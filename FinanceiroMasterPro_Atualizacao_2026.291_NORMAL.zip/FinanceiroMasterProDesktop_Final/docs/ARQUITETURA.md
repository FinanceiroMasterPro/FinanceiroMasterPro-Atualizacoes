# Arquitetura comercial

- **Desktop (WPF):** interface Windows.
- **Application:** casos de uso e regras coordenadoras.
- **Domain:** entidades e regras financeiras.
- **Infrastructure:** persistência, autenticação, licenciamento, backup e integrações.

## Segurança e licença
Licença e dados financeiros são responsabilidades separadas. Expiração de licença nunca deve apagar dados. A versão comercial deve usar hash de senha com algoritmo adaptativo (Argon2id/PBKDF2), assinatura criptográfica de licença, armazenamento seguro de segredo, auditoria e validação no servidor quando aplicável. O SHA-256 presente no protótipo é somente bootstrap local e deve ser substituído antes de produção.

## Persistência
O repositório em memória é propositalmente um protótipo compilável sem dependências externas. Antes da versão comercial, substituir por SQLite para instalação local e prever SQL Server/PostgreSQL para cenários multiusuário.
