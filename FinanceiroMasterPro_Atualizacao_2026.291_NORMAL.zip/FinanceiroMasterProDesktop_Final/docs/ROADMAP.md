# Roadmap até produção

1. Fundação C#/.NET/WPF — criada.
2. Login e separação de segurança — protótipo criado.
3. Lançamentos — layout-base criado conforme especificação.
4. Persistência SQLite + migrações.
5. Cadastros completos e lupas cadastrar/editar.
6. Pagar/Receber, filtros e baixas.
7. Parcelamentos com looping e Rateios.
8. Provisionamentos e Fluxo de Caixa.
9. Cartões/faturas com listagem dos itens antes da baixa.
10. Dashboard, relatórios, PDF/Excel e impressão.
11. Usuários, perfis, permissões e auditoria.
12. Backup/restauração e integridade.
13. Licenciamento comercial, avaliação, ativação e renovação.
14. Atualizador assinado e instalador Windows.
15. Testes automatizados, homologação, assinatura de código e release.
