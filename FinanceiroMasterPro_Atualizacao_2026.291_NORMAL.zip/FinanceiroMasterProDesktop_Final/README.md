# Financeiro Master Pro Desktop — reconstrução C#/.NET

Esta entrega consolida a nova base do Financeiro Master Pro para Windows Desktop e mantém o sistema HTML anterior apenas como referência funcional/visual.

## Incluído nesta entrega
- Solução em C# / .NET 10 LTS / WPF.
- Arquitetura Desktop, Application, Domain e Infrastructure.
- Tela de login protótipo.
- Menu dos módulos principais.
- Tela-base de Lançamentos com a distribuição de campos definida no projeto.
- Entidades de lançamentos, faturas, parcelas, rateios, provisionamentos e cadastros.
- Regras iniciais para parcelamento, rateio e baixa de itens de fatura.
- Base de licenciamento separada dos dados financeiros.
- Documentação de arquitetura e roadmap comercial.

## IMPORTANTE — estado da entrega
É **código-fonte de desenvolvimento**, não um instalador comercial final. O ambiente usado para gerar este pacote não possui o SDK `dotnet`, portanto a solução não foi compilada aqui. A validação deve ser feita no Windows com Visual Studio compatível com .NET 10.

## Primeiro teste
1. Instale Visual Studio com “Desenvolvimento para desktop com .NET” e .NET 10 SDK.
2. Abra `FinanceiroMasterPro.slnx`.
3. Defina `FinanceiroMasterPro.Desktop` como projeto de inicialização.
4. Execute.
5. Login provisório de desenvolvimento: `admin` / `admin`.

**Não use essa senha nem o hash protótipo em produção.** Eles existem apenas para permitir o primeiro teste da interface e serão substituídos pela segurança comercial.
