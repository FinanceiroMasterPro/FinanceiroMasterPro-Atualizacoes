using FinanceiroMasterPro.Domain.Entities;
namespace FinanceiroMasterPro.Application.Contracts;
public interface IRepository<T> { IReadOnlyList<T> Listar(); T? Obter(Guid id); void Salvar(T item); void Excluir(Guid id); }
public interface IAuthService { Usuario? Autenticar(string login,string senha); }
public interface ILicencaService { LicencaLocal ObterEstado(); bool PodeOperar(); }
