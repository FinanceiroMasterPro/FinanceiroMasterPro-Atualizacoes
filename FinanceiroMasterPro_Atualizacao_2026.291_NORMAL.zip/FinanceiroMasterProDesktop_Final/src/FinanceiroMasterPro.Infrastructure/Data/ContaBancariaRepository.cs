using Microsoft.Data.Sqlite;
using System;
using System.Collections.Generic;

namespace FinanceiroMasterPro.Infrastructure.Data;

public sealed class ContaBancaria
{
    public long Id { get; set; }
    public string Nome { get; set; } = "";
    public string TipoConta { get; set; } = "Conta Bancária";
    public decimal SaldoInicial { get; set; }
    public string Banco { get; set; } = "";
    public string Bandeira { get; set; } = "";
    public string Agencia { get; set; } = "";
    public string Conta { get; set; } = "";
    public decimal LimiteCredito { get; set; }
    public int? DiaFechamento { get; set; }
    public int? DiaVencimento { get; set; }
    public long? ContaPagamentoId { get; set; }
    public bool Ativo { get; set; } = true;
    public override string ToString() => Nome;
}

public sealed class ContaBancariaRepository
{
    public List<ContaBancaria> Listar()
    {
        var contas = new List<ContaBancaria>();
        using var connection = new SqliteConnection(DatabaseInitializer.ConnectionString);
        connection.Open();
        using var command = connection.CreateCommand();
        command.CommandText = """
        SELECT Id, Nome, Banco, Agencia, Conta, Ativo,
               COALESCE(TipoConta,'Conta Bancária'), COALESCE(SaldoInicial,0),
               COALESCE(LimiteCredito,0), DiaFechamento, DiaVencimento, ContaPagamentoId, COALESCE(Bandeira,'')
        FROM ContasBancarias ORDER BY TipoConta, Nome;
        """;
        using var reader = command.ExecuteReader();
        while (reader.Read()) contas.Add(new ContaBancaria {
            Id=reader.GetInt64(0), Nome=reader.GetString(1), Banco=reader.IsDBNull(2)?"":reader.GetString(2),
            Agencia=reader.IsDBNull(3)?"":reader.GetString(3), Conta=reader.IsDBNull(4)?"":reader.GetString(4),
            Ativo=reader.GetInt64(5)==1, TipoConta=reader.IsDBNull(6)?"Conta Bancária":reader.GetString(6),
            SaldoInicial=reader.IsDBNull(7)?0:Convert.ToDecimal(reader.GetDouble(7)),
            LimiteCredito=reader.IsDBNull(8)?0:Convert.ToDecimal(reader.GetDouble(8)),
            DiaFechamento=reader.IsDBNull(9)?null:reader.GetInt32(9), DiaVencimento=reader.IsDBNull(10)?null:reader.GetInt32(10),
            ContaPagamentoId=reader.IsDBNull(11)?null:reader.GetInt64(11), Bandeira=reader.IsDBNull(12)?"":reader.GetString(12)
        });
        return contas;
    }

    public long Salvar(ContaBancaria conta)
    {
        if (string.IsNullOrWhiteSpace(conta.Nome)) throw new ArgumentException("Informe o nome da conta.");
        using var connection = new SqliteConnection(DatabaseInitializer.ConnectionString); connection.Open();
        using var command=connection.CreateCommand();
        if (conta.Id==0) command.CommandText="""
          INSERT INTO ContasBancarias (Nome,Banco,Agencia,Conta,Ativo,CriadoEm,TipoConta,SaldoInicial,LimiteCredito,DiaFechamento,DiaVencimento,ContaPagamentoId,Bandeira)
          VALUES ($nome,$banco,$agencia,$conta,$ativo,$agora,$tipo,$saldo,$limite,$fech,$venc,$pag,$bandeira); SELECT last_insert_rowid();
        """;
        else command.CommandText="""
          UPDATE ContasBancarias SET Nome=$nome,Banco=$banco,Agencia=$agencia,Conta=$conta,Ativo=$ativo,AlteradoEm=$agora,
          TipoConta=$tipo,SaldoInicial=$saldo,LimiteCredito=$limite,DiaFechamento=$fech,DiaVencimento=$venc,ContaPagamentoId=$pag,Bandeira=$bandeira WHERE Id=$id; SELECT $id;
        """;
        command.Parameters.AddWithValue("$id",conta.Id); command.Parameters.AddWithValue("$nome",conta.Nome.Trim());
        command.Parameters.AddWithValue("$banco",conta.Banco.Trim()); command.Parameters.AddWithValue("$agencia",conta.Agencia.Trim());
        command.Parameters.AddWithValue("$conta",conta.Conta.Trim()); command.Parameters.AddWithValue("$ativo",conta.Ativo?1:0);
        command.Parameters.AddWithValue("$agora",DateTime.UtcNow.ToString("O")); command.Parameters.AddWithValue("$tipo",conta.TipoConta);
        command.Parameters.AddWithValue("$saldo",conta.SaldoInicial); command.Parameters.AddWithValue("$limite",conta.LimiteCredito);
        command.Parameters.AddWithValue("$fech",(object?)conta.DiaFechamento??DBNull.Value); command.Parameters.AddWithValue("$venc",(object?)conta.DiaVencimento??DBNull.Value);
        command.Parameters.AddWithValue("$pag",(object?)conta.ContaPagamentoId??DBNull.Value); command.Parameters.AddWithValue("$bandeira",conta.Bandeira??"");
        var idSalvo = Convert.ToInt64(command.ExecuteScalar());

        // A classificação escolhida pelo usuário sobrevive à troca/limpeza de empresas.
        using var historico = connection.CreateCommand();
        historico.CommandText = """
        INSERT INTO ContaClassificacoesPersistentes (NomeNormalizado, NomeExibicao, TipoConta, AlteradoEm)
        VALUES (UPPER(TRIM($nome)), TRIM($nome), $tipo, $agora)
        ON CONFLICT(NomeNormalizado) DO UPDATE SET
            NomeExibicao=excluded.NomeExibicao, TipoConta=excluded.TipoConta, AlteradoEm=excluded.AlteradoEm;
        """;
        historico.Parameters.AddWithValue("$nome", conta.Nome.Trim());
        historico.Parameters.AddWithValue("$tipo", conta.TipoConta);
        historico.Parameters.AddWithValue("$agora", DateTime.UtcNow.ToString("O"));
        historico.ExecuteNonQuery();
        return idSalvo;
    }
    public void AlterarStatus(long id,bool ativo){ using var c=new SqliteConnection(DatabaseInitializer.ConnectionString);c.Open();using var q=c.CreateCommand();q.CommandText="UPDATE ContasBancarias SET Ativo=$a,AlteradoEm=$d WHERE Id=$id";q.Parameters.AddWithValue("$a",ativo?1:0);q.Parameters.AddWithValue("$d",DateTime.UtcNow.ToString("O"));q.Parameters.AddWithValue("$id",id);q.ExecuteNonQuery(); }
    public void Excluir(long id){ using var c=new SqliteConnection(DatabaseInitializer.ConnectionString);c.Open();using(var q=c.CreateCommand()){q.CommandText="SELECT COUNT(*) FROM Lancamentos WHERE ContaBancariaId=$id";q.Parameters.AddWithValue("$id",id);var n=Convert.ToInt32(q.ExecuteScalar());if(n>0)throw new InvalidOperationException($"Esta conta está sendo utilizada em {n} lançamento(s). Localize e altere/exclua esses lançamentos antes de excluir a conta.");}using var d=c.CreateCommand();d.CommandText="DELETE FROM ContasBancarias WHERE Id=$id";d.Parameters.AddWithValue("$id",id);d.ExecuteNonQuery();}
}
