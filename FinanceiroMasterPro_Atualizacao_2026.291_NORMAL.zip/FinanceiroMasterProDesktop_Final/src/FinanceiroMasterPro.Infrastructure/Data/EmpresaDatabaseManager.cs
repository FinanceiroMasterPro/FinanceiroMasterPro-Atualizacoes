using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;

namespace FinanceiroMasterPro.Infrastructure.Data;

public sealed class EmpresaBanco
{
    public string Id { get; set; } = Guid.NewGuid().ToString("N");
    public string Nome { get; set; } = "Empresa Principal";
    public string ArquivoBanco { get; set; } = "financeiro.db";
    public DateTime CriadaEm { get; set; } = DateTime.Now;
    public bool Ativa { get; set; } = true;
    public DateTime? InativadaEm { get; set; }
}

public static class EmpresaDatabaseManager
{
    private static readonly string Pasta = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "FinanceiroMasterPro");
    private static readonly string Registro = Path.Combine(Pasta, "empresas.json");
    public static EmpresaBanco? EmpresaAtual { get; private set; }

    public static List<EmpresaBanco> Listar()
    {
        Directory.CreateDirectory(Pasta);
        List<EmpresaBanco> lista = new();
        if (File.Exists(Registro))
        {
            try { lista = JsonSerializer.Deserialize<List<EmpresaBanco>>(File.ReadAllText(Registro)) ?? new(); }
            catch { lista = new(); }
        }
        if (lista.Count == 0)
        {
            lista.Add(new EmpresaBanco { Nome = "Empresa Principal", ArquivoBanco = "financeiro.db" });
            Salvar(lista);
        }
        return lista.Where(x => x.Ativa).OrderBy(x => x.Nome, StringComparer.CurrentCultureIgnoreCase).ToList();
    }

    public static List<EmpresaBanco> ListarInativas()
    {
        var lista = LerTodas();
        return lista.Where(x => !x.Ativa).OrderBy(x => x.Nome, StringComparer.CurrentCultureIgnoreCase).ToList();
    }

    private static List<EmpresaBanco> LerTodas()
    {
        Directory.CreateDirectory(Pasta);
        List<EmpresaBanco> lista = new();
        if (File.Exists(Registro))
        {
            try { lista = JsonSerializer.Deserialize<List<EmpresaBanco>>(File.ReadAllText(Registro)) ?? new(); }
            catch { lista = new(); }
        }
        if (lista.Count == 0)
        {
            lista.Add(new EmpresaBanco { Nome = "Empresa Principal", ArquivoBanco = "financeiro.db", Ativa = true });
            Salvar(lista);
        }
        return lista;
    }

    public static EmpresaBanco Criar(string nome)
    {
        nome = (nome ?? "").Trim();
        if (nome.Length < 2) throw new InvalidOperationException("Informe o nome da empresa.");
        var lista = LerTodas();
        if (lista.Any(x => x.Nome.Equals(nome, StringComparison.CurrentCultureIgnoreCase)))
            throw new InvalidOperationException("Já existe uma empresa com esse nome.");
        var e = new EmpresaBanco { Nome = nome, ArquivoBanco = $"empresa_{Guid.NewGuid():N}.db" };
        lista.Add(e); Salvar(lista); return e;
    }

    public static EmpresaBanco AlterarNome(EmpresaBanco empresa, string novoNome)
    {
        novoNome = (novoNome ?? "").Trim();
        if (novoNome.Length < 2) throw new InvalidOperationException("Informe o nome da empresa.");
        var lista = LerTodas();
        if (lista.Any(x => x.Id != empresa.Id && x.Nome.Equals(novoNome, StringComparison.CurrentCultureIgnoreCase)))
            throw new InvalidOperationException("Já existe uma empresa com esse nome.");
        var atual = lista.FirstOrDefault(x => x.Id == empresa.Id)
            ?? throw new InvalidOperationException("Empresa não encontrada.");
        atual.Nome = novoNome;
        Salvar(lista);
        if (EmpresaAtual?.Id == atual.Id) EmpresaAtual.Nome = novoNome;
        return atual;
    }


    public static void Inativar(EmpresaBanco empresa)
    {
        var lista = LerTodas();
        var atual = lista.FirstOrDefault(x => x.Id == empresa.Id) ?? throw new InvalidOperationException("Empresa não encontrada.");
        if (lista.Count(x => x.Ativa) <= 1) throw new InvalidOperationException("É necessário manter pelo menos uma empresa ativa.");
        atual.Ativa = false; atual.InativadaEm = DateTime.Now; Salvar(lista);
    }

    public static void Ativar(EmpresaBanco empresa)
    {
        var lista = LerTodas();
        var atual = lista.FirstOrDefault(x => x.Id == empresa.Id) ?? throw new InvalidOperationException("Empresa não encontrada.");
        atual.Ativa = true; atual.InativadaEm = null; Salvar(lista);
    }

    public static void Selecionar(EmpresaBanco empresa)
    {
        Directory.CreateDirectory(Pasta);
        EmpresaAtual = empresa;
        DatabaseInitializer.SelecionarBanco(Path.Combine(Pasta, empresa.ArquivoBanco));
    }

    public static string NomeAtual => EmpresaAtual?.Nome ?? "Empresa Principal";

    private static void Salvar(List<EmpresaBanco> lista)
    {
        Directory.CreateDirectory(Pasta);
        File.WriteAllText(Registro, JsonSerializer.Serialize(lista, new JsonSerializerOptions { WriteIndented = true }));
    }
}
