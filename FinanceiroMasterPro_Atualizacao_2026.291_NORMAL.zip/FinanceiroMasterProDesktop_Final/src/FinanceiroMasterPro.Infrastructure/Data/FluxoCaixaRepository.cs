using Microsoft.Data.Sqlite;
using System;
using System.Collections.Generic;

namespace FinanceiroMasterPro.Infrastructure.Data;

public sealed class FluxoCaixa
{
    public long Id { get; set; }
    public string Nome { get; set; } = "";
    public bool Ativo { get; set; } = true;

    public override string ToString() => Nome;
}

public sealed class FluxoCaixaRepository
{
    public List<FluxoCaixa> Listar()
    {
        var itens = new List<FluxoCaixa>();

        using var connection =
            new SqliteConnection(DatabaseInitializer.ConnectionString);

        connection.Open();

        using var command = connection.CreateCommand();

        command.CommandText =
        """
        SELECT Id, Nome, Ativo
        FROM FluxosCaixa
        ORDER BY Nome;
        """;

        using var reader = command.ExecuteReader();

        while (reader.Read())
        {
            itens.Add(new FluxoCaixa
            {
                Id = reader.GetInt64(0),
                Nome = reader.GetString(1),
                Ativo = reader.GetInt64(2) == 1
            });
        }

        return itens;
    }

    public long Salvar(FluxoCaixa item)
    {
        if (string.IsNullOrWhiteSpace(item.Nome))
            throw new ArgumentException(
                "Informe o nome do Fluxo de Caixa.");

        using var connection =
            new SqliteConnection(DatabaseInitializer.ConnectionString);

        connection.Open();

        if (item.Id == 0)
            return Inserir(connection, item);

        Atualizar(connection, item);
        return item.Id;
    }

    private static long Inserir(
        SqliteConnection connection,
        FluxoCaixa item)
    {
        using var command = connection.CreateCommand();

        command.CommandText =
        """
        INSERT INTO FluxosCaixa
        (
            Nome,
            Ativo,
            CriadoEm
        )
        VALUES
        (
            $nome,
            $ativo,
            $criadoEm
        );

        SELECT last_insert_rowid();
        """;

        command.Parameters.AddWithValue(
            "$nome",
            item.Nome.Trim());

        command.Parameters.AddWithValue(
            "$ativo",
            item.Ativo ? 1 : 0);

        command.Parameters.AddWithValue(
            "$criadoEm",
            DateTime.UtcNow.ToString("O"));

        return Convert.ToInt64(
            command.ExecuteScalar());
    }

    private static void Atualizar(
        SqliteConnection connection,
        FluxoCaixa item)
    {
        using var command = connection.CreateCommand();

        command.CommandText =
        """
        UPDATE FluxosCaixa
        SET
            Nome = $nome,
            Ativo = $ativo,
            AlteradoEm = $alteradoEm
        WHERE Id = $id;
        """;

        command.Parameters.AddWithValue("$id", item.Id);
        command.Parameters.AddWithValue("$nome", item.Nome.Trim());
        command.Parameters.AddWithValue("$ativo", item.Ativo ? 1 : 0);
        command.Parameters.AddWithValue(
            "$alteradoEm",
            DateTime.UtcNow.ToString("O"));

        command.ExecuteNonQuery();
    }

    public void AlterarStatus(long id, bool ativo)
    {
        using var connection =
            new SqliteConnection(DatabaseInitializer.ConnectionString);

        connection.Open();

        using var command = connection.CreateCommand();

        command.CommandText =
        """
        UPDATE FluxosCaixa
        SET
            Ativo = $ativo,
            AlteradoEm = $alteradoEm
        WHERE Id = $id;
        """;

        command.Parameters.AddWithValue("$id", id);
        command.Parameters.AddWithValue(
            "$ativo",
            ativo ? 1 : 0);

        command.Parameters.AddWithValue(
            "$alteradoEm",
            DateTime.UtcNow.ToString("O"));

        command.ExecuteNonQuery();
    }

    public void Excluir(long id)
    {
        using var connection = new SqliteConnection(DatabaseInitializer.ConnectionString);
        connection.Open();

        using (var check = connection.CreateCommand())
        {
            check.CommandText = "SELECT COUNT(*) FROM Lancamentos WHERE FluxoCaixaId = $id;";
            check.Parameters.AddWithValue("$id", id);
            var total = Convert.ToInt32(check.ExecuteScalar());
            if (total > 0)
                throw new InvalidOperationException($"Este cadastro está sendo utilizado em {total} lançamento(s). Localize e altere/exclua esses lançamentos antes de excluir o cadastro.");
        }

        using var command = connection.CreateCommand();
        command.CommandText = "DELETE FROM FluxosCaixa WHERE Id = $id;";
        command.Parameters.AddWithValue("$id", id);
        command.ExecuteNonQuery();
    }
}