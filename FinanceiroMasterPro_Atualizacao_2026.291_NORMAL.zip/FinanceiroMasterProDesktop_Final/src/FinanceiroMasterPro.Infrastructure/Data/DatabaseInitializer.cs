using Microsoft.Data.Sqlite;
using System;
using System.IO;
using System.Collections.Generic;
using System.Globalization;

namespace FinanceiroMasterPro.Infrastructure.Data;

public static class DatabaseInitializer
{
    private static string _databasePath = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
        "FinanceiroMasterPro",
        "financeiro.db");

    public static string DatabasePath => _databasePath;

    public static void SelecionarBanco(string caminho)
    {
        if (string.IsNullOrWhiteSpace(caminho))
            throw new ArgumentException("Caminho do banco inválido.", nameof(caminho));
        _databasePath = caminho;
    }

    public static string ConnectionString =>
        $"Data Source={DatabasePath}";

    public static void Initialize()
    {
        var pasta =
            Path.GetDirectoryName(DatabasePath);

        if (!string.IsNullOrWhiteSpace(pasta))
        {
            Directory.CreateDirectory(pasta);
        }

        using var connection =
            new SqliteConnection(ConnectionString);

        connection.Open();

        using (var pragma = connection.CreateCommand())
        {
            pragma.CommandText =
                "PRAGMA foreign_keys = ON;";

            pragma.ExecuteNonQuery();
        }

        using var command =
            connection.CreateCommand();

        command.CommandText =
        """
        CREATE TABLE IF NOT EXISTS ContasBancarias
        (
            Id INTEGER PRIMARY KEY AUTOINCREMENT,
            Nome TEXT NOT NULL,
            Banco TEXT,
            Agencia TEXT,
            Conta TEXT,
            Ativo INTEGER NOT NULL DEFAULT 1,
            CriadoEm TEXT NOT NULL,
            AlteradoEm TEXT
        );

        CREATE TABLE IF NOT EXISTS ContaClassificacoesPersistentes
        (
            NomeNormalizado TEXT PRIMARY KEY,
            NomeExibicao TEXT NOT NULL,
            TipoConta TEXT NOT NULL,
            AlteradoEm TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS ClientesFornecedores
        (
            Id INTEGER PRIMARY KEY AUTOINCREMENT,
            Nome TEXT NOT NULL,
            Documento TEXT,
            Tipo TEXT,
            Ativo INTEGER NOT NULL DEFAULT 1,
            CriadoEm TEXT NOT NULL,
            AlteradoEm TEXT
        );

        CREATE TABLE IF NOT EXISTS PlanosContas
        (
            Id INTEGER PRIMARY KEY AUTOINCREMENT,
            Nome TEXT NOT NULL,
            Ativo INTEGER NOT NULL DEFAULT 1,
            CriadoEm TEXT NOT NULL,
            AlteradoEm TEXT
        );

        CREATE TABLE IF NOT EXISTS CentrosCustos
        (
            Id INTEGER PRIMARY KEY AUTOINCREMENT,
            Nome TEXT NOT NULL,
            Ativo INTEGER NOT NULL DEFAULT 1,
            CriadoEm TEXT NOT NULL,
            AlteradoEm TEXT
        );

        CREATE TABLE IF NOT EXISTS GruposContas
        (
            Id INTEGER PRIMARY KEY AUTOINCREMENT,
            Nome TEXT NOT NULL,
            Ativo INTEGER NOT NULL DEFAULT 1,
            CriadoEm TEXT NOT NULL,
            AlteradoEm TEXT
        );

        CREATE TABLE IF NOT EXISTS FluxosCaixa
        (
            Id INTEGER PRIMARY KEY AUTOINCREMENT,
            Nome TEXT NOT NULL,
            Ativo INTEGER NOT NULL DEFAULT 1,
            CriadoEm TEXT NOT NULL,
            AlteradoEm TEXT
        );

        CREATE TABLE IF NOT EXISTS Lancamentos
        (
            Id INTEGER PRIMARY KEY AUTOINCREMENT,

            Tipo TEXT NOT NULL,

            ContaBancariaId INTEGER,

            DataPagamento TEXT,
            DataEmissao TEXT NOT NULL,

            ClienteFornecedorId INTEGER,

            Descricao TEXT NOT NULL,
            NumeroDocumento TEXT,

            PlanoContasId INTEGER,
            CentroCustosId INTEGER,
            GrupoContasId INTEGER,
            FluxoCaixaId INTEGER,

            Valor REAL NOT NULL DEFAULT 0,

            Periodo TEXT,
            Anotacoes TEXT,

            Baixado INTEGER NOT NULL DEFAULT 0,
            DataBaixa TEXT,

            Ativo INTEGER NOT NULL DEFAULT 1,

            CriadoEm TEXT NOT NULL,
            AlteradoEm TEXT,

            FOREIGN KEY (ContaBancariaId)
                REFERENCES ContasBancarias(Id),

            FOREIGN KEY (ClienteFornecedorId)
                REFERENCES ClientesFornecedores(Id),

            FOREIGN KEY (PlanoContasId)
                REFERENCES PlanosContas(Id),

            FOREIGN KEY (CentroCustosId)
                REFERENCES CentrosCustos(Id),

            FOREIGN KEY (GrupoContasId)
                REFERENCES GruposContas(Id),

            FOREIGN KEY (FluxoCaixaId)
                REFERENCES FluxosCaixa(Id)
        );

        ---------------------------------------------------------
        -- PARCELAMENTOS
        ---------------------------------------------------------

        CREATE TABLE IF NOT EXISTS Parcelamentos
        (
            Id INTEGER PRIMARY KEY AUTOINCREMENT,

            Tipo TEXT NOT NULL,
            Descricao TEXT NOT NULL,

            ValorTotal REAL NOT NULL,

            QuantidadeParcelas INTEGER NOT NULL,

            PrimeiraData TEXT NOT NULL,

            Ativo INTEGER NOT NULL DEFAULT 1,

            CriadoEm TEXT NOT NULL,
            AlteradoEm TEXT
        );

        CREATE TABLE IF NOT EXISTS ParcelamentoItens
        (
            Id INTEGER PRIMARY KEY AUTOINCREMENT,

            ParcelamentoId INTEGER NOT NULL,
            LancamentoId INTEGER NOT NULL,

            NumeroParcela INTEGER NOT NULL,
            QuantidadeParcelas INTEGER NOT NULL,

            ValorParcela REAL NOT NULL,
            DataVencimento TEXT NOT NULL,

            CriadoEm TEXT NOT NULL,

            FOREIGN KEY (ParcelamentoId)
                REFERENCES Parcelamentos(Id),

            FOREIGN KEY (LancamentoId)
                REFERENCES Lancamentos(Id)
        );

        ---------------------------------------------------------
        -- RATEIOS
        ---------------------------------------------------------

        CREATE TABLE IF NOT EXISTS Rateios
        (
            Id INTEGER PRIMARY KEY AUTOINCREMENT,

            LancamentoId INTEGER NOT NULL,

            ValorTotal REAL NOT NULL,

            Ativo INTEGER NOT NULL DEFAULT 1,

            CriadoEm TEXT NOT NULL,
            AlteradoEm TEXT,

            FOREIGN KEY (LancamentoId)
                REFERENCES Lancamentos(Id)
        );

        ---------------------------------------------------------
        -- ITENS DO RATEIO
        ---------------------------------------------------------

        CREATE TABLE IF NOT EXISTS RateioItens
        (
            Id INTEGER PRIMARY KEY AUTOINCREMENT,

            RateioId INTEGER NOT NULL,

            CentroCustosId INTEGER NOT NULL,

            Percentual REAL NOT NULL,

            Valor REAL NOT NULL,

            CriadoEm TEXT NOT NULL,

            FOREIGN KEY (RateioId)
                REFERENCES Rateios(Id),

            FOREIGN KEY (CentroCustosId)
                REFERENCES CentrosCustos(Id)
        );

        ---------------------------------------------------------
        -- ÍNDICES DOS LANÇAMENTOS
        ---------------------------------------------------------

        CREATE INDEX IF NOT EXISTS
            IX_Lancamentos_DataPagamento
        ON Lancamentos(DataPagamento);

        CREATE INDEX IF NOT EXISTS
            IX_Lancamentos_DataEmissao
        ON Lancamentos(DataEmissao);

        CREATE INDEX IF NOT EXISTS
            IX_Lancamentos_ClienteFornecedor
        ON Lancamentos(ClienteFornecedorId);

        CREATE INDEX IF NOT EXISTS
            IX_Lancamentos_ContaBancaria
        ON Lancamentos(ContaBancariaId);

        CREATE INDEX IF NOT EXISTS
            IX_Lancamentos_Tipo
        ON Lancamentos(Tipo);

        ---------------------------------------------------------
        -- ÍNDICES DOS PARCELAMENTOS
        ---------------------------------------------------------

        CREATE INDEX IF NOT EXISTS
            IX_ParcelamentoItens_Parcelamento
        ON ParcelamentoItens(ParcelamentoId);

        CREATE INDEX IF NOT EXISTS
            IX_ParcelamentoItens_Lancamento
        ON ParcelamentoItens(LancamentoId);

        CREATE UNIQUE INDEX IF NOT EXISTS
            UX_ParcelamentoItens_Parcela
        ON ParcelamentoItens
        (
            ParcelamentoId,
            NumeroParcela
        );

        ---------------------------------------------------------
        -- ÍNDICES DOS RATEIOS
        ---------------------------------------------------------

        CREATE INDEX IF NOT EXISTS
            IX_Rateios_Lancamento
        ON Rateios(LancamentoId);

        CREATE INDEX IF NOT EXISTS
            IX_RateioItens_Rateio
        ON RateioItens(RateioId);

        CREATE INDEX IF NOT EXISTS
            IX_RateioItens_CentroCustos
        ON RateioItens(CentroCustosId);
        """;

        command.ExecuteNonQuery();

        GarantirColuna(connection, "Lancamentos", "NumeroDocumento", "TEXT");
        GarantirColuna(connection, "ContasBancarias", "TipoConta", "TEXT NOT NULL DEFAULT 'Conta Bancária'");
        GarantirColuna(connection, "ContasBancarias", "Bandeira", "TEXT");
        GarantirColuna(connection, "ContasBancarias", "SaldoInicial", "REAL NOT NULL DEFAULT 0");
        GarantirColuna(connection, "ContasBancarias", "LimiteCredito", "REAL NOT NULL DEFAULT 0");
        GarantirColuna(connection, "ContasBancarias", "DiaFechamento", "INTEGER");
        GarantirColuna(connection, "ContasBancarias", "DiaVencimento", "INTEGER");
        GarantirColuna(connection, "ContasBancarias", "ContaPagamentoId", "INTEGER");
        CorrigirTipoDinheiroConhecido(connection);
        // Não inferir BAIXA pelo Período de Caixa: a fonte oficial é BAIXAR/BAIXADAS do Excel.
        LimparCadastrosNumericosImportados(connection);
        // Reparação automática desativada: não alterar BAIXA de lançamentos já existentes por heurística.
        // A BAIXA correta passa a vir exclusivamente da coluna BAIXAR/BAIXADAS durante a importação.
    }


    private static void CorrigirTipoDinheiroConhecido(SqliteConnection connection)
    {
        // Migração específica do cadastro existente do usuário: CAIXA GAVETA é conta do tipo DINHEIRO.
        // Novas contas usam sempre o TIPO DA CONTA escolhido no cadastro.
        using var command = connection.CreateCommand();
        command.CommandText = @"UPDATE ContasBancarias
                                   SET TipoConta = 'Dinheiro'
                                 WHERE UPPER(TRIM(Nome)) = 'CAIXA GAVETA'
                                   AND COALESCE(TRIM(TipoConta),'') <> 'Dinheiro';";
        command.ExecuteNonQuery();
    }

    private static void GarantirColuna(SqliteConnection connection, string tabela, string coluna, string tipo)
    {
        using var check = connection.CreateCommand();
        check.CommandText = $"PRAGMA table_info({tabela});";
        using var reader = check.ExecuteReader();
        while (reader.Read())
            if (string.Equals(reader.GetString(1), coluna, StringComparison.OrdinalIgnoreCase)) return;
        reader.Close();
        using var alter = connection.CreateCommand();
        alter.CommandText = $"ALTER TABLE {tabela} ADD COLUMN {coluna} {tipo};";
        alter.ExecuteNonQuery();
    }

    private static void CorrigirBaixasImportadasLegadas(SqliteConnection connection)
    {
        // Importações antigas podiam perder o valor visual do checkbox BAIXA no XML.
        // No arquivo original, PERÍODO DE CAIXA preenchido identifica lançamento realizado.
        using var command = connection.CreateCommand();
        command.CommandText =
        """
        UPDATE Lancamentos
           SET Baixado = 1,
               DataBaixa = COALESCE(DataBaixa, DataPagamento)
         WHERE Ativo = 1
           AND Baixado = 0
           AND Periodo IS NOT NULL
           AND TRIM(Periodo) <> '';
        """;
        command.ExecuteNonQuery();
    }

    private static void LimparCadastrosNumericosImportados(SqliteConnection connection)
    {
        LimparTabelaNumerica(connection, "ContasBancarias", "ContaBancariaId");
        LimparTabelaNumerica(connection, "ClientesFornecedores", "ClienteFornecedorId");
                LimparTabelaNumerica(connection, "PlanosContas", "PlanoContasId");
        LimparTabelaNumerica(connection, "CentrosCustos", "CentroCustosId");
        LimparTabelaNumerica(connection, "GruposContas", "GrupoContasId");
        LimparTabelaNumerica(connection, "FluxosCaixa", "FluxoCaixaId");
    }

    private static void LimparTabelaNumerica(
        SqliteConnection connection,
        string tabela,
        string colunaLancamento)
    {
        var ids = new List<long>();

        using (var select = connection.CreateCommand())
        {
            select.CommandText = $"SELECT Id, Nome FROM {tabela};";
            using var reader = select.ExecuteReader();

            while (reader.Read())
            {
                string nome = reader.IsDBNull(1) ? "" : reader.GetString(1).Trim();
                string teste = nome.Replace("R$", "").Replace(" ", "").Trim();

                bool numerico =
                    decimal.TryParse(teste, NumberStyles.Any, CultureInfo.InvariantCulture, out _) ||
                    decimal.TryParse(teste, NumberStyles.Any, new CultureInfo("pt-BR"), out _);

                if (numerico)
                    ids.Add(reader.GetInt64(0));
            }
        }

        foreach (long id in ids)
        {
            using var tx = connection.BeginTransaction();

            using (var limpar = connection.CreateCommand())
            {
                limpar.Transaction = tx;
                limpar.CommandText = $"UPDATE Lancamentos SET {colunaLancamento} = NULL WHERE {colunaLancamento} = $id;";
                limpar.Parameters.AddWithValue("$id", id);
                limpar.ExecuteNonQuery();
            }

            using (var excluir = connection.CreateCommand())
            {
                excluir.Transaction = tx;
                excluir.CommandText = $"DELETE FROM {tabela} WHERE Id = $id;";
                excluir.Parameters.AddWithValue("$id", id);
                excluir.ExecuteNonQuery();
            }

            tx.Commit();
        }
    }

    public static string LimparTodosDadosFinanceiros()
    {
        Directory.CreateDirectory(Path.GetDirectoryName(DatabasePath)!);
        string backup = "";
        if (File.Exists(DatabasePath))
        {
            var backupDir = Path.Combine(Path.GetDirectoryName(DatabasePath)!, "Backups");
            Directory.CreateDirectory(backupDir);
            backup = Path.Combine(backupDir, $"financeiro_antes_reset_{DateTime.Now:yyyyMMdd_HHmmss}.db");
            File.Copy(DatabasePath, backup, true);
        }

        using var connection = new SqliteConnection(ConnectionString);
        connection.Open();
        using var transaction = connection.BeginTransaction();
        // Antes de trocar/limpar uma empresa, guarda a classificação feita pelo usuário.
        // Esta tabela NÃO é apagada no reset; por isso uma conta conhecida recupera seu tipo
        // quando a planilha daquela empresa for importada novamente.
        using (var guardar = connection.CreateCommand())
        {
            guardar.Transaction = transaction;
            guardar.CommandText = """
            INSERT INTO ContaClassificacoesPersistentes (NomeNormalizado, NomeExibicao, TipoConta, AlteradoEm)
            SELECT UPPER(TRIM(Nome)), TRIM(Nome), COALESCE(NULLIF(TRIM(TipoConta),''),'Conta Bancária'), $agora
            FROM ContasBancarias
            WHERE TRIM(Nome) <> ''
            ON CONFLICT(NomeNormalizado) DO UPDATE SET
                NomeExibicao=excluded.NomeExibicao,
                TipoConta=excluded.TipoConta,
                AlteradoEm=excluded.AlteradoEm;
            """;
            guardar.Parameters.AddWithValue("$agora", DateTime.UtcNow.ToString("O"));
            guardar.ExecuteNonQuery();
        }

        using var command = connection.CreateCommand();
        command.Transaction = transaction;
        command.CommandText =
        """
        PRAGMA foreign_keys=OFF;
        DELETE FROM RateioItens;
        DELETE FROM Rateios;
        DELETE FROM ParcelamentoItens;
        DELETE FROM Parcelamentos;
        DELETE FROM Lancamentos;
        DELETE FROM PlanoClassificacoes;
        DELETE FROM ClientesFornecedores;
        DELETE FROM PlanosContas;
        DELETE FROM CentrosCustos;
        DELETE FROM GruposContas;
        DELETE FROM FluxosCaixa;
        DELETE FROM ContasBancarias;
        DELETE FROM sqlite_sequence
        WHERE name IN ('RateioItens','Rateios','ParcelamentoItens','Parcelamentos',
                       'Lancamentos','ClientesFornecedores','PlanosContas','CentrosCustos',
                       'GruposContas','FluxosCaixa','ContasBancarias');
        """;
        command.ExecuteNonQuery();
        transaction.Commit();
        return backup;
    }

}