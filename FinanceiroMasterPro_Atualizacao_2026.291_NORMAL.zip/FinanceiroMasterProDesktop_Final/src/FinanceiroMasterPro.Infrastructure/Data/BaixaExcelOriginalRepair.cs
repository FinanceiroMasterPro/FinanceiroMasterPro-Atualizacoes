using Microsoft.Data.Sqlite;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Xml.Linq;

namespace FinanceiroMasterPro.Infrastructure.Data;

internal static class BaixaExcelOriginalRepair
{
    private const string ChaveMigracao = "2026.025-BAIXAS-EXCEL-ORIGINAL";

    public static void Executar(SqliteConnection connection)
    {
        GarantirTabelaMigracoes(connection);
        if (JaExecutada(connection)) return;

        string? arquivo = LocalizarExcelOriginal();
        if (arquivo == null) return;

        int sincronizados = Sincronizar(connection, arquivo);
        // Só grava a migração quando realmente encontrou lançamentos do Excel no banco.
        // Assim, se a planilha não estiver disponível hoje, o sistema tenta novamente depois.
        if (sincronizados > 0)
            MarcarExecutada(connection);
    }

    private static string? LocalizarExcelOriginal()
    {
        string desktop = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);
        string pasta = Path.Combine(desktop, "CASA FINANCEIRO");
        string exato = Path.Combine(pasta, "FINANCEIRO MASTER PRO v.2026.000.xlsm");
        if (File.Exists(exato)) return exato;

        if (!Directory.Exists(pasta)) return null;
        return Directory.EnumerateFiles(pasta, "*.xlsm", SearchOption.TopDirectoryOnly)
            .FirstOrDefault(x => string.Equals(Path.GetFileName(x), "FINANCEIRO MASTER PRO v.2026.000.xlsm", StringComparison.OrdinalIgnoreCase));
    }

    private static int Sincronizar(SqliteConnection connection, string arquivo)
    {
        using FileStream stream = new(arquivo, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
        using ZipArchive zip = new(stream, ZipArchiveMode.Read, leaveOpen: false);

        List<string> shared = LerSharedStrings(zip);
        string? planilha = LocalizarPlanilhaLancamentos(zip);
        if (planilha == null) return 0;

        ZipArchiveEntry? entry = zip.GetEntry(planilha);
        if (entry == null) return 0;

        XDocument doc;
        using (Stream s = entry.Open()) doc = XDocument.Load(s);
        XNamespace ns = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";

        var idsPorChave = CarregarLancamentosBanco(connection);
        var usados = new HashSet<long>();
        int sincronizados = 0;

        using var tx = connection.BeginTransaction();
        foreach (XElement row in doc.Descendants(ns + "row"))
        {
            var cells = LerCelulasLinha(row, ns, shared);
            string conta = Obter(cells, 2).Trim();
            string dataTexto = Obter(cells, 3);
            string descricao = Obter(cells, 6).Trim();
            string valorTexto = Obter(cells, 9);
            if (string.IsNullOrWhiteSpace(conta) || !TentarDecimal(valorTexto, out decimal valor)) continue;

            DateTime? data = LerDataExcel(dataTexto);
            string chave = Chave(conta, data, descricao, valor);
            if (!idsPorChave.TryGetValue(chave, out Queue<long>? fila)) continue;

            long id = 0;
            while (fila.Count > 0)
            {
                long candidato = fila.Dequeue();
                if (usados.Add(candidato)) { id = candidato; break; }
            }
            if (id == 0) continue;

            bool baixado = InterpretarBaixa(Obter(cells, 1));
            using var cmd = connection.CreateCommand();
            cmd.Transaction = tx;
            cmd.CommandText = "UPDATE Lancamentos SET Baixado=$b, DataBaixa=$d WHERE Id=$id;";
            cmd.Parameters.AddWithValue("$b", baixado ? 1 : 0);
            cmd.Parameters.AddWithValue("$d", baixado && data.HasValue ? data.Value.ToString("yyyy-MM-dd") : DBNull.Value);
            cmd.Parameters.AddWithValue("$id", id);
            cmd.ExecuteNonQuery();
            sincronizados++;
        }
        tx.Commit();
        return sincronizados;
    }

    private static Dictionary<string, Queue<long>> CarregarLancamentosBanco(SqliteConnection connection)
    {
        var result = new Dictionary<string, Queue<long>>(StringComparer.OrdinalIgnoreCase);
        using var cmd = connection.CreateCommand();
        cmd.CommandText = """
            SELECT l.Id, COALESCE(c.Nome,''), l.DataPagamento, COALESCE(l.Descricao,''), l.Valor
              FROM Lancamentos l
              LEFT JOIN ContasBancarias c ON c.Id=l.ContaBancariaId
             WHERE l.Ativo=1
             ORDER BY l.Id;
            """;
        using var r = cmd.ExecuteReader();
        while (r.Read())
        {
            long id = r.GetInt64(0);
            string conta = r.GetString(1);
            DateTime? data = null;
            if (!r.IsDBNull(2) && DateTime.TryParse(r.GetString(2), CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime d)) data = d.Date;
            string desc = r.GetString(3);
            decimal valor = Convert.ToDecimal(r.GetDouble(4), CultureInfo.InvariantCulture);
            string chave = Chave(conta, data, desc, valor);
            if (!result.TryGetValue(chave, out Queue<long>? q)) result[chave] = q = new Queue<long>();
            q.Enqueue(id);
        }
        return result;
    }

    private static string Chave(string conta, DateTime? data, string descricao, decimal valor) =>
        $"{Norm(conta)}|{(data.HasValue ? data.Value.ToString("yyyy-MM-dd") : "")}|{Norm(descricao)}|{Math.Round(valor, 2):0.00}";

    private static string Norm(string s) => string.Join(' ', (s ?? "").Trim().ToUpperInvariant().Split((char[]?)null, StringSplitOptions.RemoveEmptyEntries));

    private static bool InterpretarBaixa(string texto)
    {
        string v = (texto ?? "").Trim().ToUpperInvariant();
        return v is "SIM" or "S" or "TRUE" or "VERDADEIRO" or "1" or "BAIXADO" or "BAIXADA" or "PAGO" or "PAGA" or "RECEBIDO" or "RECEBIDA";
    }

    private static bool TentarDecimal(string texto, out decimal valor)
    {
        texto = (texto ?? "").Trim();
        if (decimal.TryParse(texto, NumberStyles.Any, CultureInfo.InvariantCulture, out valor)) return true;
        return decimal.TryParse(texto, NumberStyles.Any, new CultureInfo("pt-BR"), out valor);
    }

    private static DateTime? LerDataExcel(string texto)
    {
        texto = (texto ?? "").Trim();
        if (double.TryParse(texto, NumberStyles.Any, CultureInfo.InvariantCulture, out double serial))
        {
            try { return DateTime.FromOADate(serial).Date; } catch { }
        }
        if (DateTime.TryParse(texto, new CultureInfo("pt-BR"), DateTimeStyles.None, out DateTime br)) return br.Date;
        if (DateTime.TryParse(texto, CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime inv)) return inv.Date;
        return null;
    }

    private static List<string> LerSharedStrings(ZipArchive zip)
    {
        var list = new List<string>();
        var entry = zip.GetEntry("xl/sharedStrings.xml");
        if (entry == null) return list;
        using Stream s = entry.Open();
        XDocument doc = XDocument.Load(s);
        XNamespace ns = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";
        foreach (var si in doc.Descendants(ns + "si")) list.Add(string.Concat(si.Descendants(ns + "t").Select(x => x.Value)));
        return list;
    }

    private static string? LocalizarPlanilhaLancamentos(ZipArchive zip)
    {
        var wbEntry = zip.GetEntry("xl/workbook.xml");
        var relEntry = zip.GetEntry("xl/_rels/workbook.xml.rels");
        if (wbEntry == null || relEntry == null) return null;
        XDocument wb; using (Stream s = wbEntry.Open()) wb = XDocument.Load(s);
        XDocument rel; using (Stream s = relEntry.Open()) rel = XDocument.Load(s);
        XNamespace ns = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";
        XNamespace rns = "http://schemas.openxmlformats.org/officeDocument/2006/relationships";
        var sheet = wb.Descendants(ns + "sheet").FirstOrDefault(x => string.Equals((string?)x.Attribute("name"), "LANÇAMENTOS", StringComparison.OrdinalIgnoreCase));
        if (sheet == null) return null;
        string? rid = (string?)sheet.Attribute(rns + "id");
        if (rid == null) return null;
        XNamespace pr = "http://schemas.openxmlformats.org/package/2006/relationships";
        string? target = rel.Descendants(pr + "Relationship").FirstOrDefault(x => (string?)x.Attribute("Id") == rid)?.Attribute("Target")?.Value;
        if (target == null) return null;
        target = target.Replace('\\', '/').TrimStart('/');
        if (target.StartsWith("xl/", StringComparison.OrdinalIgnoreCase)) return target;
        while (target.StartsWith("../", StringComparison.Ordinal)) target = target[3..];
        return "xl/" + target;
    }

    private static Dictionary<int, string> LerCelulasLinha(XElement row, XNamespace ns, List<string> shared)
    {
        var dict = new Dictionary<int, string>();
        foreach (var c in row.Elements(ns + "c"))
        {
            string referencia = (string?)c.Attribute("r") ?? "";
            int coluna = Coluna(referencia);
            if (coluna <= 0 || coluna > 14) continue;
            string tipo = (string?)c.Attribute("t") ?? "";
            string valor = "";
            if (tipo == "inlineStr") valor = string.Concat(c.Descendants(ns + "t").Select(x => x.Value));
            else
            {
                string raw = c.Element(ns + "v")?.Value ?? "";
                if (tipo == "s" && int.TryParse(raw, out int i) && i >= 0 && i < shared.Count) valor = shared[i];
                else if (tipo == "b") valor = raw == "1" ? "TRUE" : "FALSE";
                else valor = raw;
            }
            dict[coluna] = valor;
        }
        return dict;
    }

    private static int Coluna(string referencia)
    {
        int n = 0;
        foreach (char ch in referencia)
        {
            if (!char.IsLetter(ch)) break;
            n = n * 26 + (char.ToUpperInvariant(ch) - 'A' + 1);
        }
        return n;
    }

    private static string Obter(Dictionary<int, string> cells, int col) => cells.TryGetValue(col, out string? v) ? v : "";

    private static void GarantirTabelaMigracoes(SqliteConnection connection)
    {
        using var cmd = connection.CreateCommand();
        cmd.CommandText = "CREATE TABLE IF NOT EXISTS SistemaMigracoes (Chave TEXT PRIMARY KEY, ExecutadaEm TEXT NOT NULL);";
        cmd.ExecuteNonQuery();
    }

    private static bool JaExecutada(SqliteConnection connection)
    {
        using var cmd = connection.CreateCommand();
        cmd.CommandText = "SELECT COUNT(*) FROM SistemaMigracoes WHERE Chave=$c;";
        cmd.Parameters.AddWithValue("$c", ChaveMigracao);
        return Convert.ToInt32(cmd.ExecuteScalar(), CultureInfo.InvariantCulture) > 0;
    }

    private static void MarcarExecutada(SqliteConnection connection)
    {
        using var cmd = connection.CreateCommand();
        cmd.CommandText = "INSERT OR IGNORE INTO SistemaMigracoes(Chave,ExecutadaEm) VALUES($c,$d);";
        cmd.Parameters.AddWithValue("$c", ChaveMigracao);
        cmd.Parameters.AddWithValue("$d", DateTime.UtcNow.ToString("O"));
        cmd.ExecuteNonQuery();
    }
}
