using Microsoft.Data.Sqlite;
using System;
using System.Collections.Generic;

namespace FinanceiroMasterPro.Infrastructure.Data;

public sealed class ParcelaGerada
{
    public int Numero { get; set; }
    public int Quantidade { get; set; }
    public DateTime Vencimento { get; set; }
    public decimal Valor { get; set; }
    public long LancamentoId { get; set; }
}

public sealed class ParcelamentoRepository
{

    public HashSet<long> ListarLancamentosParcelados()
    {
        var ids=new HashSet<long>();
        using var connection=new SqliteConnection(DatabaseInitializer.ConnectionString);
        connection.Open();
        using var command=connection.CreateCommand();
        command.CommandText =
        """
        SELECT DISTINCT pi.LancamentoId
        FROM ParcelamentoItens pi
        INNER JOIN Parcelamentos p ON p.Id=pi.ParcelamentoId
        WHERE p.Ativo=1;
        """;
        using var reader=command.ExecuteReader();
        while(reader.Read()) ids.Add(reader.GetInt64(0));
        return ids;
    }

    public List<ParcelaGerada> Gerar(
        Lancamento lancamentoBase,
        int quantidadeParcelas,
        DateTime primeiraData,
        int? intervaloDias = null)
    {
        if (quantidadeParcelas < 2)
            throw new ArgumentException(
                "Informe pelo menos 2 parcelas.");

        if (quantidadeParcelas > 999)
            throw new ArgumentException(
                "A quantidade máxima é de 999 parcelas.");

        if (lancamentoBase.Valor == 0)
            throw new ArgumentException(
                "O valor total deve ser diferente de zero.");

        if (string.IsNullOrWhiteSpace(lancamentoBase.Tipo))
            throw new ArgumentException(
                "Informe o Tipo do lançamento.");

        if (string.IsNullOrWhiteSpace(lancamentoBase.Descricao))
            throw new ArgumentException(
                "Informe a Descrição do lançamento.");

        using var connection =
            new SqliteConnection(
                DatabaseInitializer.ConnectionString);

        connection.Open();

        using var transaction =
            connection.BeginTransaction();

        try
        {
            long parcelamentoId =
                InserirParcelamento(
                    connection,
                    transaction,
                    lancamentoBase,
                    quantidadeParcelas,
                    primeiraData);

            decimal valorTotal =
                decimal.Round(
                    lancamentoBase.Valor,
                    2,
                    MidpointRounding.AwayFromZero);

            decimal valorBase =
                decimal.Round(
                    valorTotal / quantidadeParcelas,
                    2,
                    MidpointRounding.AwayFromZero);

            decimal acumulado = 0m;

            var parcelas =
                new List<ParcelaGerada>();

            for (int numero = 1;
                 numero <= quantidadeParcelas;
                 numero++)
            {
                DateTime vencimento =
                    intervaloDias.HasValue ? primeiraData.AddDays((numero - 1) * intervaloDias.Value) : primeiraData.AddMonths(numero - 1);

                decimal valorParcela;

                if (numero == quantidadeParcelas)
                {
                    // A última parcela recebe eventual
                    // diferença de centavos.
                    valorParcela =
                        valorTotal - acumulado;
                }
                else
                {
                    valorParcela = valorBase;
                    acumulado += valorParcela;
                }

                string descricaoParcela =
                    $"{lancamentoBase.Descricao.Trim()} " +
                    $"({numero}/{quantidadeParcelas})";

                long lancamentoId =
                    InserirLancamento(
                        connection,
                        transaction,
                        lancamentoBase,
                        vencimento,
                        valorParcela,
                        descricaoParcela);

                InserirItem(
                    connection,
                    transaction,
                    parcelamentoId,
                    lancamentoId,
                    numero,
                    quantidadeParcelas,
                    valorParcela,
                    vencimento);

                parcelas.Add(
                    new ParcelaGerada
                    {
                        Numero = numero,
                        Quantidade = quantidadeParcelas,
                        Vencimento = vencimento,
                        Valor = valorParcela,
                        LancamentoId = lancamentoId
                    });
            }

            transaction.Commit();

            return parcelas;
        }
        catch
        {
            transaction.Rollback();
            throw;
        }
    }

    private static long InserirParcelamento(
        SqliteConnection connection,
        SqliteTransaction transaction,
        Lancamento lancamento,
        int quantidadeParcelas,
        DateTime primeiraData)
    {
        using var command =
            connection.CreateCommand();

        command.Transaction = transaction;

        command.CommandText =
        """
        INSERT INTO Parcelamentos
        (
            Tipo,
            Descricao,
            ValorTotal,
            QuantidadeParcelas,
            PrimeiraData,
            Ativo,
            CriadoEm
        )
        VALUES
        (
            $tipo,
            $descricao,
            $valorTotal,
            $quantidade,
            $primeiraData,
            1,
            $criadoEm
        );

        SELECT last_insert_rowid();
        """;

        command.Parameters.AddWithValue(
            "$tipo",
            lancamento.Tipo.Trim());

        command.Parameters.AddWithValue(
            "$descricao",
            lancamento.Descricao.Trim());

        command.Parameters.AddWithValue(
            "$valorTotal",
            lancamento.Valor);

        command.Parameters.AddWithValue(
            "$quantidade",
            quantidadeParcelas);

        command.Parameters.AddWithValue(
            "$primeiraData",
            primeiraData.ToString("O"));

        command.Parameters.AddWithValue(
            "$criadoEm",
            DateTime.UtcNow.ToString("O"));

        return Convert.ToInt64(
            command.ExecuteScalar());
    }

    private static long InserirLancamento(
        SqliteConnection connection,
        SqliteTransaction transaction,
        Lancamento item,
        DateTime vencimento,
        decimal valorParcela,
        string descricaoParcela)
    {
        using var command =
            connection.CreateCommand();

        command.Transaction = transaction;

        command.CommandText =
        """
        INSERT INTO Lancamentos
        (
            Tipo,
            ContaBancariaId,
            DataPagamento,
            DataEmissao,
            ClienteFornecedorId,
            Descricao,
            PlanoContasId,
            CentroCustosId,
            GrupoContasId,
            FluxoCaixaId,
            Valor,
            Periodo,
            Anotacoes,
            Baixado,
            DataBaixa,
            Ativo,
            CriadoEm
        )
        VALUES
        (
            $tipo,
            $contaBancariaId,
            $dataPagamento,
            $dataEmissao,
            $clienteFornecedorId,
            $descricao,
            $planoContasId,
            $centroCustosId,
            $grupoContasId,
            $fluxoCaixaId,
            $valor,
            $periodo,
            $anotacoes,
            0,
            NULL,
            1,
            $criadoEm
        );

        SELECT last_insert_rowid();
        """;

        command.Parameters.AddWithValue(
            "$tipo",
            item.Tipo.Trim());

        command.Parameters.AddWithValue(
            "$contaBancariaId",
            DbValue(item.ContaBancariaId));

        command.Parameters.AddWithValue(
            "$dataPagamento",
            vencimento.ToString("O"));

        command.Parameters.AddWithValue(
            "$dataEmissao",
            item.DataEmissao.ToString("O"));

        command.Parameters.AddWithValue(
            "$clienteFornecedorId",
            DbValue(item.ClienteFornecedorId));

        command.Parameters.AddWithValue(
            "$descricao",
            descricaoParcela);

        command.Parameters.AddWithValue(
            "$planoContasId",
            DbValue(item.PlanoContasId));

        command.Parameters.AddWithValue(
            "$centroCustosId",
            DbValue(item.CentroCustosId));

        command.Parameters.AddWithValue(
            "$grupoContasId",
            DbValue(item.GrupoContasId));

        command.Parameters.AddWithValue(
            "$fluxoCaixaId",
            DbValue(item.FluxoCaixaId));

        command.Parameters.AddWithValue(
            "$valor",
            valorParcela);

        command.Parameters.AddWithValue(
            "$periodo",
            "");

        command.Parameters.AddWithValue(
            "$anotacoes",
            item.Anotacoes?.Trim() ?? "");

        command.Parameters.AddWithValue(
            "$criadoEm",
            DateTime.UtcNow.ToString("O"));

        return Convert.ToInt64(
            command.ExecuteScalar());
    }

    private static void InserirItem(
        SqliteConnection connection,
        SqliteTransaction transaction,
        long parcelamentoId,
        long lancamentoId,
        int numero,
        int quantidade,
        decimal valor,
        DateTime vencimento)
    {
        using var command =
            connection.CreateCommand();

        command.Transaction = transaction;

        command.CommandText =
        """
        INSERT INTO ParcelamentoItens
        (
            ParcelamentoId,
            LancamentoId,
            NumeroParcela,
            QuantidadeParcelas,
            ValorParcela,
            DataVencimento,
            CriadoEm
        )
        VALUES
        (
            $parcelamentoId,
            $lancamentoId,
            $numero,
            $quantidade,
            $valor,
            $vencimento,
            $criadoEm
        );
        """;

        command.Parameters.AddWithValue(
            "$parcelamentoId",
            parcelamentoId);

        command.Parameters.AddWithValue(
            "$lancamentoId",
            lancamentoId);

        command.Parameters.AddWithValue(
            "$numero",
            numero);

        command.Parameters.AddWithValue(
            "$quantidade",
            quantidade);

        command.Parameters.AddWithValue(
            "$valor",
            valor);

        command.Parameters.AddWithValue(
            "$vencimento",
            vencimento.ToString("O"));

        command.Parameters.AddWithValue(
            "$criadoEm",
            DateTime.UtcNow.ToString("O"));

        command.ExecuteNonQuery();
    }

    private static object DbValue(long? valor)
    {
        return valor.HasValue
            ? valor.Value
            : DBNull.Value;
    }
}