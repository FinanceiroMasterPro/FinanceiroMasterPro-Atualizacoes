using FinanceiroMasterPro.Application.Contracts;
namespace FinanceiroMasterPro.Infrastructure.Data;
public sealed class InMemoryRepository<T> : IRepository<T> where T:class { private readonly List<T> _items=[]; private readonly Func<T,Guid> _id; public InMemoryRepository(Func<T,Guid> id)=>_id=id; public IReadOnlyList<T> Listar()=>_items.ToList(); public T? Obter(Guid id)=>_items.FirstOrDefault(x=>_id(x)==id); public void Salvar(T item){var i=_items.FindIndex(x=>_id(x)==_id(item)); if(i>=0)_items[i]=item;else _items.Add(item);} public void Excluir(Guid id)=>_items.RemoveAll(x=>_id(x)==id); }
