using Microsoft.Data.Sqlite;
using System;
using System.Collections.Generic;

namespace FinanceiroMasterPro.Infrastructure.Data;

public sealed class Lancamento
{
    public long Id { get; set; }
    public string Tipo { get; set; } = "";

    public long? ContaBancariaId { get; set; }
    public string ContaBancariaNome { get; set; } = "";

    public DateTime? DataPagamento { get; set; }
    public DateTime DataEmissao { get; set; } = DateTime.Today;

    public long? ClienteFornecedorId { get; set; }
    public string ClienteFornecedorNome { get; set; } = "";

    public string Descricao { get; set; } = "";
    public string NumeroDocumento { get; set; } = "";

    public long? PlanoContasId { get; set; }
    public string PlanoContasNome { get; set; } = "";

    public long? CentroCustosId { get; set; }
    public string CentroCustosNome { get; set; } = "";

    public long? GrupoContasId { get; set; }
    public string GrupoContasNome { get; set; } = "";

    public long? FluxoCaixaId { get; set; }
    public string FluxoCaixaNome { get; set; } = "";

    public decimal Valor { get; set; }
    public string ValorExibicaoSemSinal => Math.Abs(Valor).ToString("N2", System.Globalization.CultureInfo.GetCultureInfo("pt-BR"));

    public string Periodo { get; set; } = "";
    public string Anotacoes { get; set; } = "";

    public bool Baixado { get; set; }
    public DateTime? DataBaixa { get; set; }

    public bool Ativo { get; set; } = true;

    // Somente para exibição na grade; não é gravado em Lancamentos.
    public bool PossuiRateio { get; set; }
    public int NumeroRateio { get; set; }
    public bool PossuiParcelamento { get; set; }
    public string PeriodoExibicao => Baixado ? Periodo : "";
    public string TipoExibicao => Baixado
        ? (Tipo.Equals("Pagar", StringComparison.OrdinalIgnoreCase) ? "Pago"
            : Tipo.Equals("Receber", StringComparison.OrdinalIgnoreCase) ? "Recebido" : Tipo)
        : Tipo;
    public string IdentificacaoAgrupamento =>
        PossuiParcelamento ? "PARCELADO" :
        PossuiRateio ? $"RATEADO {Math.Max(1, NumeroRateio):00}" : "";
}

public sealed class LancamentoRepository
{
    public List<Lancamento> Listar()
    {
        var itens = new List<Lancamento>();

        using var connection =
            new SqliteConnection(DatabaseInitializer.ConnectionString);

        connection.Open();

        using var command = connection.CreateCommand();

        command.CommandText =
        """
        SELECT
            l.Id,
            l.Tipo,
            l.ContaBancariaId,
            COALESCE(cb.Nome, ''),
            l.DataPagamento,
            l.DataEmissao,
            l.ClienteFornecedorId,
            COALESCE(cf.Nome, ''),
            l.Descricao,
            COALESCE(l.NumeroDocumento, ''),
            l.PlanoContasId,
            COALESCE(pc.Nome, ''),
            l.CentroCustosId,
            COALESCE(cc.Nome, ''),
            l.GrupoContasId,
            COALESCE(gc.Nome, ''),
            l.FluxoCaixaId,
            COALESCE(fc.Nome, ''),
            l.Valor,
            COALESCE(l.Periodo, ''),
            COALESCE(l.Anotacoes, ''),
            l.Baixado,
            l.DataBaixa,
            l.Ativo

        FROM Lancamentos l

        LEFT JOIN ContasBancarias cb
            ON cb.Id = l.ContaBancariaId

        LEFT JOIN ClientesFornecedores cf
            ON cf.Id = l.ClienteFornecedorId

        LEFT JOIN PlanosContas pc
            ON pc.Id = l.PlanoContasId

        LEFT JOIN CentrosCustos cc
            ON cc.Id = l.CentroCustosId

        LEFT JOIN GruposContas gc
            ON gc.Id = l.GrupoContasId

        LEFT JOIN FluxosCaixa fc
            ON fc.Id = l.FluxoCaixaId

        ORDER BY
            l.DataPagamento DESC,
            l.Id DESC;
        """;

        using var reader = command.ExecuteReader();

        while (reader.Read())
        {
            itens.Add(new Lancamento
            {
                Id = reader.GetInt64(0),
                Tipo = reader.GetString(1),

                ContaBancariaId =
                    reader.IsDBNull(2) ? null : reader.GetInt64(2),

                ContaBancariaNome = reader.GetString(3),

                DataPagamento = LerData(reader, 4),

                DataEmissao =
                    LerData(reader, 5) ?? DateTime.Today,

                ClienteFornecedorId =
                    reader.IsDBNull(6) ? null : reader.GetInt64(6),

                ClienteFornecedorNome = reader.GetString(7),

                Descricao = reader.GetString(8),
                NumeroDocumento = reader.GetString(9),

                PlanoContasId = reader.IsDBNull(10) ? null : reader.GetInt64(10),
                PlanoContasNome = reader.GetString(11),
                CentroCustosId = reader.IsDBNull(12) ? null : reader.GetInt64(12),
                CentroCustosNome = reader.GetString(13),
                GrupoContasId = reader.IsDBNull(14) ? null : reader.GetInt64(14),
                GrupoContasNome = reader.GetString(15),
                FluxoCaixaId = reader.IsDBNull(16) ? null : reader.GetInt64(16),
                FluxoCaixaNome = reader.GetString(17),
                Valor = Convert.ToDecimal(reader.GetDouble(18)),
                Periodo = reader.GetString(19),
                Anotacoes = reader.GetString(20),
                Baixado = reader.GetInt64(21) == 1,
                DataBaixa = LerData(reader, 22),
                Ativo = reader.GetInt64(23) == 1
            });
        }

        return itens;
    }

    // Leitura enxuta usada exclusivamente pelo DFC CAIXA.
    // Evita carregar colunas e relacionamentos que o DFC não utiliza e já filtra no SQLite
    // somente os lançamentos ativos, baixados e com data de pagamento.
    public List<Lancamento> ListarDfc()
    {
        var itens = new List<Lancamento>();

        using var connection = new SqliteConnection(DatabaseInitializer.ConnectionString);
        connection.Open();
        using var command = connection.CreateCommand();
        command.CommandText =
        """
        SELECT
            l.Id,
            l.Tipo,
            l.DataPagamento,
            COALESCE(pc.Nome, ''),
            COALESCE(gc.Nome, ''),
            COALESCE(fc.Nome, ''),
            l.Valor
        FROM Lancamentos l
        LEFT JOIN PlanosContas pc ON pc.Id = l.PlanoContasId
        LEFT JOIN GruposContas gc ON gc.Id = l.GrupoContasId
        LEFT JOIN FluxosCaixa fc ON fc.Id = l.FluxoCaixaId
        WHERE l.Ativo = 1
          AND l.Baixado = 1
          AND l.DataPagamento IS NOT NULL
        ORDER BY l.DataPagamento DESC, l.Id DESC;
        """;

        using var reader = command.ExecuteReader();
        while (reader.Read())
        {
            itens.Add(new Lancamento
            {
                Id = reader.GetInt64(0),
                Tipo = reader.GetString(1),
                DataPagamento = LerData(reader, 2),
                PlanoContasNome = reader.GetString(3),
                GrupoContasNome = reader.GetString(4),
                FluxoCaixaNome = reader.GetString(5),
                Valor = Convert.ToDecimal(reader.GetDouble(6)),
                Baixado = true,
                Ativo = true
            });
        }
        return itens;
    }

    public long Salvar(Lancamento item)
    {
        Validar(item);

        using var connection =
            new SqliteConnection(DatabaseInitializer.ConnectionString);

        connection.Open();

        if (item.Id == 0)
            return Inserir(connection, item);

        Atualizar(connection, item);

        return item.Id;
    }

    private static void Validar(Lancamento item)
    {
        if (string.IsNullOrWhiteSpace(item.Tipo))
            throw new ArgumentException(
                "Informe o Tipo do lançamento.");

        if (string.IsNullOrWhiteSpace(item.Descricao))
            throw new ArgumentException(
                "Informe a Descrição do lançamento.");

        if (item.Valor == 0)
            throw new ArgumentException(
                "Informe um Valor diferente de zero.");
    }

    private static long Inserir(
        SqliteConnection connection,
        Lancamento item)
    {
        using var command = connection.CreateCommand();

        command.CommandText =
        """
        INSERT INTO Lancamentos
        (
            Tipo,
            ContaBancariaId,
            DataPagamento,
            DataEmissao,
            ClienteFornecedorId,
            Descricao,
            NumeroDocumento,
            PlanoContasId,
            CentroCustosId,
            GrupoContasId,
            FluxoCaixaId,
            Valor,
            Periodo,
            Anotacoes,
            Baixado,
            DataBaixa,
            Ativo,
            CriadoEm
        )
        VALUES
        (
            $tipo,
            $contaBancariaId,
            $dataPagamento,
            $dataEmissao,
            $clienteFornecedorId,
            $descricao,
            $numeroDocumento,
            $planoContasId,
            $centroCustosId,
            $grupoContasId,
            $fluxoCaixaId,
            $valor,
            $periodo,
            $anotacoes,
            $baixado,
            $dataBaixa,
            $ativo,
            $criadoEm
        );

        SELECT last_insert_rowid();
        """;

        PreencherParametros(command, item);

        command.Parameters.AddWithValue(
            "$criadoEm",
            DateTime.UtcNow.ToString("O"));

        return Convert.ToInt64(command.ExecuteScalar());
    }

    private static void Atualizar(
        SqliteConnection connection,
        Lancamento item)
    {
        using var command = connection.CreateCommand();

        command.CommandText =
        """
        UPDATE Lancamentos
        SET
            Tipo = $tipo,
            ContaBancariaId = $contaBancariaId,
            DataPagamento = $dataPagamento,
            DataEmissao = $dataEmissao,
            ClienteFornecedorId = $clienteFornecedorId,
            Descricao = $descricao,
            NumeroDocumento = $numeroDocumento,
            PlanoContasId = $planoContasId,
            CentroCustosId = $centroCustosId,
            GrupoContasId = $grupoContasId,
            FluxoCaixaId = $fluxoCaixaId,
            Valor = $valor,
            Periodo = $periodo,
            Anotacoes = $anotacoes,
            Baixado = $baixado,
            DataBaixa = $dataBaixa,
            Ativo = $ativo,
            AlteradoEm = $alteradoEm
        WHERE Id = $id;
        """;

        PreencherParametros(command, item);

        command.Parameters.AddWithValue("$id", item.Id);

        command.Parameters.AddWithValue(
            "$alteradoEm",
            DateTime.UtcNow.ToString("O"));

        command.ExecuteNonQuery();
    }

    private static void PreencherParametros(
        SqliteCommand command,
        Lancamento item)
    {
        command.Parameters.AddWithValue(
            "$tipo",
            item.Tipo.Trim());

        command.Parameters.AddWithValue(
            "$contaBancariaId",
            ValorOuDbNull(item.ContaBancariaId));

        command.Parameters.AddWithValue(
            "$dataPagamento",
            DataOuDbNull(item.DataPagamento));

        command.Parameters.AddWithValue(
            "$dataEmissao",
            item.DataEmissao.ToString("O"));

        command.Parameters.AddWithValue(
            "$clienteFornecedorId",
            ValorOuDbNull(item.ClienteFornecedorId));

        command.Parameters.AddWithValue(
            "$descricao",
            item.Descricao.Trim());

        command.Parameters.AddWithValue("$numeroDocumento", item.NumeroDocumento?.Trim() ?? "");

        command.Parameters.AddWithValue(
            "$planoContasId",
            ValorOuDbNull(item.PlanoContasId));

        command.Parameters.AddWithValue(
            "$centroCustosId",
            ValorOuDbNull(item.CentroCustosId));

        command.Parameters.AddWithValue(
            "$grupoContasId",
            ValorOuDbNull(item.GrupoContasId));

        command.Parameters.AddWithValue(
            "$fluxoCaixaId",
            ValorOuDbNull(item.FluxoCaixaId));

        command.Parameters.AddWithValue(
            "$valor",
            item.Valor);

        command.Parameters.AddWithValue(
            "$periodo",
            item.Periodo?.Trim() ?? "");

        command.Parameters.AddWithValue(
            "$anotacoes",
            item.Anotacoes?.Trim() ?? "");

        command.Parameters.AddWithValue(
            "$baixado",
            item.Baixado ? 1 : 0);

        command.Parameters.AddWithValue(
            "$dataBaixa",
            DataOuDbNull(item.DataBaixa));

        command.Parameters.AddWithValue(
            "$ativo",
            item.Ativo ? 1 : 0);
    }

    public void AlterarBaixa(
        long id,
        bool baixado,
        DateTime? dataBaixa)
    {
        using var connection =
            new SqliteConnection(DatabaseInitializer.ConnectionString);

        connection.Open();

        using var command = connection.CreateCommand();

        string periodo =
            baixado && dataBaixa.HasValue
                ? dataBaixa.Value.ToString("MM/yyyy")
                : "";

        command.CommandText =
        """
        UPDATE Lancamentos
        SET
            Baixado = $baixado,
            DataBaixa = $dataBaixa,
            Periodo = $periodo,
            AlteradoEm = $alteradoEm
        WHERE Id = $id;
        """;

        command.Parameters.AddWithValue("$id", id);

        command.Parameters.AddWithValue(
            "$baixado",
            baixado ? 1 : 0);

        command.Parameters.AddWithValue(
            "$dataBaixa",
            DataOuDbNull(dataBaixa));

        command.Parameters.AddWithValue(
            "$periodo",
            periodo);

        command.Parameters.AddWithValue(
            "$alteradoEm",
            DateTime.UtcNow.ToString("O"));

        command.ExecuteNonQuery();
    }

    // =========================================================
    // EXCLUSÃO INDIVIDUAL
    // =========================================================
    public int Excluir(long id)
    {
        if (id <= 0)
            return 0;

        return ExcluirInterno(
            "l.Id = $id",
            command =>
            {
                command.Parameters.AddWithValue("$id", id);
            });
    }

    // =========================================================
    // CONTAGEM POR ANO
    // Usa DATA PAGAMENTO.
    // =========================================================
    public int ContarPorAno(int ano)
    {
        DateTime inicio = new(ano, 1, 1);
        DateTime fim = inicio.AddYears(1);

        return ContarPeriodo(inicio, fim);
    }

    // =========================================================
    // CONTAGEM POR MÊS
    // =========================================================
    public int ContarPorMes(int ano, int mes)
    {
        DateTime inicio = new(ano, mes, 1);
        DateTime fim = inicio.AddMonths(1);

        return ContarPeriodo(inicio, fim);
    }

    // =========================================================
    // CONTAGEM POR PERÍODO
    // =========================================================
    public int ContarPorPeriodo(
        DateTime inicio,
        DateTime fimInclusive)
    {
        DateTime fimExclusivo =
            fimInclusive.Date.AddDays(1);

        return ContarPeriodo(
            inicio.Date,
            fimExclusivo);
    }

    public int ContarTodos()
    {
        using var connection =
            new SqliteConnection(DatabaseInitializer.ConnectionString);

        connection.Open();

        using var command = connection.CreateCommand();

        command.CommandText =
            "SELECT COUNT(*) FROM Lancamentos;";

        return Convert.ToInt32(
            command.ExecuteScalar());
    }

    private static int ContarPeriodo(
        DateTime inicio,
        DateTime fimExclusivo)
    {
        using var connection =
            new SqliteConnection(DatabaseInitializer.ConnectionString);

        connection.Open();

        using var command = connection.CreateCommand();

        command.CommandText =
        """
        SELECT COUNT(*)
        FROM Lancamentos
        WHERE
            DataPagamento >= $inicio
            AND DataPagamento < $fim;
        """;

        command.Parameters.AddWithValue(
            "$inicio",
            inicio.ToString("O"));

        command.Parameters.AddWithValue(
            "$fim",
            fimExclusivo.ToString("O"));

        return Convert.ToInt32(
            command.ExecuteScalar());
    }

    // =========================================================
    // APAGAR POR ANO
    // =========================================================
    public int ExcluirPorAno(int ano)
    {
        DateTime inicio = new(ano, 1, 1);
        DateTime fim = inicio.AddYears(1);

        return ExcluirPorIntervalo(
            inicio,
            fim);
    }

    // =========================================================
    // APAGAR POR MÊS
    // =========================================================
    public int ExcluirPorMes(
        int ano,
        int mes)
    {
        DateTime inicio = new(ano, mes, 1);
        DateTime fim = inicio.AddMonths(1);

        return ExcluirPorIntervalo(
            inicio,
            fim);
    }

    // =========================================================
    // APAGAR PERÍODO X A X
    // =========================================================
    public int ExcluirPorPeriodo(
        DateTime inicio,
        DateTime fimInclusive)
    {
        return ExcluirPorIntervalo(
            inicio.Date,
            fimInclusive.Date.AddDays(1));
    }

    // =========================================================
    // APAGAR TUDO
    // =========================================================
    public int ExcluirTodos()
    {
        return ExcluirInterno(
            "1 = 1",
            _ => { });
    }

    private int ExcluirPorIntervalo(
        DateTime inicio,
        DateTime fimExclusivo)
    {
        return ExcluirInterno(
            """
            l.DataPagamento >= $inicio
            AND l.DataPagamento < $fim
            """,
            command =>
            {
                command.Parameters.AddWithValue(
                    "$inicio",
                    inicio.ToString("O"));

                command.Parameters.AddWithValue(
                    "$fim",
                    fimExclusivo.ToString("O"));
            });
    }

    // =========================================================
    // EXCLUSÃO SEGURA
    // RATEIOS + PARCELAMENTOS + LANÇAMENTOS
    // =========================================================
    private static int ExcluirInterno(
        string condicao,
        Action<SqliteCommand> preencherFiltro)
    {
        using var connection =
            new SqliteConnection(DatabaseInitializer.ConnectionString);

        connection.Open();

        using var transaction =
            connection.BeginTransaction();

        try
        {
            // Guarda os IDs que serão eliminados.
            using (var temp = connection.CreateCommand())
            {
                temp.Transaction = transaction;

                temp.CommandText =
                """
                CREATE TEMP TABLE IF NOT EXISTS
                    LancamentosExcluir
                (
                    Id INTEGER PRIMARY KEY
                );

                DELETE FROM LancamentosExcluir;
                """;

                temp.ExecuteNonQuery();
            }

            using (var selecionar = connection.CreateCommand())
            {
                selecionar.Transaction = transaction;

                selecionar.CommandText =
                    $"""
                    INSERT INTO LancamentosExcluir (Id)
                    SELECT l.Id
                    FROM Lancamentos l
                    WHERE {condicao};
                    """;

                preencherFiltro(selecionar);
                selecionar.ExecuteNonQuery();
            }

            int quantidade;

            using (var contar = connection.CreateCommand())
            {
                contar.Transaction = transaction;

                contar.CommandText =
                    """
                    SELECT COUNT(*)
                    FROM LancamentosExcluir;
                    """;

                quantidade =
                    Convert.ToInt32(
                        contar.ExecuteScalar());
            }

            if (quantidade == 0)
            {
                transaction.Commit();
                return 0;
            }

            // 1. ITENS DOS RATEIOS
            using (var command = connection.CreateCommand())
            {
                command.Transaction = transaction;

                command.CommandText =
                    """
                    DELETE FROM RateioItens
                    WHERE RateioId IN
                    (
                        SELECT Id
                        FROM Rateios
                        WHERE LancamentoId IN
                        (
                            SELECT Id
                            FROM LancamentosExcluir
                        )
                    );
                    """;

                command.ExecuteNonQuery();
            }

            // 2. RATEIOS
            using (var command = connection.CreateCommand())
            {
                command.Transaction = transaction;

                command.CommandText =
                    """
                    DELETE FROM Rateios
                    WHERE LancamentoId IN
                    (
                        SELECT Id
                        FROM LancamentosExcluir
                    );
                    """;

                command.ExecuteNonQuery();
            }

            // 3. ITENS DE PARCELAMENTOS
            using (var command = connection.CreateCommand())
            {
                command.Transaction = transaction;

                command.CommandText =
                    """
                    DELETE FROM ParcelamentoItens
                    WHERE LancamentoId IN
                    (
                        SELECT Id
                        FROM LancamentosExcluir
                    );
                    """;

                command.ExecuteNonQuery();
            }

            // 4. REMOVE PARCELAMENTOS QUE FICARAM SEM PARCELAS
            using (var command = connection.CreateCommand())
            {
                command.Transaction = transaction;

                command.CommandText =
                    """
                    DELETE FROM Parcelamentos
                    WHERE Id NOT IN
                    (
                        SELECT DISTINCT ParcelamentoId
                        FROM ParcelamentoItens
                    );
                    """;

                command.ExecuteNonQuery();
            }

            // 5. LANÇAMENTOS
            using (var command = connection.CreateCommand())
            {
                command.Transaction = transaction;

                command.CommandText =
                    """
                    DELETE FROM Lancamentos
                    WHERE Id IN
                    (
                        SELECT Id
                        FROM LancamentosExcluir
                    );
                    """;

                command.ExecuteNonQuery();
            }

            using (var limpar = connection.CreateCommand())
            {
                limpar.Transaction = transaction;

                limpar.CommandText =
                    "DELETE FROM LancamentosExcluir;";

                limpar.ExecuteNonQuery();
            }

            transaction.Commit();

            return quantidade;
        }
        catch
        {
            transaction.Rollback();
            throw;
        }
    }

    private static object ValorOuDbNull(long? valor)
    {
        return valor.HasValue
            ? valor.Value
            : DBNull.Value;
    }

    private static object DataOuDbNull(DateTime? data)
    {
        return data.HasValue
            ? data.Value.ToString("O")
            : DBNull.Value;
    }

    private static DateTime? LerData(
        SqliteDataReader reader,
        int indice)
    {
        if (reader.IsDBNull(indice))
            return null;

        string texto =
            reader.GetString(indice);

        if (DateTime.TryParse(
                texto,
                out DateTime data))
        {
            return data;
        }

        return null;
    }
}