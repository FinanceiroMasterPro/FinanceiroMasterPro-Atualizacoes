using Microsoft.Data.Sqlite;
using System;
using System.Collections.Generic;

namespace FinanceiroMasterPro.Infrastructure.Data;

public sealed class CentroCustos
{
    public long Id { get; set; }
    public string Nome { get; set; } = "";
    public bool Ativo { get; set; } = true;

    public override string ToString() => Nome;
}

public sealed class CentroCustosRepository
{
    public List<CentroCustos> Listar()
    {
        var itens = new List<CentroCustos>();

        using var connection =
            new SqliteConnection(DatabaseInitializer.ConnectionString);

        connection.Open();

        using var command = connection.CreateCommand();

        command.CommandText =
        """
        SELECT Id, Nome, Ativo
        FROM CentrosCustos
        ORDER BY Nome;
        """;

        using var reader = command.ExecuteReader();

        while (reader.Read())
        {
            itens.Add(new CentroCustos
            {
                Id = reader.GetInt64(0),
                Nome = reader.GetString(1),
                Ativo = reader.GetInt64(2) == 1
            });
        }

        return itens;
    }

    public long Salvar(CentroCustos item)
    {
        if (string.IsNullOrWhiteSpace(item.Nome))
            throw new ArgumentException(
                "Informe o nome do Centro de Custos.");

        using var connection =
            new SqliteConnection(DatabaseInitializer.ConnectionString);

        connection.Open();

        if (item.Id == 0)
            return Inserir(connection, item);

        Atualizar(connection, item);

        return item.Id;
    }

    private static long Inserir(
        SqliteConnection connection,
        CentroCustos item)
    {
        using var command = connection.CreateCommand();

        command.CommandText =
        """
        INSERT INTO CentrosCustos
        (
            Nome,
            Ativo,
            CriadoEm
        )
        VALUES
        (
            $nome,
            $ativo,
            $criadoEm
        );

        SELECT last_insert_rowid();
        """;

        command.Parameters.AddWithValue(
            "$nome",
            item.Nome.Trim());

        command.Parameters.AddWithValue(
            "$ativo",
            item.Ativo ? 1 : 0);

        command.Parameters.AddWithValue(
            "$criadoEm",
            DateTime.UtcNow.ToString("O"));

        return Convert.ToInt64(
            command.ExecuteScalar());
    }

    private static void Atualizar(
        SqliteConnection connection,
        CentroCustos item)
    {
        using var command = connection.CreateCommand();

        command.CommandText =
        """
        UPDATE CentrosCustos
        SET
            Nome = $nome,
            Ativo = $ativo,
            AlteradoEm = $alteradoEm
        WHERE Id = $id;
        """;

        command.Parameters.AddWithValue("$id", item.Id);
        command.Parameters.AddWithValue("$nome", item.Nome.Trim());
        command.Parameters.AddWithValue("$ativo", item.Ativo ? 1 : 0);
        command.Parameters.AddWithValue(
            "$alteradoEm",
            DateTime.UtcNow.ToString("O"));

        command.ExecuteNonQuery();
    }

    public void AlterarStatus(long id, bool ativo)
    {
        using var connection =
            new SqliteConnection(DatabaseInitializer.ConnectionString);

        connection.Open();

        using var command = connection.CreateCommand();

        command.CommandText =
        """
        UPDATE CentrosCustos
        SET
            Ativo = $ativo,
            AlteradoEm = $alteradoEm
        WHERE Id = $id;
        """;

        command.Parameters.AddWithValue("$id", id);
        command.Parameters.AddWithValue("$ativo", ativo ? 1 : 0);
        command.Parameters.AddWithValue(
            "$alteradoEm",
            DateTime.UtcNow.ToString("O"));

        command.ExecuteNonQuery();
    }

    public void Excluir(long id)
    {
        using var connection = new SqliteConnection(DatabaseInitializer.ConnectionString);
        connection.Open();

        using (var check = connection.CreateCommand())
        {
            check.CommandText = "SELECT COUNT(*) FROM Lancamentos WHERE CentroCustosId = $id;";
            check.Parameters.AddWithValue("$id", id);
            var total = Convert.ToInt32(check.ExecuteScalar());
            if (total > 0)
                throw new InvalidOperationException($"Este cadastro está sendo utilizado em {total} lançamento(s). Localize e altere/exclua esses lançamentos antes de excluir o cadastro.");
        }

        using var command = connection.CreateCommand();
        command.CommandText = "DELETE FROM CentrosCustos WHERE Id = $id;";
        command.Parameters.AddWithValue("$id", id);
        command.ExecuteNonQuery();
    }
}