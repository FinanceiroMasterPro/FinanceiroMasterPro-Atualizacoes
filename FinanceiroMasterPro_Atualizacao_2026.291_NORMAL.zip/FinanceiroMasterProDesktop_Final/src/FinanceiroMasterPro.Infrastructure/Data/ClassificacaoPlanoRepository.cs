using Microsoft.Data.Sqlite;
namespace FinanceiroMasterPro.Infrastructure.Data;

public sealed class ClassificacaoPlano
{
    public long Id { get; set; }
    public long PlanoContasId { get; set; }
    public long GrupoContasId { get; set; }
    public long FluxoCaixaId { get; set; }
    public long? CentroCustosId { get; set; }
    public string PlanoNome { get; set; } = "";
    public string GrupoNome { get; set; } = "";
    public string FluxoNome { get; set; } = "";
    public string CentroNome { get; set; } = "";
    public string Resumo => $"{GrupoNome} — {FluxoNome}";
}
public sealed class ClassificacaoPlanoRepository
{
    public ClassificacaoPlanoRepository(){GarantirTabela();}
    void GarantirTabela(){
      using var c=new SqliteConnection(DatabaseInitializer.ConnectionString);c.Open();
      using var q=c.CreateCommand();q.CommandText = @"CREATE TABLE IF NOT EXISTS PlanoClassificacoes(
        Id INTEGER PRIMARY KEY AUTOINCREMENT,
        PlanoContasId INTEGER NOT NULL,
        GrupoContasId INTEGER NOT NULL,
        FluxoCaixaId INTEGER NOT NULL,
        CriadoEm TEXT NOT NULL,
        UNIQUE(PlanoContasId,GrupoContasId,FluxoCaixaId)
      );";q.ExecuteNonQuery();
      try{using var a=c.CreateCommand();a.CommandText="ALTER TABLE PlanoClassificacoes ADD COLUMN CentroCustosId INTEGER NULL;";a.ExecuteNonQuery();}catch{}
    }
    public List<ClassificacaoPlano> Listar(long? planoId=null){
      using var c=new SqliteConnection(DatabaseInitializer.ConnectionString);c.Open();
      using var q=c.CreateCommand();q.CommandText = @"SELECT pc.Id,pc.PlanoContasId,pc.GrupoContasId,pc.FluxoCaixaId,
             p.Nome,g.Nome,f.Nome,pc.CentroCustosId,COALESCE(cc.Nome,'')
      FROM PlanoClassificacoes pc
      JOIN PlanosContas p ON p.Id=pc.PlanoContasId
      JOIN GruposContas g ON g.Id=pc.GrupoContasId
      JOIN FluxosCaixa f ON f.Id=pc.FluxoCaixaId
      LEFT JOIN CentrosCustos cc ON cc.Id=pc.CentroCustosId
      WHERE ($plano IS NULL OR pc.PlanoContasId=$plano)
      ORDER BY p.Nome,f.Nome,g.Nome;";
      q.Parameters.AddWithValue("$plano",(object?)planoId??DBNull.Value);
      var r=new List<ClassificacaoPlano>();using var rd=q.ExecuteReader();
      while(rd.Read())r.Add(new(){Id=rd.GetInt64(0),PlanoContasId=rd.GetInt64(1),GrupoContasId=rd.GetInt64(2),FluxoCaixaId=rd.GetInt64(3),PlanoNome=rd.GetString(4),GrupoNome=rd.GetString(5),FluxoNome=rd.GetString(6),CentroCustosId=rd.IsDBNull(7)?null:rd.GetInt64(7),CentroNome=rd.GetString(8)});
      return r;
    }
    public void Salvar(long plano,long grupo,long fluxo,long? centro=null,long? id=null){
      using var c=new SqliteConnection(DatabaseInitializer.ConnectionString);c.Open();
      using var q=c.CreateCommand();
      if(id.HasValue){q.CommandText="UPDATE PlanoClassificacoes SET PlanoContasId=$p,GrupoContasId=$g,FluxoCaixaId=$f,CentroCustosId=$c WHERE Id=$id;";q.Parameters.AddWithValue("$id",id.Value);}
      else q.CommandText="INSERT OR IGNORE INTO PlanoClassificacoes(PlanoContasId,GrupoContasId,FluxoCaixaId,CentroCustosId,CriadoEm) VALUES($p,$g,$f,$c,$d);";
      q.Parameters.AddWithValue("$p",plano);q.Parameters.AddWithValue("$g",grupo);q.Parameters.AddWithValue("$f",fluxo);q.Parameters.AddWithValue("$c",(object?)centro??DBNull.Value);q.Parameters.AddWithValue("$d",DateTime.UtcNow.ToString("O"));q.ExecuteNonQuery();
    }
    public void Excluir(long id){using var c=new SqliteConnection(DatabaseInitializer.ConnectionString);c.Open();using var q=c.CreateCommand();q.CommandText="DELETE FROM PlanoClassificacoes WHERE Id=$id;";q.Parameters.AddWithValue("$id",id);q.ExecuteNonQuery();}
}