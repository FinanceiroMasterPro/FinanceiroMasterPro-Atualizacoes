using Microsoft.Data.Sqlite;
using System;
using System.Collections.Generic;
using System.Linq;

namespace FinanceiroMasterPro.Infrastructure.Data;

public sealed class RateioItem
{
    public long PlanoContasId { get; set; }
    public string PlanoContasNome { get; set; } = "";
    public long? CentroCustosId { get; set; }
    public string CentroCustosNome { get; set; } = "";

    public decimal Percentual { get; set; }

    public decimal Valor { get; set; }
    public string ValorExibicaoSemSinal => Math.Abs(Valor).ToString("N2", System.Globalization.CultureInfo.GetCultureInfo("pt-BR"));
}

public sealed class RateioResumo
{
    public long LancamentoId { get; set; }
    public DateTime? DataPagamento { get; set; }
    public string ClienteFornecedor { get; set; } = "";
    public string Descricao { get; set; } = "";
    public decimal ValorOriginal { get; set; }
    public int QuantidadeItens { get; set; }
    public decimal TotalRateado { get; set; }
    public List<RateioItem> Itens { get; set; } = new();
    public string ValorOriginalBr => Math.Abs(ValorOriginal).ToString("N2", new System.Globalization.CultureInfo("pt-BR"));
    public string TotalRateadoBr => Math.Abs(TotalRateado).ToString("N2", new System.Globalization.CultureInfo("pt-BR"));
}

public sealed class RateioRepository
{
    public long Salvar(
        long lancamentoId,
        decimal valorTotal,
        IEnumerable<RateioItem> itens)
    {
        if (lancamentoId <= 0)
        {
            throw new ArgumentException(
                "O lançamento precisa estar salvo antes do rateio.");
        }

        if (valorTotal == 0)
        {
            throw new ArgumentException(
                "O valor do lançamento deve ser maior que zero.");
        }

        var lista = itens?.ToList()
            ?? new List<RateioItem>();

        if (lista.Count < 1)
        {
            throw new ArgumentException("Informe pelo menos 1 item para realizar o rateio.");
        }

        ValidarItens(
            valorTotal,
            lista);

        using var connection =
            new SqliteConnection(
                DatabaseInitializer.ConnectionString);

        connection.Open();
        GarantirColunas(connection);

        using var transaction =
            connection.BeginTransaction();

        try
        {
            ExcluirRateioAnterior(
                connection,
                transaction,
                lancamentoId);

            long rateioId =
                InserirRateio(
                    connection,
                    transaction,
                    lancamentoId,
                    valorTotal);

            foreach (var item in lista)
            {
                InserirItem(
                    connection,
                    transaction,
                    rateioId,
                    item);
            }

            transaction.Commit();

            return rateioId;
        }
        catch
        {
            transaction.Rollback();
            throw;
        }
    }

    public List<RateioItem> ListarPorLancamento(
        long lancamentoId)
    {
        var itens =
            new List<RateioItem>();

        using var connection =
            new SqliteConnection(
                DatabaseInitializer.ConnectionString);

        connection.Open();
        GarantirColunas(connection);

        using var command =
            connection.CreateCommand();

        command.CommandText =
        """
        SELECT ri.PlanoContasId, COALESCE(pc.Nome,''), ri.CentroCustosId, COALESCE(cc.Nome,''), ri.Percentual, ri.Valor
        FROM RateioItens ri
        INNER JOIN Rateios r ON r.Id=ri.RateioId
        LEFT JOIN PlanosContas pc ON pc.Id=ri.PlanoContasId
        LEFT JOIN CentrosCustos cc ON cc.Id=ri.CentroCustosId
        WHERE r.LancamentoId=$lancamentoId AND r.Ativo=1
        ORDER BY ri.Id;
        """;

        command.Parameters.AddWithValue(
            "$lancamentoId",
            lancamentoId);

        using var reader =
            command.ExecuteReader();

        while (reader.Read())
        {
            itens.Add(new RateioItem
            {
                PlanoContasId=reader.IsDBNull(0)?0:reader.GetInt64(0),
                PlanoContasNome=reader.GetString(1),
                CentroCustosId=reader.IsDBNull(2)?null:reader.GetInt64(2),
                CentroCustosNome=reader.GetString(3),
                Percentual=Convert.ToDecimal(reader.GetDouble(4)),
                Valor=Convert.ToDecimal(reader.GetDouble(5))
            });
        }

        return itens;
    }

    public void SincronizarIdentificacaoRateios()
    {
        using var connection=new SqliteConnection(DatabaseInitializer.ConnectionString);
        connection.Open();
        using var command=connection.CreateCommand();
        command.CommandText =
        """
        UPDATE Lancamentos
        SET Anotacoes =
            CASE
              WHEN TRIM(COALESCE(Anotacoes,''))='' THEN 'RATEIO 01'
              ELSE TRIM(Anotacoes) || ' | RATEIO 01'
            END
        WHERE Ativo=1
          AND Id IN (SELECT DISTINCT LancamentoId FROM Rateios WHERE Ativo=1)
          AND UPPER(COALESCE(Anotacoes,'')) NOT LIKE '%RATEIO 01%';
        """;
        command.ExecuteNonQuery();
    }

    public List<RateioResumo> ListarRateios()
    {
        var lista=new List<RateioResumo>();
        using var connection=new SqliteConnection(DatabaseInitializer.ConnectionString);
        connection.Open(); GarantirColunas(connection);
        using var command=connection.CreateCommand();
        command.CommandText =
        """
        SELECT r.LancamentoId, l.DataPagamento, COALESCE(cf.Nome,''), COALESCE(l.Descricao,''),
               r.ValorTotal, COUNT(ri.Id), COALESCE(SUM(ri.Valor),0)
        FROM Rateios r
        INNER JOIN Lancamentos l ON l.Id=r.LancamentoId
        LEFT JOIN ClientesFornecedores cf ON cf.Id=l.ClienteFornecedorId
        LEFT JOIN RateioItens ri ON ri.RateioId=r.Id
        WHERE r.Ativo=1 AND l.Ativo=1
        GROUP BY r.Id,r.LancamentoId,l.DataPagamento,cf.Nome,l.Descricao,r.ValorTotal
        ORDER BY COALESCE(l.DataPagamento,l.DataEmissao) DESC,r.Id DESC;
        """;
        using var reader=command.ExecuteReader();
        while(reader.Read()) lista.Add(new RateioResumo{
            LancamentoId=reader.GetInt64(0),
            DataPagamento=reader.IsDBNull(1)?null:DateTime.Parse(reader.GetString(1)),
            ClienteFornecedor=reader.GetString(2),
            Descricao=reader.GetString(3),
            ValorOriginal=Convert.ToDecimal(reader.GetDouble(4)),
            QuantidadeItens=reader.GetInt32(5),
            TotalRateado=Convert.ToDecimal(reader.GetDouble(6))
        });
        foreach(var r in lista) r.Itens=ListarPorLancamento(r.LancamentoId);
        return lista;
    }

    public Dictionary<long,int> ListarNumerosRateio()
    {
        var mapa=new Dictionary<long,int>();
        using var connection=new SqliteConnection(DatabaseInitializer.ConnectionString);
        connection.Open();
        using var command=connection.CreateCommand();
        command.CommandText="SELECT LancamentoId, Id FROM Rateios WHERE Ativo=1 ORDER BY Id;";
        using var reader=command.ExecuteReader();
        int n=0;
        while(reader.Read()){n++;mapa[reader.GetInt64(0)]=n;}
        return mapa;
    }

    public HashSet<long> ListarLancamentosRateados()
    {
        var ids=new HashSet<long>();
        using var connection=new SqliteConnection(DatabaseInitializer.ConnectionString);
        connection.Open();
        using var command=connection.CreateCommand();
        command.CommandText="SELECT DISTINCT LancamentoId FROM Rateios WHERE Ativo=1;";
        using var reader=command.ExecuteReader();
        while(reader.Read()) ids.Add(reader.GetInt64(0));
        return ids;
    }

    public bool PossuiRateio(
        long lancamentoId)
    {
        using var connection =
            new SqliteConnection(
                DatabaseInitializer.ConnectionString);

        connection.Open();

        using var command =
            connection.CreateCommand();

        command.CommandText =
        """
        SELECT COUNT(*)

        FROM Rateios

        WHERE
            LancamentoId = $lancamentoId
            AND Ativo = 1;
        """;

        command.Parameters.AddWithValue(
            "$lancamentoId",
            lancamentoId);

        long quantidade =
            Convert.ToInt64(
                command.ExecuteScalar());

        return quantidade > 0;
    }

    private static void ValidarItens(
        decimal valorTotal,
        List<RateioItem> itens)
    {
        foreach (var item in itens)
        {
            if (item.PlanoContasId <= 0)
            {
                throw new ArgumentException("Todos os itens precisam ter um Plano de Contas.");
            }

            if (item.Valor == 0)
            {
                throw new ArgumentException(
                    "Os valores do rateio precisam ser diferentes de zero.");
            }
        }

        bool centroDuplicado =
            itens
                .GroupBy(x => new { x.PlanoContasId, x.CentroCustosId })
                .Any(
                    x => x.Count() > 1);

        if (centroDuplicado)
        {
            throw new ArgumentException(
                "O mesmo Plano de Contas/Centro de Custos não pode aparecer duas vezes no rateio.");
        }

        decimal valorRateado =
            decimal.Round(
                itens.Sum(x => x.Valor),
                2,
                MidpointRounding.AwayFromZero);

        decimal valorEsperado =
            decimal.Round(
                valorTotal,
                2,
                MidpointRounding.AwayFromZero);

        if (valorRateado != valorEsperado)
        {
            throw new ArgumentException(
                $"O valor rateado precisa totalizar " +
                $"{valorEsperado:C}. " +
                $"Total atual: {valorRateado:C}.");
        }
    }

    private static void ExcluirRateioAnterior(
        SqliteConnection connection,
        SqliteTransaction transaction,
        long lancamentoId)
    {
        long? rateioId = null;

        using (var localizar =
               connection.CreateCommand())
        {
            localizar.Transaction =
                transaction;

            localizar.CommandText =
            """
            SELECT Id
            FROM Rateios
            WHERE
                LancamentoId = $lancamentoId
                AND Ativo = 1
            ORDER BY Id DESC
            LIMIT 1;
            """;

            localizar.Parameters.AddWithValue(
                "$lancamentoId",
                lancamentoId);

            object? resultado =
                localizar.ExecuteScalar();

            if (resultado != null &&
                resultado != DBNull.Value)
            {
                rateioId =
                    Convert.ToInt64(
                        resultado);
            }
        }

        if (!rateioId.HasValue)
            return;

        using (var excluirItens =
               connection.CreateCommand())
        {
            excluirItens.Transaction =
                transaction;

            excluirItens.CommandText =
            """
            DELETE FROM RateioItens
            WHERE RateioId = $rateioId;
            """;

            excluirItens.Parameters.AddWithValue(
                "$rateioId",
                rateioId.Value);

            excluirItens.ExecuteNonQuery();
        }

        using (var excluirRateio =
               connection.CreateCommand())
        {
            excluirRateio.Transaction =
                transaction;

            excluirRateio.CommandText =
            """
            DELETE FROM Rateios
            WHERE Id = $rateioId;
            """;

            excluirRateio.Parameters.AddWithValue(
                "$rateioId",
                rateioId.Value);

            excluirRateio.ExecuteNonQuery();
        }
    }

    private static long InserirRateio(
        SqliteConnection connection,
        SqliteTransaction transaction,
        long lancamentoId,
        decimal valorTotal)
    {
        using var command =
            connection.CreateCommand();

        command.Transaction =
            transaction;

        command.CommandText =
        """
        INSERT INTO Rateios
        (
            LancamentoId,
            ValorTotal,
            Ativo,
            CriadoEm
        )
        VALUES
        (
            $lancamentoId,
            $valorTotal,
            1,
            $criadoEm
        );

        SELECT last_insert_rowid();
        """;

        command.Parameters.AddWithValue(
            "$lancamentoId",
            lancamentoId);

        command.Parameters.AddWithValue(
            "$valorTotal",
            valorTotal);

        command.Parameters.AddWithValue(
            "$criadoEm",
            DateTime.UtcNow.ToString("O"));

        return Convert.ToInt64(
            command.ExecuteScalar());
    }

    private static void GarantirColunas(SqliteConnection connection)
    {
        try { using var c=connection.CreateCommand(); c.CommandText="ALTER TABLE RateioItens ADD COLUMN PlanoContasId INTEGER NULL;"; c.ExecuteNonQuery(); } catch { }
    }

    private static void InserirItem(
        SqliteConnection connection,
        SqliteTransaction transaction,
        long rateioId,
        RateioItem item)
    {
        using var command =
            connection.CreateCommand();

        command.Transaction =
            transaction;

        command.CommandText =
        """
        INSERT INTO RateioItens
        (
            RateioId,
            PlanoContasId,
            CentroCustosId,
            Percentual,
            Valor,
            CriadoEm
        )
        VALUES
        (
            $rateioId,
            $planoContasId,
            $centroCustosId,
            $percentual,
            $valor,
            $criadoEm
        );
        """;

        command.Parameters.AddWithValue(
            "$rateioId",
            rateioId);

        command.Parameters.AddWithValue("$planoContasId", item.PlanoContasId);
        command.Parameters.AddWithValue("$centroCustosId", (object?)item.CentroCustosId ?? DBNull.Value);

        command.Parameters.AddWithValue(
            "$percentual",
            item.Percentual);

        command.Parameters.AddWithValue(
            "$valor",
            item.Valor);

        command.Parameters.AddWithValue(
            "$criadoEm",
            DateTime.UtcNow.ToString("O"));

        command.ExecuteNonQuery();
    }
}