using System.Security.Cryptography;
using System.Text.Json;
using FinanceiroMasterPro.Application.Contracts;
using FinanceiroMasterPro.Domain.Entities;
using FinanceiroMasterPro.Infrastructure.Data;

namespace FinanceiroMasterPro.Infrastructure.Security;

public sealed class SecurityUser
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public string Nome { get; set; } = "";
    public string Login { get; set; } = "";
    public string PasswordHash { get; set; } = "";
    public string PasswordSalt { get; set; } = "";
    public string Perfil { get; set; } = "Consulta";
    public bool Ativo { get; set; } = true;
    public bool ExigirTrocaSenha { get; set; }
    public int TentativasFalhas { get; set; }
    public DateTime? BloqueadoAte { get; set; }
    public DateTime? UltimoAcesso { get; set; }
    public List<string> EmpresasPermitidas { get; set; } = new();
    public List<string> Permissoes { get; set; } = new();
    public bool Administrador => Perfil.Equals("Administrador", StringComparison.OrdinalIgnoreCase);
}

public static class SecuritySession
{
    public static SecurityUser? CurrentUser { get; set; }
}

public static class PasswordHasher
{
    public static (string Hash, string Salt) HashNew(string password)
    {
        var salt = RandomNumberGenerator.GetBytes(16);
        var hash = Rfc2898DeriveBytes.Pbkdf2(password, salt, 120000, HashAlgorithmName.SHA256, 32);
        return (Convert.ToBase64String(hash), Convert.ToBase64String(salt));
    }
    public static bool Verify(string password, string hash, string salt)
    {
        try
        {
            var expected = Convert.FromBase64String(hash);
            var actual = Rfc2898DeriveBytes.Pbkdf2(password, Convert.FromBase64String(salt), 120000, HashAlgorithmName.SHA256, 32);
            return CryptographicOperations.FixedTimeEquals(expected, actual);
        }
        catch { return false; }
    }
    public static void Validate(string password)
    {
        if (password.Length < 8 || !password.Any(char.IsLetter) || !password.Any(char.IsDigit))
            throw new InvalidOperationException("A senha deve ter pelo menos 8 caracteres, com letras e números.");
    }
}

public static class SecurityStore
{
    private static readonly string Pasta = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "FinanceiroMasterPro");
    private static readonly string Arquivo = Path.Combine(Pasta, "seguranca.json");
    private static readonly object Sync = new();

    public static List<SecurityUser> Listar()
    {
        lock (Sync)
        {
            Directory.CreateDirectory(Pasta);
            List<SecurityUser> users = new();
            if (File.Exists(Arquivo))
            {
                try { users = JsonSerializer.Deserialize<List<SecurityUser>>(File.ReadAllText(Arquivo)) ?? new(); } catch { }
            }
            if (users.Count == 0)
            {
                var p = PasswordHasher.HashNew("admin123");
                users.Add(new SecurityUser { Nome="Administrador", Login="admin", PasswordHash=p.Hash, PasswordSalt=p.Salt, Perfil="Administrador", ExigirTrocaSenha=true });
                Salvar(users);
            }
            return users;
        }
    }

    public static SecurityUser? Autenticar(string login, string senha, out string erro)
    {
        var users = Listar();
        var u = users.FirstOrDefault(x => x.Login.Equals((login ?? "").Trim(), StringComparison.OrdinalIgnoreCase));
        if (u is null || !u.Ativo) { erro = "Usuário ou senha inválidos."; return null; }
        // 2026.176: não bloquear o acesso por tentativas incorretas.
        // Também limpa qualquer bloqueio gravado por versões anteriores.
        if (u.BloqueadoAte is not null || u.TentativasFalhas != 0)
        {
            u.BloqueadoAte = null;
            u.TentativasFalhas = 0;
            Salvar(users);
        }
        if (!PasswordHasher.Verify(senha ?? "", u.PasswordHash, u.PasswordSalt))
        {
            erro = "Usuário ou senha inválidos.";
            return null;
        }
        u.TentativasFalhas=0; u.BloqueadoAte=null; u.UltimoAcesso=DateTime.Now; Salvar(users); erro=""; return u;
    }

    public static void SalvarUsuario(SecurityUser user, string? novaSenha = null)
    {
        var users=Listar();
        if (users.Any(x=>x.Id!=user.Id && x.Login.Equals(user.Login, StringComparison.OrdinalIgnoreCase))) throw new InvalidOperationException("Já existe um usuário com esse login.");
        if (!string.IsNullOrWhiteSpace(novaSenha)) { PasswordHasher.Validate(novaSenha); var p=PasswordHasher.HashNew(novaSenha); user.PasswordHash=p.Hash; user.PasswordSalt=p.Salt; }
        if (string.IsNullOrWhiteSpace(user.PasswordHash)) throw new InvalidOperationException("Informe uma senha para o novo usuário.");
        var i=users.FindIndex(x=>x.Id==user.Id); if(i>=0) users[i]=user; else users.Add(user);
        if (!users.Any(x=>x.Ativo && x.Administrador)) throw new InvalidOperationException("É necessário manter pelo menos um administrador ativo.");
        Salvar(users);
    }

    public static void ExcluirUsuario(Guid id)
    {
        var users = Listar();
        var u = users.FirstOrDefault(x => x.Id == id) ?? throw new InvalidOperationException("Usuário não encontrado.");
        if (SecuritySession.CurrentUser?.Id == id) throw new InvalidOperationException("Não é possível excluir o usuário que está gerenciando a segurança agora.");
        if (u.Administrador && users.Count(x => x.Ativo && x.Administrador && x.Id != id) == 0)
            throw new InvalidOperationException("Cadastre ou mantenha outro administrador ativo antes de excluir este usuário.");
        users.Remove(u);
        Salvar(users);
    }

    public static void AlterarSenha(Guid id, string atual, string nova)
    {
        PasswordHasher.Validate(nova); var users=Listar(); var u=users.First(x=>x.Id==id);
        if(!PasswordHasher.Verify(atual,u.PasswordHash,u.PasswordSalt)) throw new InvalidOperationException("Senha atual incorreta.");
        var p=PasswordHasher.HashNew(nova); u.PasswordHash=p.Hash;u.PasswordSalt=p.Salt;u.ExigirTrocaSenha=false;Salvar(users);
        if(SecuritySession.CurrentUser?.Id==u.Id) SecuritySession.CurrentUser=u;
    }

    public static bool PodeAcessarEmpresa(SecurityUser u, string empresaId) => u.Administrador || u.EmpresasPermitidas.Count==0 || u.EmpresasPermitidas.Contains(empresaId);
    private static void Salvar(List<SecurityUser> users) { Directory.CreateDirectory(Pasta); File.WriteAllText(Arquivo, JsonSerializer.Serialize(users,new JsonSerializerOptions{WriteIndented=true})); }
}

public sealed class AuditEntry { public DateTime Data {get;set;}=DateTime.Now; public string Usuario {get;set;}=""; public string Acao {get;set;}=""; public string Detalhe {get;set;}=""; }
public static class AuditStore
{
    private static readonly string Arquivo=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"FinanceiroMasterPro","auditoria.json");
    public static void Registrar(string acao,string detalhe="") { try { var l=Listar(); l.Add(new AuditEntry{Usuario=SecuritySession.CurrentUser?.Login??"SISTEMA",Acao=acao,Detalhe=detalhe}); Directory.CreateDirectory(Path.GetDirectoryName(Arquivo)!); File.WriteAllText(Arquivo,JsonSerializer.Serialize(l.TakeLast(2000),new JsonSerializerOptions{WriteIndented=true})); } catch {} }
    public static List<AuditEntry> Listar(){ try { if(File.Exists(Arquivo)) return JsonSerializer.Deserialize<List<AuditEntry>>(File.ReadAllText(Arquivo))??new(); } catch{} return new(); }
}

public sealed class LocalAuthService : IAuthService
{
    public Usuario? Autenticar(string login,string senha)
    {
        var u=SecurityStore.Autenticar(login,senha,out _); if(u is null) return null; SecuritySession.CurrentUser=u;
        return new Usuario { Id=u.Id, Nome=u.Nome, Login=u.Login, Ativo=u.Ativo, Administrador=u.Administrador };
    }
    public SecurityUser? AutenticarSeguro(string login,string senha,out string erro) { var u=SecurityStore.Autenticar(login,senha,out erro); if(u!=null) SecuritySession.CurrentUser=u; return u; }
}
public sealed class TrialLicenseService : ILicencaService { private readonly LicencaLocal _licenca=new(){Cliente="Avaliação local",Chave="TRIAL",Avaliacao=true,Ativa=true,ExpiraEm=DateTime.Today.AddDays(30)}; public LicencaLocal ObterEstado()=>_licenca; public bool PodeOperar()=>_licenca.Ativa && (_licenca.ExpiraEm is null || _licenca.ExpiraEm.Value.Date>=DateTime.Today); }
