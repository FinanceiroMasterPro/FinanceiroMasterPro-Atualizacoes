using System.Globalization;
using System.Text;
using System.Text.RegularExpressions;
namespace FinanceiroMasterPro.Desktop;
public static class PesquisaAvancada {
 public static string N(string? v){if(string.IsNullOrWhiteSpace(v))return "";var d=v.Trim().Normalize(NormalizationForm.FormD);var b=new StringBuilder();foreach(var c in d)if(CharUnicodeInfo.GetUnicodeCategory(c)!=UnicodeCategory.NonSpacingMark)b.Append(char.ToUpperInvariant(c));return Regex.Replace(b.ToString(),@"\s+"," ");}
 public static bool Texto(string? v,string p){var a=N(v);return N(p).Split(' ',StringSplitOptions.RemoveEmptyEntries).All(a.Contains);}
 static string D(string? v)=>Regex.Replace(v??"",@"\D","");
 public static bool Valor(decimal v,string p){p=p.Trim();var br=v.ToString("N2",CultureInfo.GetCultureInfo("pt-BR"));if(Texto(br,p)||Texto(v.ToString("0.00",CultureInfo.InvariantCulture),p)||Texto(v.ToString(CultureInfo.InvariantCulture),p))return true;var d=D(p);if(d.Length>=2&&D(br).Contains(d))return true;if(decimal.TryParse(p,NumberStyles.Number|NumberStyles.AllowLeadingSign,CultureInfo.GetCultureInfo("pt-BR"),out var a)&&Math.Abs(a-v)<.005m)return true;if(decimal.TryParse(p,NumberStyles.Number|NumberStyles.AllowLeadingSign,CultureInfo.InvariantCulture,out var b)&&Math.Abs(b-v)<.005m)return true;return false;}
 public static bool Data(DateTime? d,string p)=>d.HasValue&&(Texto(d.Value.ToString("dd/MM/yyyy"),p)||Texto(d.Value.ToString("MM/yyyy"),p));
}