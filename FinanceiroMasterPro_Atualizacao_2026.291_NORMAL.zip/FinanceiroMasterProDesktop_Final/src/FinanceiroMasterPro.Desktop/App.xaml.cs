using System.Windows;
using FinanceiroMasterPro.Infrastructure.Data;
using FinanceiroMasterPro.Infrastructure.Security;

namespace FinanceiroMasterPro.Desktop;

public partial class App : System.Windows.Application
{
    protected override void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);
        ShutdownMode = ShutdownMode.OnExplicitShutdown;

        var login = new Views.LoginWindow(new LocalAuthService());
        if (login.ShowDialog() != true) { Shutdown(); return; }

        if (SecuritySession.CurrentUser?.ExigirTrocaSenha == true)
        {
            var troca = new Views.AlterarSenhaWindow(true);
            if (troca.ShowDialog() != true) { Shutdown(); return; }
        }

        var seletor = new Views.SelecionarEmpresaWindow();
        if (seletor.ShowDialog() != true || seletor.EmpresaSelecionada is null) { Shutdown(); return; }

        EmpresaDatabaseManager.Selecionar(seletor.EmpresaSelecionada);
        DatabaseInitializer.Initialize();

        var mainWindow = new MainWindow();
        MainWindow = mainWindow;
        ShutdownMode = ShutdownMode.OnMainWindowClose;
        mainWindow.Show();
    }

}