﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace FinanceiroMasterPro.Desktop;

public sealed record InstitutionOption(string Key,string Nome,string Categoria,string Icone)
{
    public override string ToString()=>Nome;
    public bool Personalizada => Key.StartsWith("personalizada_",StringComparison.OrdinalIgnoreCase);
}

public static class InstitutionCatalog
{
    private sealed record Personalizada(string Key,string Nome,string Categoria,string Arquivo);
    private static readonly string Pasta = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"FinanceiroMasterPro","Bandeiras");
    private static readonly string Cadastro = Path.Combine(Pasta,"biblioteca.json");
    private static readonly List<InstitutionOption> Padrao = new()
    {
        new("dinheiro","Dinheiro","Dinheiro","pack://application:,,,/FinanceiroMasterPro;component/Assets/Instituicoes/dinheiro.png"),
        new("alelo","Alelo","Vale Alimentação / Refeição","pack://application:,,,/FinanceiroMasterPro;component/Assets/Instituicoes/alelo.png"),
        new("banco_do_brasil","Banco do Brasil","Bancos","pack://application:,,,/FinanceiroMasterPro;component/Assets/Instituicoes/banco_do_brasil.png"),
        new("inter","Banco Inter","Bancos Digitais","pack://application:,,,/FinanceiroMasterPro;component/Assets/Instituicoes/inter.png"),
        new("bradesco","Bradesco","Bancos","pack://application:,,,/FinanceiroMasterPro;component/Assets/Instituicoes/bradesco.png"),
        new("btg","BTG Pactual","Investimentos","pack://application:,,,/FinanceiroMasterPro;component/Assets/Instituicoes/btg.png"),
        new("c6","C6 Bank","Bancos Digitais","pack://application:,,,/FinanceiroMasterPro;component/Assets/Instituicoes/c6.png"),
        new("caixa","Caixa Econômica Federal","Bancos","pack://application:,,,/FinanceiroMasterPro;component/Assets/Instituicoes/caixa.png"),
        new("itau","Itaú","Bancos","pack://application:,,,/FinanceiroMasterPro;component/Assets/Instituicoes/itau.png"),
        new("mercado_pago","Mercado Pago","Carteiras Digitais","pack://application:,,,/FinanceiroMasterPro;component/Assets/Instituicoes/mercado_pago.png"),
        new("nubank","Nubank","Bancos Digitais","pack://application:,,,/FinanceiroMasterPro;component/Assets/Instituicoes/nubank.png"),
        new("safra","Safra","Bancos","pack://application:,,,/FinanceiroMasterPro;component/Assets/Instituicoes/safra.png"),
        new("santander","Santander","Bancos","pack://application:,,,/FinanceiroMasterPro;component/Assets/Instituicoes/santander.png"),
        new("sicredi","Sicredi","Cooperativas","pack://application:,,,/FinanceiroMasterPro;component/Assets/Instituicoes/sicredi.png"),
        new("sodexo","Sodexo / Pluxee","Vale Alimentação / Refeição","pack://application:,,,/FinanceiroMasterPro;component/Assets/Instituicoes/sodexo.png"),
        new("ticket","Ticket","Vale Alimentação / Refeição","pack://application:,,,/FinanceiroMasterPro;component/Assets/Instituicoes/ticket.png"),
        new("vr","VR Benefícios","Vale Alimentação / Refeição","pack://application:,,,/FinanceiroMasterPro;component/Assets/Instituicoes/vr.png")
    };
    public static List<InstitutionOption> Opcoes => Carregar();
    private static string OverridePath(string key)=>Path.Combine(Pasta,"override_"+key+".png");
    private static List<Personalizada> LerPersonalizadas(){try{return File.Exists(Cadastro)?JsonSerializer.Deserialize<List<Personalizada>>(File.ReadAllText(Cadastro))??new():new();}catch{return new();}}
    private static void SalvarPersonalizadas(List<Personalizada> lista){Directory.CreateDirectory(Pasta);lista=lista.OrderBy(x=>x.Nome,StringComparer.CurrentCultureIgnoreCase).ToList();File.WriteAllText(Cadastro,JsonSerializer.Serialize(lista,new JsonSerializerOptions{WriteIndented=true}));}
    public static List<InstitutionOption> Carregar(string? pesquisa=null)
    {
        Directory.CreateDirectory(Pasta);
        var itens=Padrao.Select(x=>File.Exists(OverridePath(x.Key)) ? x with { Icone=OverridePath(x.Key) } : x).ToList();
        itens.AddRange(LerPersonalizadas().Where(x=>File.Exists(x.Arquivo)).Select(x=>new InstitutionOption(x.Key,x.Nome,x.Categoria,x.Arquivo)));
        IEnumerable<InstitutionOption> q=itens.GroupBy(x=>x.Key,StringComparer.OrdinalIgnoreCase).Select(g=>g.Last());
        if(!string.IsNullOrWhiteSpace(pesquisa))q=q.Where(x=>x.Nome.Contains(pesquisa,StringComparison.CurrentCultureIgnoreCase)||x.Categoria.Contains(pesquisa,StringComparison.CurrentCultureIgnoreCase));
        return new[]{new InstitutionOption("","Sem bandeira","Outros","")}.Concat(q.OrderBy(x=>x.Nome,StringComparer.CurrentCultureIgnoreCase)).ToList();
    }
    public static InstitutionOption? PorChave(string? key)=>Carregar().FirstOrDefault(x=>string.Equals(x.Key,key??"",StringComparison.OrdinalIgnoreCase));
    public static InstitutionOption? PorNome(string? nome)=>string.IsNullOrWhiteSpace(nome)?null:Carregar().FirstOrDefault(x=>string.Equals(x.Nome,nome.Trim(),StringComparison.CurrentCultureIgnoreCase));
    public static InstitutionOption? Resolver(string? key,string? nomeBanco)=>PorChave(key)??PorNome(nomeBanco);
    public static InstitutionOption AdicionarPersonalizada(string nome,string arquivoOrigem,string categoria="Personalizadas")
    {
        if(string.IsNullOrWhiteSpace(nome))throw new ArgumentException("Informe o nome da bandeira / instituição."); if(!File.Exists(arquivoOrigem))throw new FileNotFoundException("Imagem não encontrada.",arquivoOrigem);
        Directory.CreateDirectory(Pasta);var key="personalizada_"+Guid.NewGuid().ToString("N");var destino=Path.Combine(Pasta,key+".png");NormalizarImagem(arquivoOrigem,destino,true,1.0);
        var lista=LerPersonalizadas();lista.Add(new Personalizada(key,nome.Trim(),categoria,destino));SalvarPersonalizadas(lista);return new InstitutionOption(key,nome.Trim(),categoria,destino);
    }
    public static void SubstituirImagem(string key,string arquivoOrigem)
    {
        if(string.IsNullOrWhiteSpace(key))throw new InvalidOperationException("Selecione uma bandeira.");
        if(!File.Exists(arquivoOrigem))throw new FileNotFoundException("Imagem não encontrada.",arquivoOrigem);
        Directory.CreateDirectory(Pasta);
        var personalizada=LerPersonalizadas().FirstOrDefault(x=>string.Equals(x.Key,key,StringComparison.OrdinalIgnoreCase));
        var destino=personalizada?.Arquivo ?? OverridePath(key);
        var tmp=destino+".novo.png";
        NormalizarImagem(arquivoOrigem,tmp,true,1.0);
        File.Copy(tmp,destino,true); File.Delete(tmp);
    }
    public static bool PodeRestaurarOriginal(string key)=>Padrao.Any(x=>string.Equals(x.Key,key,StringComparison.OrdinalIgnoreCase))&&File.Exists(OverridePath(key));
    public static void RestaurarOriginal(string key)
    {
        if(!Padrao.Any(x=>string.Equals(x.Key,key,StringComparison.OrdinalIgnoreCase)))throw new InvalidOperationException("Somente bandeiras padrão podem ser restauradas.");
        var arq=OverridePath(key); if(File.Exists(arq))File.Delete(arq);
    }
    public static void AjustarPersonalizada(string key,double zoom=1.0)
    {
        var item=LerPersonalizadas().FirstOrDefault(x=>x.Key==key)??throw new InvalidOperationException("Selecione uma bandeira personalizada.");
        if(!File.Exists(item.Arquivo))throw new FileNotFoundException("Arquivo da bandeira não encontrado.");var tmp=item.Arquivo+".tmp.png";NormalizarImagem(item.Arquivo,tmp,true,zoom);File.Copy(tmp,item.Arquivo,true);File.Delete(tmp);
    }
    public static void ExcluirPersonalizada(string key)
    {
        var lista=LerPersonalizadas();var item=lista.FirstOrDefault(x=>x.Key==key)??throw new InvalidOperationException("Somente bandeiras personalizadas podem ser excluídas.");lista.Remove(item);SalvarPersonalizadas(lista);try{if(File.Exists(item.Arquivo))File.Delete(item.Arquivo);}catch{}
    }
    private static void NormalizarImagem(string origem,string destino,bool cortarMargens,double zoom)
    {
        var src=new BitmapImage();src.BeginInit();src.CacheOption=BitmapCacheOption.OnLoad;src.UriSource=new Uri(origem,UriKind.Absolute);src.EndInit();src.Freeze();BitmapSource baseImg=src;
        if(cortarMargens)
        {
            var conv=new FormatConvertedBitmap(src,PixelFormats.Bgra32,null,0);int w=conv.PixelWidth,h=conv.PixelHeight,stride=w*4;var px=new byte[h*stride];conv.CopyPixels(px,stride,0);int minX=w,minY=h,maxX=-1,maxY=-1;
            for(int y=0;y<h;y++)for(int x=0;x<w;x++){int i=y*stride+x*4;byte b=px[i],g=px[i+1],r=px[i+2],a=px[i+3];bool vazio=a<18||(r>246&&g>246&&b>246);if(!vazio){if(x<minX)minX=x;if(x>maxX)maxX=x;if(y<minY)minY=y;if(y>maxY)maxY=y;}}
            if(maxX>=minX&&maxY>=minY){int pad=Math.Max(2,(int)(Math.Max(maxX-minX+1,maxY-minY+1)*0.04));minX=Math.Max(0,minX-pad);minY=Math.Max(0,minY-pad);maxX=Math.Min(w-1,maxX+pad);maxY=Math.Min(h-1,maxY+pad);baseImg=new CroppedBitmap(src,new System.Windows.Int32Rect(minX,minY,maxX-minX+1,maxY-minY+1));}
        }
        const int tamanho=128;var visual=new DrawingVisual();using(var dc=visual.RenderOpen()){var escala=Math.Min((double)tamanho/baseImg.PixelWidth,(double)tamanho/baseImg.PixelHeight)*Math.Clamp(zoom,0.65,1.45);double dw=baseImg.PixelWidth*escala; double dh=baseImg.PixelHeight*escala;dc.DrawImage(baseImg,new System.Windows.Rect((tamanho-dw)/2,(tamanho-dh)/2,dw,dh));}
        var bmp=new RenderTargetBitmap(tamanho,tamanho,96,96,PixelFormats.Pbgra32);bmp.Render(visual);var encoder=new PngBitmapEncoder();encoder.Frames.Add(BitmapFrame.Create(bmp));using var fs=File.Create(destino);encoder.Save(fs);
    }
}
