﻿using System.Linq;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using FinanceiroMasterPro.Infrastructure.Data;
using FinanceiroMasterPro.Infrastructure.Security;

namespace FinanceiroMasterPro.Desktop;

public partial class MainWindow : Window
{
    private List<long>? _relatorioLancamentosIds;
    // Snapshot FIXO dos IDs que existiam no relatório antes de abrir um lançamento.
    // Nunca é substituído pelo lançamento isolado.
    private List<long>? _relatorioLancamentosIdsOriginais;
    private Views.LancamentosView? _lancamentosViewOrigemRelatorio;
    public MainWindow()
    {
        InitializeComponent();
        Title = $"Financeiro Master Pro Desktop - {EmpresaDatabaseManager.NomeAtual} - Versão 2026.291";
        TxtEmpresaVersao.Text = $"{EmpresaDatabaseManager.NomeAtual.ToUpperInvariant()}  |  Versão 2026.291";
        TxtUsuario.Text = $"{(SecuritySession.CurrentUser?.Nome ?? "").ToUpperInvariant()} ( {SecuritySession.CurrentUser?.Perfil ?? ""} )";
        Dashboard_Click(this, new RoutedEventArgs());
    }

    private void ShowText(string titulo, string descricao)
    {
        Conteudo.Content = new StackPanel
        {
            Children =
            {
                new TextBlock
                {
                    Text = titulo,
                    FontSize = 30,
                    FontWeight = FontWeights.Bold
                },

                new TextBlock
                {
                    Text = descricao,
                    Margin = new Thickness(0, 10, 0, 0),
                    FontSize = 15,
                    TextWrapping = TextWrapping.Wrap
                }
            }
        };
    }

    private void TrocarEmpresa_Click(object sender, RoutedEventArgs e)
    {
        var seletor = new Views.SelecionarEmpresaWindow { Owner = this };
        if (seletor.ShowDialog() != true || seletor.EmpresaSelecionada is null) return;

        var empresaAnterior = EmpresaDatabaseManager.EmpresaAtual;
        try
        {
            // Libera a tela vinculada ao banco anterior antes de alterar a empresa ativa.
            Conteudo.Content = null;
            EmpresaDatabaseManager.Selecionar(seletor.EmpresaSelecionada);
            // Cada empresa possui seu próprio arquivo SQLite. Garante que o banco
            // selecionado esteja na estrutura da versão atual antes de criar qualquer tela.
            DatabaseInitializer.Initialize();

            Title = $"Financeiro Master Pro Desktop - {EmpresaDatabaseManager.NomeAtual} - Versão 2026.291";
            TxtEmpresaVersao.Text = $"{EmpresaDatabaseManager.NomeAtual.ToUpperInvariant()}  |  Versão 2026.291";
            Conteudo.Content = new Views.DashboardView();
        }
        catch (Exception ex)
        {
            // Não deixa uma falha de recarga encerrar o aplicativo. Restaura a empresa anterior.
            if (empresaAnterior is not null)
            {
                try { EmpresaDatabaseManager.Selecionar(empresaAnterior); } catch { }
            }

            try { Conteudo.Content = new Views.DashboardView(); } catch { }
            MessageBox.Show(
                $"Não foi possível trocar de empresa.\n\n{ex.Message}",
                "Trocar Empresa",
                MessageBoxButton.OK,
                MessageBoxImage.Error);
        }
    }

    private void Dashboard_Click(object sender, RoutedEventArgs e)
    {
        Conteudo.Content = new Views.DashboardView();
    }

    private void Cadastros_Click(
        object sender,
        RoutedEventArgs e)
    {
        ShowText(
            "Cadastros",
            "Contas Bancárias, Plano de Contas, Centro de Custos, " +
            "Grupo de Contas, Fluxo de Caixa e Clientes/Fornecedores.");
    }

    private void ContaBancaria_Click(
        object sender,
        RoutedEventArgs e)
    {
        Conteudo.Content =
            new Views.ContaBancariaView();
    }


    private void CartaoCredito_Click(object sender, RoutedEventArgs e)
    {
        Conteudo.Content = new Views.CartaoCreditoView();
    }

    private void PlanoContas_Click(
        object sender,
        RoutedEventArgs e)
    {
        Conteudo.Content =
            new Views.PlanoContasView();
    }

    private void CentroCustos_Click(
        object sender,
        RoutedEventArgs e)
    {
        Conteudo.Content =
            new Views.CentroCustosView();
    }

    private void GrupoContas_Click(
        object sender,
        RoutedEventArgs e)
    {
        Conteudo.Content =
            new Views.GrupoContasView();
    }

    private void Fluxo_Click(
        object sender,
        RoutedEventArgs e)
    {
        Conteudo.Content =
            new Views.FluxoCaixaView();
    }

    private void CadastroUnico_Click(object sender, RoutedEventArgs e)
    {
        Conteudo.Content = new Views.CadastroUnicoView();
    }

    private void ClienteFornecedor_Click(
        object sender,
        RoutedEventArgs e)
    {
        Conteudo.Content =
            new Views.ClienteFornecedorView();
    }

    // =========================================================
    // LANÇAMENTOS
    // =========================================================
    private void DfcCaixa_Click(object sender, RoutedEventArgs e)
    {
        Conteudo.Content = new Views.DfcCaixaView();
    }

    private void FluxoContas_Click(object sender, RoutedEventArgs e)
    {
        Conteudo.Content = new Views.FluxoCaixaContasView();
    }

    public void AbrirLancamentoPorId(long lancamentoId)
    {
        var view = new Views.LancamentosView();
        Conteudo.Content = view;
        view.HabilitarVoltarTelaAnterior();
        view.AbrirLancamentoPorId(lancamentoId);
    }

    public void VoltarParaFluxoContas()
    {
        Conteudo.Content = new Views.FluxoCaixaContasView();
    }

    public void VoltarParaDfcCaixa()
    {
        Conteudo.Content = new Views.DfcCaixaView();
    }



    public void PrepararRelatorioLancamentos(Views.LancamentosView origem, List<long> idsRelatorio)
    {
        // Guarda a própria tela de origem para preservar exatamente filtros/configurações.
        _lancamentosViewOrigemRelatorio = origem;
        _relatorioLancamentosIds = idsRelatorio.ToList();
        _relatorioLancamentosIdsOriginais = idsRelatorio.ToList();
    }

    public void AbrirLancamentoDoRelatorio(long lancamentoId, List<long> idsRelatorio)
    {
        // Lógica restaurada exatamente da 2026.252 para este passo:
        // a lista recebida do relatório é a lista completa anterior ao isolamento.
        _relatorioLancamentosIds = idsRelatorio;
        var view = new Views.LancamentosView();
        Conteudo.Content = view;
        view.HabilitarVoltarTelaAnterior("RELATORIO_LANCAMENTOS");
        view.AbrirSomenteLancamentoPorId(lancamentoId);
    }

    public void VoltarParaRelatorioLancamentos()
    {
        // CORREÇÃO 2026.266: antes de recriar o Relatório, restaura a Grade de
        // Lançamentos original para sua visualização normal. O relatório é uma
        // cópia fiel dessa Grade, portanto nunca deve ser recriado a partir da
        // tela temporária que contém somente o lançamento em edição.
        if (_lancamentosViewOrigemRelatorio != null)
        {
            var origem = _lancamentosViewOrigemRelatorio;
            origem.AtualizarGradePreservandoFiltros();
            Conteudo.Content = origem;

            var itens = origem.ObterLancamentosVisiveis();
            _relatorioLancamentosIds = itens.Select(x => x.Id).ToList();
            _relatorioLancamentosIdsOriginais = _relatorioLancamentosIds.ToList();

            var win = new Views.RelatorioLancamentosWindow(itens) { Owner = this };
            win.ShowDialog();
            return;
        }

        Conteudo.Content = new Views.LancamentosView();
    }

    public void VoltarDoRelatorioParaLancamentos()
    {
        // Retorna à MESMA tela que abriu o relatório, preservando filtros/configurações.
        // Apenas atualiza os dados para refletir eventual alteração feita no lançamento.
        if (_lancamentosViewOrigemRelatorio != null)
        {
            var origem = _lancamentosViewOrigemRelatorio;
            Conteudo.Content = origem;
            origem.AtualizarGradePreservandoFiltros();
        }
        else
        {
            Conteudo.Content = new Views.LancamentosView();
        }
        _relatorioLancamentosIds = null;
        _relatorioLancamentosIdsOriginais = null;
        _lancamentosViewOrigemRelatorio = null;
    }

    private void Lancamentos_Click(
        object sender,
        RoutedEventArgs e)
    {
        Conteudo.Content =
            new Views.LancamentosView();
    }

    public void AbrirLancamentosDoDfc(string pesquisa, DateTime? inicio = null, DateTime? fim = null)
    {
        var view = new Views.LancamentosView();
        Conteudo.Content = view;
        view.HabilitarVoltarTelaAnterior("DFC_CAIXA");
        view.AplicarPesquisaDfc(pesquisa, inicio, fim);
    }

    // =========================================================
    // IMPORTAÇÃO DO EXCEL
    // =========================================================
    private void ImportarExcel_Click(
        object sender,
        RoutedEventArgs e)
    {
        var janela = new Views.ImportacaoExcelWindow
        {
            Owner = this
        };

        janela.ShowDialog();
    }

    private void ImportarExtrato_Click(object sender, RoutedEventArgs e)
    {
        var janela = new Views.ImportacaoExtratoWindow { Owner = this };
        janela.ShowDialog();
    }

    private void Parcelamentos_Click(
        object sender,
        RoutedEventArgs e)
    {
        ShowText(
            "Parcelamentos",
            "Estrutura preparada para geração automática e looping de parcelas.");
    }

    private void Rateios_Click(object sender, RoutedEventArgs e)
    {
        Conteudo.Content = new Views.RateiosView();
    }

    private void Provisionamentos_Click(
        object sender,
        RoutedEventArgs e)
    {
        ShowText(
            "Provisionamentos",
            "Previsões financeiras por competência.");
    }

    private void Faturas_Click(
        object sender,
        RoutedEventArgs e)
    {
        ShowText(
            "Cartões / Faturas",
            "A baixa da fatura deverá listar e baixar os lançamentos " +
            "vinculados, preservando cada item.");
    }

    private void Usuarios_Click(object sender, RoutedEventArgs e)
    {
        if (SecuritySession.CurrentUser?.Administrador != true) { MessageBox.Show("Somente administradores podem acessar Usuários / Segurança."); return; }
        Conteudo.Content = new Views.UsuariosSegurancaView();
    }

    private void AlterarSenha_Click(object sender, RoutedEventArgs e)
    {
        new Views.AlterarSenhaWindow { Owner = this }.ShowDialog();
    }

    private void Licenca_Click(
        object sender,
        RoutedEventArgs e)
    {
        ShowText(
            "Licenciamento",
            "Base separada dos dados financeiros para avaliação, ativação, " +
            "renovação e restrição segura por licença.");
    }

    public void AbrirView(UserControl view) => Conteudo.Content = view;
    public void AbrirNovoLancamentoCartao(long contaId)
    {
        var v = new Views.LancamentosView(); Conteudo.Content = v; v.SelecionarContaParaNovo(contaId);
    }
    public void AbrirLancamentosDaConta(long contaId)
    {
        var v = new Views.LancamentosView(); Conteudo.Content = v; v.FiltrarPorConta(contaId);
    }
    public void AbrirCartao(long contaId) => Conteudo.Content = new Views.CartaoCreditoView(contaId);


    private void ApagarLancamentos_Click(object sender, RoutedEventArgs e)
    {
        if (Conteudo.Content is not Views.LancamentosView view)
        {
            view = new Views.LancamentosView();
            Conteudo.Content = view;
        }
        view.SolicitarApagarLancamentos();
    }

    private void LimparTodosDados_Click(object sender, RoutedEventArgs e)
    {
        var primeira = MessageBox.Show(
            "ATENÇÃO: esta operação apagará TODOS os dados financeiros e cadastros desta instalação:\n\n" +
            "Contas Bancárias e Cartões\nClientes / Fornecedores\nPlano de Contas\nCentro de Custos\n" +
            "Grupo de Contas\nFluxo de Caixa\nLançamentos\nParcelamentos\nRateios\n\n" +
            "A estrutura, telas e configurações do sistema serão preservadas.\n\nDeseja continuar?",
            "Limpar todos os dados",
            MessageBoxButton.YesNo,
            MessageBoxImage.Warning);

        if (primeira != MessageBoxResult.Yes) return;

        var janela = new Window
        {
            Title = "Confirmação de segurança",
            Width = 470, Height = 225,
            WindowStartupLocation = WindowStartupLocation.CenterOwner,
            Owner = this, ResizeMode = ResizeMode.NoResize
        };
        var painel = new StackPanel { Margin = new Thickness(22) };
        painel.Children.Add(new TextBlock
        {
            Text = "Para confirmar a limpeza completa, digite LIMPAR abaixo:",
            FontSize = 14, FontWeight = FontWeights.SemiBold,
            TextWrapping = TextWrapping.Wrap
        });
        var caixa = new TextBox { Height = 32, Margin = new Thickness(0,14,0,14), FontSize = 15 };
        painel.Children.Add(caixa);
        var confirmar = new Button { Content = "CONFIRMAR LIMPEZA", Height = 36, Width = 180, HorizontalAlignment = HorizontalAlignment.Right };
        confirmar.Click += (_,__) =>
        {
            if (!string.Equals(caixa.Text.Trim(), "LIMPAR", StringComparison.OrdinalIgnoreCase))
            {
                MessageBox.Show("Digite LIMPAR para confirmar.", "Financeiro Master Pro", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }
            janela.DialogResult = true;
        };
        painel.Children.Add(confirmar);
        janela.Content = painel;
        janela.Loaded += (_,__) => caixa.Focus();

        if (janela.ShowDialog() != true) return;

        try
        {
            var backup = DatabaseInitializer.LimparTodosDadosFinanceiros();
            Conteudo.Content = new Views.DashboardView();
            MessageBox.Show(
                "Todos os dados financeiros e cadastros foram apagados.\n\n" +
                "A estrutura e as configurações do Financeiro Master Pro foram preservadas." +
                (string.IsNullOrWhiteSpace(backup) ? "" : "\n\nUm backup de segurança foi criado antes da limpeza."),
                "Financeiro Master Pro",
                MessageBoxButton.OK,
                MessageBoxImage.Information);
        }
        catch (Exception ex)
        {
            MessageBox.Show("Não foi possível concluir a limpeza.\n\n" + ex.Message,
                "Financeiro Master Pro", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }


    private async void AtualizacaoSistema_Click(object sender, RoutedEventArgs e)
    {
        const string versaoAtual = "2026.291";
        const string apiLatest = "https://api.github.com/repos/FinanceiroMasterPro/FinanceiroMasterPro-Atualizacoes/releases/latest";
        string? urlPacote = null;
        string? versaoOnlineEncontrada = null;

        static bool EhMaisNova(string online, string atual)
        {
            static int[] Partes(string v) => v.Trim().TrimStart('v','V').Split('.').Select(x => int.TryParse(x, out var n) ? n : 0).ToArray();
            var a = Partes(online); var b = Partes(atual);
            for (int i = 0; i < Math.Max(a.Length, b.Length); i++)
            {
                int x = i < a.Length ? a[i] : 0, y = i < b.Length ? b[i] : 0;
                if (x != y) return x > y;
            }
            return false;
        }

        var win = new Window { Title = "Atualização do Sistema", Width = 590, Height = 455, WindowStartupLocation = WindowStartupLocation.CenterOwner, Owner = this, ResizeMode = ResizeMode.NoResize };
        var painel = new StackPanel { Margin = new Thickness(28) };
        painel.Children.Add(new TextBlock { Text = "ATUALIZAÇÃO DO SISTEMA", FontSize = 20, FontWeight = FontWeights.Bold, Margin = new Thickness(0,0,0,18) });
        painel.Children.Add(new TextBlock { Text = $"Versão instalada: {versaoAtual}", FontSize = 15, FontWeight = FontWeights.SemiBold, Margin = new Thickness(0,0,0,10) });
        var status = new TextBlock { Text = "Servidor oficial: FinanceiroMasterPro/FinanceiroMasterPro-Atualizacoes", TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0,0,0,18) };
        painel.Children.Add(status);
        var verificar = new Button { Content = "VERIFICAR ATUALIZAÇÕES", Height = 38, Width = 210, HorizontalAlignment = HorizontalAlignment.Left };
        var atualizar = new Button { Content = "ATUALIZAR AGORA", Height = 38, Width = 210, HorizontalAlignment = HorizontalAlignment.Left, Margin = new Thickness(0,10,0,0), IsEnabled = false };

        verificar.Click += async (_, __) =>
        {
            try
            {
                verificar.IsEnabled = false; atualizar.IsEnabled = false; urlPacote = null;
                status.Text = "Verificando atualização...";
                using var http = new System.Net.Http.HttpClient();
                http.DefaultRequestHeaders.UserAgent.ParseAdd("FinanceiroMasterPro-Updater/2026.291");
                var json = await http.GetStringAsync(apiLatest);
                using var doc = System.Text.Json.JsonDocument.Parse(json);
                var root = doc.RootElement;
                versaoOnlineEncontrada = (root.GetProperty("tag_name").GetString() ?? "").Trim().TrimStart('v','V');
                if (EhMaisNova(versaoOnlineEncontrada, versaoAtual))
                {
                    foreach (var asset in root.GetProperty("assets").EnumerateArray())
                    {
                        var nome = asset.GetProperty("name").GetString() ?? "";
                        if (nome.EndsWith(".zip", StringComparison.OrdinalIgnoreCase) && nome.Contains("FinanceiroMasterPro_Atualizacao_", StringComparison.OrdinalIgnoreCase))
                        { urlPacote = asset.GetProperty("browser_download_url").GetString(); break; }
                    }
                    status.Text = $"Nova versão disponível: {versaoOnlineEncontrada}";
                    atualizar.IsEnabled = !string.IsNullOrWhiteSpace(urlPacote);
                    MessageBox.Show(atualizar.IsEnabled ? $"Nova atualização disponível: {versaoOnlineEncontrada}\n\nClique em ATUALIZAR AGORA." : "A versão foi encontrada, mas o pacote ZIP oficial não está anexado ao lançamento.", "Atualização do Sistema", MessageBoxButton.OK, atualizar.IsEnabled ? MessageBoxImage.Information : MessageBoxImage.Warning);
                }
                else
                {
                    status.Text = $"Última versão publicada: {versaoOnlineEncontrada}";
                    MessageBox.Show("Seu Financeiro Master Pro já está atualizado.", "Atualização do Sistema", MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
            catch (Exception ex) { status.Text = "Não foi possível consultar o servidor de atualizações."; MessageBox.Show("Não foi possível verificar atualizações.\n\n" + ex.Message, "Atualização do Sistema", MessageBoxButton.OK, MessageBoxImage.Warning); }
            finally { verificar.IsEnabled = true; }
        };

        atualizar.Click += async (_, __) =>
        {
            if (string.IsNullOrWhiteSpace(urlPacote) || string.IsNullOrWhiteSpace(versaoOnlineEncontrada)) return;
            if (MessageBox.Show($"Instalar agora a versão {versaoOnlineEncontrada}?\n\nO sistema fará backup, fechará o Financeiro, instalará a atualização e abrirá novamente.", "Atualização do Sistema", MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes) return;
            try
            {
                verificar.IsEnabled = false; atualizar.IsEnabled = false; status.Text = "Baixando atualização...";
                var pasta = System.IO.Path.Combine(System.IO.Path.GetTempPath(), "FinanceiroMasterPro_AutoUpdate_" + versaoOnlineEncontrada + "_" + Guid.NewGuid().ToString("N"));
                if (System.IO.Directory.Exists(pasta)) System.IO.Directory.Delete(pasta, true);
                System.IO.Directory.CreateDirectory(pasta);
                var zip = System.IO.Path.Combine(pasta, "atualizacao.zip");
                using (var http = new System.Net.Http.HttpClient())
                {
                    http.DefaultRequestHeaders.UserAgent.ParseAdd("FinanceiroMasterPro-Updater/2026.291");
                    var bytes = await http.GetByteArrayAsync(urlPacote);
                    await System.IO.File.WriteAllBytesAsync(zip, bytes);
                }
                status.Text = "Preparando instalação...";
                var extraido = System.IO.Path.Combine(pasta, "pacote");
                System.IO.Compression.ZipFile.ExtractToDirectory(zip, extraido);
                var ps1 = System.IO.Directory.GetFiles(extraido, "Atualizar-FinanceiroMasterPro.ps1", System.IO.SearchOption.AllDirectories).FirstOrDefault();
                if (ps1 == null) throw new Exception("O pacote não contém o instalador oficial Atualizar-FinanceiroMasterPro.ps1.");
                var psi = new System.Diagnostics.ProcessStartInfo
                {
                    FileName = "powershell.exe",
                    Arguments = $"-NoProfile -ExecutionPolicy Bypass -File \"{ps1}\"",
                    UseShellExecute = true,
                    WorkingDirectory = System.IO.Path.GetDirectoryName(ps1)!
                };
                System.Diagnostics.Process.Start(psi);
                await System.Threading.Tasks.Task.Delay(700);
                System.Windows.Application.Current.Shutdown();
            }
            catch (Exception ex) { verificar.IsEnabled = true; atualizar.IsEnabled = true; status.Text = "Falha ao preparar a atualização."; MessageBox.Show("Não foi possível iniciar a atualização automática.\n\n" + ex.Message, "Atualização do Sistema", MessageBoxButton.OK, MessageBoxImage.Error); }
        };

        painel.Children.Add(verificar); painel.Children.Add(atualizar);
        painel.Children.Add(new TextBlock { Text = "A partir desta versão, novas atualizações podem ser baixadas e instaladas diretamente por esta Central.", Margin = new Thickness(0,18,0,0), TextWrapping = TextWrapping.Wrap, Foreground = System.Windows.Media.Brushes.DimGray });
        win.Content = painel; win.ShowDialog();
    }

}