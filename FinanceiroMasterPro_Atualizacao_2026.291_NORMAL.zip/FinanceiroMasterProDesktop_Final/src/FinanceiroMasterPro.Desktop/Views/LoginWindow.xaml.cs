﻿using System;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using FinanceiroMasterPro.Application.Contracts;
using FinanceiroMasterPro.Infrastructure.Security;

namespace FinanceiroMasterPro.Desktop.Views;

public partial class LoginWindow : Window
{
    private readonly IAuthService _auth;
    private bool _sincronizandoSenha;
    private static string PreferenciasPath => Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
        "FinanceiroMasterPro", "usuario_login.txt");

    public LoginWindow(IAuthService auth)
    {
        InitializeComponent();
        _auth = auth;
        CarregarUsuarioLembrado();
    }

    private void CarregarUsuarioLembrado()
    {
        try
        {
            if (File.Exists(PreferenciasPath))
            {
                var lembrado = File.ReadAllText(PreferenciasPath).Trim();
                var existe = SecurityStore.Listar().Any(u => u.Ativo && u.Login.Equals(lembrado, StringComparison.OrdinalIgnoreCase));
                if (existe)
                {
                    LoginBox.Text = lembrado;
                    LembrarUsuarioCheck.IsChecked = true;
                }
                else
                {
                    File.Delete(PreferenciasPath);
                    LoginBox.Text = "";
                    LembrarUsuarioCheck.IsChecked = false;
                }
            }
        }
        catch { }
    }

    private void EscolherUsuario_Click(object sender, RoutedEventArgs e)
    {
        var usuarios = SecurityStore.Listar()
            .Where(u => u.Ativo)
            .OrderBy(u => u.Nome)
            .ThenBy(u => u.Login)
            .ToList();

        var menu = new ContextMenu();
        foreach (var usuario in usuarios)
        {
            var item = new MenuItem
            {
                Header = string.IsNullOrWhiteSpace(usuario.Nome)
                    ? usuario.Login
                    : $"{usuario.Nome}  ({usuario.Login})",
                Tag = usuario.Login,
                MinWidth = 220,
                Padding = new Thickness(10, 7, 10, 7)
            };
            item.Click += (_, __) =>
            {
                LoginBox.Text = (string)item.Tag;
                LoginBox.Focus();
                LoginBox.CaretIndex = LoginBox.Text.Length;
            };
            menu.Items.Add(item);
        }

        if (menu.Items.Count == 0)
        {
            menu.Items.Add(new MenuItem { Header = "Nenhum usuário ativo cadastrado", IsEnabled = false });
        }

        menu.PlacementTarget = UsuarioButton;
        menu.Placement = System.Windows.Controls.Primitives.PlacementMode.Bottom;
        menu.IsOpen = true;
    }

    private void SalvarPreferenciaUsuario()
    {
        try
        {
            Directory.CreateDirectory(Path.GetDirectoryName(PreferenciasPath)!);
            if (LembrarUsuarioCheck.IsChecked == true)
                File.WriteAllText(PreferenciasPath, LoginBox.Text.Trim());
            else if (File.Exists(PreferenciasPath))
                File.Delete(PreferenciasPath);
        }
        catch { }
    }

    private void Olho_Click(object sender, RoutedEventArgs e)
    {
        if (SenhaVisivelBox.Visibility == Visibility.Collapsed)
        {
            _sincronizandoSenha = true;
            SenhaVisivelBox.Text = SenhaBox.Password;
            _sincronizandoSenha = false;
            SenhaBox.Visibility = Visibility.Collapsed;
            SenhaVisivelBox.Visibility = Visibility.Visible;
            SenhaVisivelBox.Focus();
            SenhaVisivelBox.CaretIndex = SenhaVisivelBox.Text.Length;
        }
        else
        {
            _sincronizandoSenha = true;
            SenhaBox.Password = SenhaVisivelBox.Text;
            _sincronizandoSenha = false;
            SenhaVisivelBox.Visibility = Visibility.Collapsed;
            SenhaBox.Visibility = Visibility.Visible;
            SenhaBox.Focus();
        }
    }

    private void SenhaBox_PasswordChanged(object sender, RoutedEventArgs e)
    {
        if (_sincronizandoSenha) return;
        _sincronizandoSenha = true;
        SenhaVisivelBox.Text = SenhaBox.Password;
        _sincronizandoSenha = false;
    }

    private void SenhaVisivelBox_TextChanged(object sender, System.Windows.Controls.TextChangedEventArgs e)
    {
        if (_sincronizandoSenha) return;
        _sincronizandoSenha = true;
        SenhaBox.Password = SenhaVisivelBox.Text;
        _sincronizandoSenha = false;
    }

    private string SenhaDigitada =>
        SenhaVisivelBox.Visibility == Visibility.Visible ? SenhaVisivelBox.Text : SenhaBox.Password;


    private void LoginBox_PreviewKeyDown(object sender, System.Windows.Input.KeyEventArgs e)
    {
        if (e.Key != System.Windows.Input.Key.Enter) return;
        e.Handled = true;
        if (SenhaVisivelBox.Visibility == Visibility.Visible)
        {
            SenhaVisivelBox.Focus();
            SenhaVisivelBox.CaretIndex = SenhaVisivelBox.Text.Length;
        }
        else
        {
            SenhaBox.Focus();
        }
    }

    private void Entrar_Click(object sender, RoutedEventArgs e)
    {
        Erro.Text = "";
        if (_auth is LocalAuthService local)
        {
            var u = local.AutenticarSeguro(LoginBox.Text, SenhaDigitada, out var erro);
            if (u != null)
            {
                SalvarPreferenciaUsuario();
                DialogResult = true;
                Close();
                return;
            }
            Erro.Text = erro;
            return;
        }

        if (_auth.Autenticar(LoginBox.Text, SenhaDigitada) != null)
        {
            SalvarPreferenciaUsuario();
            DialogResult = true;
            Close();
        }
        else Erro.Text = "Usuário ou senha inválidos.";
    }


    private void GerenciarUsuarios_Click(object sender, RoutedEventArgs e)
    {
        Erro.Text = "";
        if (_auth is not LocalAuthService local)
        {
            Erro.Text = "Gerenciamento de usuários indisponível neste modo.";
            return;
        }

        var u = local.AutenticarSeguro(LoginBox.Text, SenhaDigitada, out var erro);
        if (u == null)
        {
            Erro.Text = erro;
            return;
        }
        if (!u.Administrador)
        {
            Erro.Text = "Somente um administrador pode gerenciar usuários.";
            return;
        }

        SecuritySession.CurrentUser = u;
        var w = new Window
        {
            Title = "Financeiro Master Pro - Usuários / Segurança",
            Width = 1100, Height = 700, MinWidth = 900, MinHeight = 600,
            WindowStartupLocation = WindowStartupLocation.CenterScreen,
            Content = new UsuariosSegurancaView(),
            Owner = this
        };
        w.ShowDialog();
        SecuritySession.CurrentUser = null;
    }

    private void EsqueciSenha_Click(object sender, RoutedEventArgs e)
    {
        MessageBox.Show(
            "Solicite ao administrador do sistema a redefinição da sua senha.\n\n" +
            "Por segurança, a senha atual não pode ser exibida ou recuperada.",
            "Esqueci minha senha", MessageBoxButton.OK, MessageBoxImage.Information);
    }

}
