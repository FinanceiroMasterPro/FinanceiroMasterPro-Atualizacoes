using FinanceiroMasterPro.Infrastructure.Data;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace FinanceiroMasterPro.Desktop.Views;

public partial class GrupoContasView : UserControl
{
    private readonly GrupoContasRepository _repository = new();
    private List<GrupoContas> _grupos = new();

    private long _idAtual = 0;

    public GrupoContasView()
    {
        InitializeComponent();

        CarregarGrupos();
        Novo();
    }

    private void CarregarGrupos()
    {
        _grupos = _repository.Listar();

        GridGrupos.ItemsSource = null;
        GridGrupos.ItemsSource = _grupos;
    }

    private void Novo()
    {
        _idAtual = 0;

        TxtNome.Clear();
        ChkAtivo.IsChecked = true;

        GridGrupos.SelectedItem = null;

        TxtNome.Focus();
    }

    private void Novo_Click(object sender, RoutedEventArgs e)
    {
        Novo();
    }

    private void Salvar_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            if (string.IsNullOrWhiteSpace(TxtNome.Text))
            {
                MessageBox.Show(
                    "Informe o nome do Grupo de Contas.",
                    "Financeiro Master Pro",
                    MessageBoxButton.OK,
                    MessageBoxImage.Information);

                TxtNome.Focus();
                return;
            }

            var grupo = new GrupoContas
            {
                Id = _idAtual,
                Nome = TxtNome.Text,
                Ativo = ChkAtivo.IsChecked == true
            };

            _idAtual = _repository.Salvar(grupo);

            MessageBox.Show(
                "Grupo de Contas salvo com sucesso.",
                "Financeiro Master Pro",
                MessageBoxButton.OK,
                MessageBoxImage.Information);

            CarregarGrupos();
            Novo();
        }
        catch (System.Exception ex)
        {
            MessageBox.Show(
                $"Não foi possível salvar o Grupo de Contas.\n\n{ex.Message}",
                "Financeiro Master Pro",
                MessageBoxButton.OK,
                MessageBoxImage.Error);
        }
    }

    private void GridGrupos_SelectionChanged(
        object sender,
        SelectionChangedEventArgs e)
    {
        if (GridGrupos.SelectedItem is not GrupoContas grupo)
            return;

        _idAtual = grupo.Id;

        TxtNome.Text = grupo.Nome;
        ChkAtivo.IsChecked = grupo.Ativo;
    }

    private void AlterarStatus_Click(object sender, RoutedEventArgs e)
    {
        if (_idAtual == 0)
        {
            MessageBox.Show(
                "Selecione um Grupo de Contas na lista.",
                "Financeiro Master Pro",
                MessageBoxButton.OK,
                MessageBoxImage.Information);

            return;
        }

        bool novoStatus = ChkAtivo.IsChecked != true;

        _repository.AlterarStatus(_idAtual, novoStatus);

        CarregarGrupos();
        Novo();
    }

    private void Pesquisar_TextChanged(
        object sender,
        TextChangedEventArgs e)
    {
        string pesquisa = TxtPesquisar.Text.Trim().ToLower();

        if (string.IsNullOrWhiteSpace(pesquisa))
        {
            GridGrupos.ItemsSource = _grupos;
            return;
        }

        GridGrupos.ItemsSource =
            _grupos
                .Where(g => PesquisaAvancada.Texto(g.Nome,pesquisa))
                .ToList();
    }

    private void Alterar_Click(object sender, RoutedEventArgs e)
    {
        if (_idAtual == 0)
        {
            MessageBox.Show("Selecione um cadastro na lista para alterar.", "Financeiro Master Pro", MessageBoxButton.OK, MessageBoxImage.Information);
            return;
        }
        Salvar_Click(sender, e);
    }

    private void Excluir_Click(object sender, RoutedEventArgs e)
    {
        if (_idAtual == 0)
        {
            MessageBox.Show("Selecione um cadastro na lista para excluir.", "Financeiro Master Pro", MessageBoxButton.OK, MessageBoxImage.Information);
            return;
        }

        var resposta = MessageBox.Show(
            "Deseja realmente excluir este cadastro?\n\nSe ele estiver vinculado a lançamentos, parcelamentos ou rateios, a exclusão será bloqueada para proteger os dados.",
            "Financeiro Master Pro",
            MessageBoxButton.YesNo,
            MessageBoxImage.Warning);
        if (resposta != MessageBoxResult.Yes) return;

        try
        {
            _repository.Excluir(_idAtual);
            CarregarGrupos();
            Novo();
        }
        catch (System.Exception ex)
        {
            MessageBox.Show(ex.Message, "Financeiro Master Pro", MessageBoxButton.OK, MessageBoxImage.Information);
        }
    }

    private void Cadastro_PreviewKeyDown(object sender, KeyEventArgs e)
    {
        if (e.Key != Key.Enter) return;
        if (Keyboard.FocusedElement is Button) return;
        e.Handled = true;
        (Keyboard.FocusedElement as UIElement)?.MoveFocus(new TraversalRequest(FocusNavigationDirection.Next));
    }
    private void AlterarLote_Click(object sender, RoutedEventArgs e)
    {
        var selecionados = GridGrupos.SelectedItems.Cast<GrupoContas>().ToList();
        if (selecionados.Count == 0)
        {
            MessageBox.Show("Selecione um ou mais cadastros. Use Ctrl+clique para selecionar vários.", "Financeiro Master Pro", MessageBoxButton.OK, MessageBoxImage.Information);
            return;
        }
        var janela = new EdicaoLoteWindow(selecionados.Count) { Owner = Window.GetWindow(this) };
        if (janela.ShowDialog() != true) return;
        int alterados = 0;
        foreach (var item in selecionados)
        {
            if (!item.Nome.Contains(janela.Localizar, System.StringComparison.OrdinalIgnoreCase)) continue;
            item.Nome = System.Text.RegularExpressions.Regex.Replace(item.Nome, System.Text.RegularExpressions.Regex.Escape(janela.Localizar), janela.Substituir, System.Text.RegularExpressions.RegexOptions.IgnoreCase).Trim();
            _repository.Salvar(item); alterados++;
        }
        CarregarGrupos();
        MessageBox.Show($"{alterados} cadastro(s) alterado(s).", "Financeiro Master Pro", MessageBoxButton.OK, MessageBoxImage.Information);
    }

    private void ExcluirLote_Click(object sender, RoutedEventArgs e)
    {
        var selecionados = GridGrupos.SelectedItems.Cast<GrupoContas>().ToList();
        if (selecionados.Count == 0)
        {
            MessageBox.Show("Selecione um ou mais cadastros para excluir.", "Financeiro Master Pro", MessageBoxButton.OK, MessageBoxImage.Information); return;
        }
        if (MessageBox.Show($"Excluir {selecionados.Count} cadastro(s) selecionado(s)?\n\nCadastros vinculados serão protegidos pelo sistema.", "Financeiro Master Pro", MessageBoxButton.YesNo, MessageBoxImage.Warning) != MessageBoxResult.Yes) return;
        int excluidos=0, bloqueados=0;
        foreach (var item in selecionados)
        {
            try { _repository.Excluir(item.Id); excluidos++; } catch { bloqueados++; }
        }
        CarregarGrupos(); Novo();
        MessageBox.Show($"Excluídos: {excluidos}\nProtegidos/bloqueados: {bloqueados}", "Financeiro Master Pro", MessageBoxButton.OK, MessageBoxImage.Information);
    }

}
