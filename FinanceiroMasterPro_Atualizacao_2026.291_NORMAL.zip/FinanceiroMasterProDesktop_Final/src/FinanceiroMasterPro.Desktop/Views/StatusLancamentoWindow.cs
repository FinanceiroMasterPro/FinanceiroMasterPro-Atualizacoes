﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace FinanceiroMasterPro.Desktop.Views;

public enum StatusLancamentoEscolha { Pagar, Receber, Pago, Recebido, Transferencia }

public sealed class StatusLancamentoWindow : Window
{
    public StatusLancamentoEscolha Escolha { get; private set; }

    public StatusLancamentoWindow()
    {
        Title = "Confirmar Status do Lançamento";
        Width = 760;
        Height = 190;
        WindowStartupLocation = WindowStartupLocation.CenterOwner;
        ResizeMode = ResizeMode.NoResize;
        Background = Brushes.White;

        var raiz = new StackPanel { Margin = new Thickness(22, 18, 22, 15) };
        raiz.Children.Add(new TextBlock { Text = "Este lançamento é:", FontSize = 15, FontWeight = FontWeights.SemiBold, Margin = new Thickness(0,0,0,14) });

        var botoes = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Center };
        AdicionarBotao(botoes, "PAGAR", StatusLancamentoEscolha.Pagar);
        AdicionarBotao(botoes, "RECEBER", StatusLancamentoEscolha.Receber);
        AdicionarBotao(botoes, "PAGO", StatusLancamentoEscolha.Pago);
        AdicionarBotao(botoes, "RECEBIDO", StatusLancamentoEscolha.Recebido);
        AdicionarBotao(botoes, "TRANSFERÊNCIA", StatusLancamentoEscolha.Transferencia);
        raiz.Children.Add(botoes);
        raiz.Children.Add(new TextBlock { Text = "PAGO ou RECEBIDO preenche o PERÍODO automaticamente.", Margin = new Thickness(0,16,0,0), HorizontalAlignment = HorizontalAlignment.Center, Foreground = Brushes.DimGray });
        Content = raiz;
    }

    private void AdicionarBotao(Panel painel, string texto, StatusLancamentoEscolha escolha)
    {
        var b = new Button { Content = texto, Width = 120, Height = 38, Margin = new Thickness(5,0,5,0), FontWeight = FontWeights.SemiBold };
        b.Click += (_, _) => { Escolha = escolha; DialogResult = true; };
        painel.Children.Add(b);
    }
}
