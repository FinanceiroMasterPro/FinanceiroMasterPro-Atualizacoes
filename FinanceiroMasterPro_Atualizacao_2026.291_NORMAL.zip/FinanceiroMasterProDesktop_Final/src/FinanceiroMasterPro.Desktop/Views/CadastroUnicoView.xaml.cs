using FinanceiroMasterPro.Infrastructure.Data;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
namespace FinanceiroMasterPro.Desktop.Views;
public partial class CadastroUnicoView:UserControl{
 long? _vinculoSelecionadoId;
 readonly PlanoContasRepository _p=new();readonly CentroCustosRepository _c=new();readonly GrupoContasRepository _g=new();readonly FluxoCaixaRepository _f=new();readonly ClassificacaoPlanoRepository _v=new();
 public CadastroUnicoView(){InitializeComponent();Carregar();}
 void Carregar(){Plano.ItemsSource=_p.Listar().Where(x=>x.Ativo).ToList();Centro.ItemsSource=_c.Listar().Where(x=>x.Ativo).ToList();Grupo.ItemsSource=_g.Listar().Where(x=>x.Ativo).ToList();Fluxo.ItemsSource=_f.Listar().Where(x=>x.Ativo).ToList();GridVinculos.ItemsSource=_v.Listar();AplicarPesquisa();}
 void Cadastro_PreviewKeyDown(object s,KeyEventArgs e){if(e.Key!=Key.Enter||Keyboard.FocusedElement is Button)return;e.Handled=true;(Keyboard.FocusedElement as UIElement)?.MoveFocus(new TraversalRequest(FocusNavigationDirection.Next));}
 void Maiusculo_LostFocus(object s,RoutedEventArgs e){if(s is ComboBox c)c.Text=(c.Text??"").Trim().ToUpperInvariant();}
 void Pesquisa_TextChanged(object s,TextChangedEventArgs e)=>AplicarPesquisa();
 void AplicarPesquisa(){if(GridVinculos==null)return;var p=TxtPesquisa?.Text?.Trim()??"";var q=_v.Listar().AsEnumerable();if(!string.IsNullOrWhiteSpace(p))q=q.Where(v=>PesquisaAvancada.Texto(v.PlanoNome,p)||PesquisaAvancada.Texto(v.GrupoNome,p)||PesquisaAvancada.Texto(v.FluxoNome,p));GridVinculos.ItemsSource=q.ToList();}
 string Texto(ComboBox c)=>(c.Text??"").Trim().ToUpperInvariant();
 PlanoContas PlanoOk(){var n=Texto(Plano);var x=_p.Listar().FirstOrDefault(z=>z.Nome.Equals(n,StringComparison.OrdinalIgnoreCase));if(x!=null){if(x.Nome!=n){x.Nome=n;_p.Salvar(x);}return x;}var y=new PlanoContas{Nome=n,Ativo=true};y.Id=_p.Salvar(y);return y;}
 CentroCustos CentroOk(){var n=Texto(Centro);var x=_c.Listar().FirstOrDefault(z=>z.Nome.Equals(n,StringComparison.OrdinalIgnoreCase));if(x!=null){if(x.Nome!=n){x.Nome=n;_c.Salvar(x);}return x;}var y=new CentroCustos{Nome=n,Ativo=true};y.Id=_c.Salvar(y);return y;}
 GrupoContas GrupoOk(){var n=Texto(Grupo);var x=_g.Listar().FirstOrDefault(z=>z.Nome.Equals(n,StringComparison.OrdinalIgnoreCase));if(x!=null){if(x.Nome!=n){x.Nome=n;_g.Salvar(x);}return x;}var y=new GrupoContas{Nome=n,Ativo=true};y.Id=_g.Salvar(y);return y;}
 FluxoCaixa FluxoOk(){var n=Texto(Fluxo);var x=_f.Listar().FirstOrDefault(z=>z.Nome.Equals(n,StringComparison.OrdinalIgnoreCase));if(x!=null){if(x.Nome!=n){x.Nome=n;_f.Salvar(x);}return x;}var y=new FluxoCaixa{Nome=n,Ativo=true};y.Id=_f.Salvar(y);return y;}
 void Salvar_Click(object s,RoutedEventArgs e){
   if(string.IsNullOrWhiteSpace(Texto(Plano))||string.IsNullOrWhiteSpace(Texto(Grupo))||string.IsNullOrWhiteSpace(Texto(Fluxo))){MessageBox.Show("Informe Plano de Contas, Grupo de Contas e Fluxo de Caixa.","Financeiro Master Pro");return;}
   try{var p=PlanoOk();CentroCustos? c=null;if(!string.IsNullOrWhiteSpace(Texto(Centro)))c=CentroOk();var g=GrupoOk();var f=FluxoOk();var editando=_vinculoSelecionadoId.HasValue;_v.Salvar(p.Id,g.Id,f.Id,c?.Id,_vinculoSelecionadoId);Carregar();SelecionarVinculo(p.Id,g.Id,f.Id);MessageBox.Show(editando?"Cadastro alterado com sucesso.":"Cadastro realizado com sucesso.","Financeiro Master Pro");}
   catch(Exception ex){MessageBox.Show(ex.Message,"Financeiro Master Pro");}
 }
 void SelecionarVinculo(long p,long g,long f){var item=_v.Listar().FirstOrDefault(x=>x.PlanoContasId==p&&x.GrupoContasId==g&&x.FluxoCaixaId==f);if(item!=null){GridVinculos.SelectedItem=item;GridVinculos.ScrollIntoView(item);}}
 void Novo_Click(object s,RoutedEventArgs e)=>Novo();
 void Novo(){_vinculoSelecionadoId=null;GridVinculos.SelectedItem=null;Plano.SelectedItem=null;Plano.Text="";Centro.SelectedItem=null;Centro.Text="";Grupo.SelectedItem=null;Grupo.Text="";Fluxo.SelectedItem=null;Fluxo.Text="";Plano.Focus();}
 void GridVinculos_SelectionChanged(object s,SelectionChangedEventArgs e){
   if(GridVinculos.SelectedItem is not ClassificacaoPlano v)return;_vinculoSelecionadoId=v.Id;
   var p=_p.Listar().FirstOrDefault(x=>x.Id==v.PlanoContasId);var c=v.CentroCustosId.HasValue?_c.Listar().FirstOrDefault(x=>x.Id==v.CentroCustosId.Value):null;var g=_g.Listar().FirstOrDefault(x=>x.Id==v.GrupoContasId);var f=_f.Listar().FirstOrDefault(x=>x.Id==v.FluxoCaixaId);
   if(p!=null){Plano.SelectedItem=p;Plano.Text=p.Nome;}if(c!=null){Centro.SelectedItem=c;Centro.Text=c.Nome;}else{Centro.SelectedItem=null;Centro.Text="";}if(g!=null){Grupo.SelectedItem=g;Grupo.Text=g.Nome;}if(f!=null){Fluxo.SelectedItem=f;Fluxo.Text=f.Nome;}
 }
 void Excluir_Click(object s,RoutedEventArgs e){if(GridVinculos.SelectedItem is not ClassificacaoPlano v)return;if(MessageBox.Show($"Excluir o vínculo?\n\n{v.PlanoNome} → {v.GrupoNome} → {v.FluxoNome}","Financeiro Master Pro",MessageBoxButton.YesNo,MessageBoxImage.Question)!=MessageBoxResult.Yes)return;_v.Excluir(v.Id);Carregar();}

 void Alterar_Click(object s,RoutedEventArgs e){
   if(GridVinculos.SelectedItem is not ClassificacaoPlano){MessageBox.Show("Selecione um cadastro para alterar.","Financeiro Master Pro");return;}
   Plano.Focus();
 }
 void ExcluirSelecionado_Click(object s,RoutedEventArgs e)=>Excluir_Click(s,e);
 void SelecionarTodos_Click(object s,RoutedEventArgs e){GridVinculos.SelectAll();}
 List<ClassificacaoPlano> Selecionados()=>GridVinculos.SelectedItems.Cast<ClassificacaoPlano>().ToList();
 void ExcluirLote_Click(object s,RoutedEventArgs e){
   var itens=Selecionados();if(itens.Count==0){MessageBox.Show("Selecione um ou mais cadastros.","Financeiro Master Pro");return;}
   if(MessageBox.Show($"Excluir {itens.Count} vínculo(s) selecionado(s)?\n\nOs cadastros usados em lançamentos permanecem protegidos.","Financeiro Master Pro",MessageBoxButton.YesNo,MessageBoxImage.Question)!=MessageBoxResult.Yes)return;
   var erros=0;foreach(var x in itens){try{_v.Excluir(x.Id);}catch{erros++;}}Carregar();
   MessageBox.Show(erros==0?$"{itens.Count} vínculo(s) excluído(s).":$"Exclusão concluída. {erros} item(ns) não puderam ser excluídos.","Financeiro Master Pro");
 }
 void AlterarLote_Click(object s,RoutedEventArgs e)=>AbrirSubstituicao(true);
 void LocalizarSubstituir_Click(object s,RoutedEventArgs e)=>AbrirSubstituicao(false);
 void AbrirSubstituicao(bool somenteSelecionados){
   var itens=somenteSelecionados?Selecionados():GridVinculos.Items.Cast<ClassificacaoPlano>().ToList();
   if(itens.Count==0){MessageBox.Show(somenteSelecionados?"Selecione um ou mais cadastros.":"Não há cadastros na lista atual.","Financeiro Master Pro");return;}
   var win=new Window{Title=somenteSelecionados?"ALTERAR EM LOTE":"LOCALIZAR / SUBSTITUIR",Width=590,Height=390,MinWidth=590,MinHeight=390,SizeToContent=SizeToContent.Manual,WindowStartupLocation=WindowStartupLocation.CenterOwner,Owner=Window.GetWindow(this),ResizeMode=ResizeMode.NoResize};
   var raiz=new StackPanel{Margin=new Thickness(18,18,18,22)};
   raiz.Children.Add(new TextBlock{Text=$"Registros: {itens.Count}",FontWeight=FontWeights.Bold,Margin=new Thickness(0,0,0,10)});
   raiz.Children.Add(new TextBlock{Text="CAMPO:"});var campo=new ComboBox{Height=30,Margin=new Thickness(0,3,0,10)};campo.ItemsSource=new[]{"PLANO DE CONTAS","CENTRO DE CUSTOS","GRUPO DE CONTAS","FLUXO DE CAIXA"};campo.SelectedIndex=0;raiz.Children.Add(campo);
   raiz.Children.Add(new TextBlock{Text="LOCALIZAR:"});var localizar=new TextBox{Height=30,Margin=new Thickness(0,3,0,10)};raiz.Children.Add(localizar);
   raiz.Children.Add(new TextBlock{Text="SUBSTITUIR POR: (pode ficar vazio)"});var substituir=new TextBox{Height=30,Margin=new Thickness(0,3,0,12)};raiz.Children.Add(substituir);
   var botoes=new StackPanel{Orientation=Orientation.Horizontal,HorizontalAlignment=HorizontalAlignment.Right,Margin=new Thickness(0,8,0,0)};var cancelar=new Button{Content="CANCELAR",Width=120,Height=36,Margin=new Thickness(5),Foreground=System.Windows.Media.Brushes.Black,Background=System.Windows.Media.Brushes.LightGray};var aplicar=new Button{Content=somenteSelecionados?"APLICAR ALTERAÇÃO":"SUBSTITUIR TODOS",Width=165,Height=36,Margin=new Thickness(5),FontWeight=FontWeights.Bold,Foreground=System.Windows.Media.Brushes.Black,Background=System.Windows.Media.Brushes.LightGray};cancelar.Click+=(_,__)=>win.Close();aplicar.Click+=(_,__)=>{var de=(localizar.Text??"");if(string.IsNullOrEmpty(de)){MessageBox.Show("Informe o texto a localizar.","Financeiro Master Pro");return;}var para=(substituir.Text??"");var encontrados=ContarSubstituicoes(itens,campo.SelectedIndex,de);if(encontrados==0){MessageBox.Show("Nenhum cadastro encontrado com esse texto.","Financeiro Master Pro");return;}if(MessageBox.Show($"Serão alterados {encontrados} cadastro(s).\n\nDeseja continuar?","Financeiro Master Pro",MessageBoxButton.YesNo,MessageBoxImage.Question)!=MessageBoxResult.Yes)return;var n=AplicarSubstituicao(itens,campo.SelectedIndex,de,para);win.Close();Carregar();MessageBox.Show($"Alteração concluída em {n} cadastro(s).","Financeiro Master Pro");};botoes.Children.Add(cancelar);botoes.Children.Add(aplicar);raiz.Children.Add(botoes);win.Content=raiz;win.ShowDialog();
 }
 int ContarSubstituicoes(List<ClassificacaoPlano> itens,int campo,string de){
   var ids=new HashSet<long>();var n=0;
   foreach(var v in itens){
    if(campo==0 && ids.Add(v.PlanoContasId)){var x=_p.Listar().FirstOrDefault(z=>z.Id==v.PlanoContasId);if(x!=null&&x.Nome.Contains(de,StringComparison.OrdinalIgnoreCase))n++;}
    else if(campo==1 && v.CentroCustosId.HasValue && ids.Add(v.CentroCustosId.Value)){var x=_c.Listar().FirstOrDefault(z=>z.Id==v.CentroCustosId.Value);if(x!=null&&x.Nome.Contains(de,StringComparison.OrdinalIgnoreCase))n++;}
    else if(campo==2 && ids.Add(v.GrupoContasId)){var x=_g.Listar().FirstOrDefault(z=>z.Id==v.GrupoContasId);if(x!=null&&x.Nome.Contains(de,StringComparison.OrdinalIgnoreCase))n++;}
    else if(campo==3 && ids.Add(v.FluxoCaixaId)){var x=_f.Listar().FirstOrDefault(z=>z.Id==v.FluxoCaixaId);if(x!=null&&x.Nome.Contains(de,StringComparison.OrdinalIgnoreCase))n++;}
   }return n;
 }

 int AplicarSubstituicao(List<ClassificacaoPlano> itens,int campo,string de,string para){
   var alterados=0;var ids=new HashSet<long>();
   foreach(var v in itens){
    if(campo==0 && ids.Add(v.PlanoContasId)){var x=_p.Listar().FirstOrDefault(z=>z.Id==v.PlanoContasId);if(x!=null&&x.Nome.Contains(de,StringComparison.OrdinalIgnoreCase)){x.Nome=SubstituirCI(x.Nome,de,para).Trim().ToUpperInvariant();_p.Salvar(x);alterados++;}}
    else if(campo==1 && v.CentroCustosId.HasValue && ids.Add(v.CentroCustosId.Value)){var x=_c.Listar().FirstOrDefault(z=>z.Id==v.CentroCustosId.Value);if(x!=null&&x.Nome.Contains(de,StringComparison.OrdinalIgnoreCase)){x.Nome=SubstituirCI(x.Nome,de,para).Trim().ToUpperInvariant();_c.Salvar(x);alterados++;}}
    else if(campo==2 && ids.Add(v.GrupoContasId)){var x=_g.Listar().FirstOrDefault(z=>z.Id==v.GrupoContasId);if(x!=null&&x.Nome.Contains(de,StringComparison.OrdinalIgnoreCase)){x.Nome=SubstituirCI(x.Nome,de,para).Trim().ToUpperInvariant();_g.Salvar(x);alterados++;}}
    else if(campo==3 && ids.Add(v.FluxoCaixaId)){var x=_f.Listar().FirstOrDefault(z=>z.Id==v.FluxoCaixaId);if(x!=null&&x.Nome.Contains(de,StringComparison.OrdinalIgnoreCase)){x.Nome=SubstituirCI(x.Nome,de,para).Trim().ToUpperInvariant();_f.Salvar(x);alterados++;}}
   }return alterados;
 }
 static string SubstituirCI(string texto,string localizar,string substituir){
   var i=texto.IndexOf(localizar,StringComparison.OrdinalIgnoreCase);while(i>=0){texto=texto[..i]+substituir+texto[(i+localizar.Length)..];i=texto.IndexOf(localizar,i+substituir.Length,StringComparison.OrdinalIgnoreCase);}return texto;
 }
}