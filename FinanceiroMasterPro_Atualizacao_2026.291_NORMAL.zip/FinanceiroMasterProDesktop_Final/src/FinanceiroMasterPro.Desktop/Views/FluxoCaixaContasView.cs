﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.IO;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Media;
using FinanceiroMasterPro.Infrastructure.Data;

namespace FinanceiroMasterPro.Desktop.Views;

public sealed class FluxoCaixaContasView : UserControl
{
    readonly DatePicker _dataInicial = new() { Width=150, Height=30, Margin=new Thickness(4,0,6,0), SelectedDate=DateTime.Today, VerticalContentAlignment=VerticalAlignment.Center };
    readonly DatePicker _dataFinal = new() { Width=150, Height=30, Margin=new Thickness(4,0,10,0), SelectedDate=DateTime.Today.AddDays(7), VerticalContentAlignment=VerticalAlignment.Center };
    readonly CheckBox _vencidos = new() { Content="Vencidos", IsChecked=true, VerticalAlignment=VerticalAlignment.Center, Margin=new Thickness(0,0,14,0) };
    readonly Button _status = new() { Content="Todos ▼", Width=150, Height=30, Margin=new Thickness(4,0,10,0), Padding=new Thickness(8,0,8,0) };
    readonly HashSet<string> _statusSelecionados = new(StringComparer.OrdinalIgnoreCase) { "Pagar", "Receber", "Pago", "Recebido", "Transferência" };
    readonly Button _conta = new() { Content="Contas ▼", Width=245, Height=30, Margin=new Thickness(4,0,8,0), Padding=new Thickness(8,0,8,0) };
    readonly CheckBox _agrupar = new() { Content="Agrupar", IsChecked=true, VerticalAlignment=VerticalAlignment.Center, Margin=new Thickness(0,0,12,0) };
    readonly DataGrid _grid = new() { AutoGenerateColumns=false, IsReadOnly=true, CanUserAddRows=false, CanUserResizeColumns=true, CanUserReorderColumns=false, HeadersVisibility=DataGridHeadersVisibility.Column, GridLinesVisibility=DataGridGridLinesVisibility.All, SelectionMode=DataGridSelectionMode.Single, HorizontalGridLinesBrush=Brush("#C7C7C7"), VerticalGridLinesBrush=Brush("#D3D3D3") };
    readonly ContaBancariaRepository _contasRepo = new();
    readonly LancamentoRepository _lancRepo = new();
    string _pesquisa="";
    readonly HashSet<long> _contasSelecionadas = new();
    bool _carregandoPreferencias;
    string PreferenciasPath => Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "FinanceiroMasterPro", "fluxo-caixa-contas.json");

    public FluxoCaixaContasView()
    {
        BuildUi();
        PrepararDataPicker(_dataInicial); PrepararDataPicker(_dataFinal);
        Loaded += (_,__) => Carregar();
        Unloaded += (_,__) => SalvarPreferencias();
    }

    void BuildUi()
    {
        var root=new DockPanel{Margin=new Thickness(10),LastChildFill=true};
        var top=new StackPanel{Orientation=Orientation.Vertical}; DockPanel.SetDock(top,Dock.Top);
        top.Children.Add(new TextBlock{Text="PREVISÃO DE FLUXO DE CAIXA POR CONTA",FontSize=24,FontWeight=FontWeights.Bold,Foreground=Brush("#5A14B8"),Margin=new Thickness(2,0,0,10)});
        var filtros=new WrapPanel{VerticalAlignment=VerticalAlignment.Center};
        filtros.Children.Add(Lbl("De")); filtros.Children.Add(_dataInicial); filtros.Children.Add(Lbl("Até")); filtros.Children.Add(_dataFinal);
        _dataInicial.SelectedDateChanged+=(_,__)=>{if(IsLoaded)Atualizar();}; _dataFinal.SelectedDateChanged+=(_,__)=>{if(IsLoaded)Atualizar();};
        filtros.Children.Add(_vencidos);
        _vencidos.Checked+=(_,__)=>{if(IsLoaded)Atualizar();}; _vencidos.Unchecked+=(_,__)=>{if(IsLoaded)Atualizar();};
        filtros.Children.Add(Lbl("Status")); _status.Click+=(_,__)=>PersonalizarStatus(); filtros.Children.Add(_status);
        filtros.Children.Add(Lbl("Contas")); _conta.Click+=(_,__)=>PersonalizarContas(); filtros.Children.Add(_conta); filtros.Children.Add(_agrupar);
        _agrupar.Checked+=(_,__)=>{if(IsLoaded)Atualizar();}; _agrupar.Unchecked+=(_,__)=>{if(IsLoaded)Atualizar();};
        var pesquisar=Btn("🔎  PESQUISA AVANÇADA"); pesquisar.Click+=(_,__)=>PesquisaAvancada(); filtros.Children.Add(pesquisar);
        var limpar=Btn("LIMPAR PESQUISA"); limpar.Margin=new Thickness(6,0,0,0); limpar.Click+=(_,__)=>{_pesquisa="";Atualizar();}; filtros.Children.Add(limpar);
        var relatorios=Btn("RELATÓRIOS"); relatorios.Margin=new Thickness(12,0,0,0); relatorios.Click+=(_,__)=>AbrirRelatorio(); filtros.Children.Add(relatorios);
        var atualizar=Btn("ATUALIZAR"); atualizar.Margin=new Thickness(6,0,0,0); atualizar.Click+=(_,__)=>Atualizar(); filtros.Children.Add(atualizar);
        top.Children.Add(filtros);
        top.Children.Add(new TextBlock{Text="Dê 2 cliques em um lançamento para abrir a mesma tela e alterar ou excluir.",Foreground=Brush("#356A9A"),Margin=new Thickness(2,8,0,4),FontSize=12});
        root.Children.Add(top);

        _grid.Margin=new Thickness(0,6,0,0); _grid.RowHeight=28; _grid.ColumnHeaderHeight=30; _grid.FontSize=13;
        _grid.ColumnHeaderStyle = CabecalhoColuna();
        // OPÇÃO 1: mesmas proporções da referência enviada. As colunas são reais e
        // independentes, inclusive VALOR e SALDO, para o arraste/redimensionamento.
        _grid.Columns.Add(ColCentro("Status","Status",200));
        _grid.Columns.Add(ColVencimento("Vencimento","VencimentoExibicao",235));
        _grid.Columns.Add(ColDescricao("Descrição","Descricao",new DataGridLength(2.35,DataGridLengthUnitType.Star)));
        _grid.Columns.Add(Col("Plano de Conta","Plano",new DataGridLength(1.55,DataGridLengthUnitType.Star)));
        _grid.Columns.Add(ColCentro("Centro de Custo","CentroCusto",new DataGridLength(1.25,DataGridLengthUnitType.Star)));
        _grid.Columns.Add(ColDireita("Valor","ValorExibicao",190));
        _grid.Columns.Add(ColSaldoFinal("Saldo","SaldoExibicao",190));
        foreach(var coluna in _grid.Columns) coluna.MinWidth = 70;
        _grid.Columns[0].MinWidth = 90;
        _grid.Columns[1].MinWidth = 110;
        _grid.Columns[2].MinWidth = 180;
        _grid.Columns[3].MinWidth = 150;
        _grid.Columns[4].MinWidth = 130;
        _grid.Columns[5].MinWidth = 100;
        _grid.Columns[6].MinWidth = 105;
        _grid.LoadingRow+=Grid_LoadingRow; _grid.MouseDoubleClick+=Grid_DoubleClick;
        root.Children.Add(_grid); Content=root;
    }

    void Carregar()
    {
        var contas=_contasRepo.Listar().Where(x=>x.Ativo).OrderBy(x=>x.Nome).ToList();
        _contasSelecionadas.Clear();
        CarregarPreferencias();
        if(_contasSelecionadas.Count==0 && contas.Count>0) _contasSelecionadas.Add(contas[0].Id);
        AtualizarTextoContas();
        Atualizar();
    }

    void Atualizar()
    {
        if(IsLoaded && !_carregandoPreferencias) SalvarPreferencias();
        var hoje=DateTime.Today; var inicio=(_dataInicial.SelectedDate??hoje).Date; var fim=(_dataFinal.SelectedDate??inicio).Date; if(fim<inicio)(inicio,fim)=(fim,inicio);
        var contas=_contasRepo.Listar().Where(c=>c.Ativo&&_contasSelecionadas.Contains(c.Id)).OrderBy(c=>c.Nome).ToList();
        var lancs=_lancRepo.Listar().Where(l=>l.Ativo&&l.ContaBancariaId.HasValue&&l.DataPagamento.HasValue).ToList();
        var linhas=new List<Linha>();
        foreach(var c in contas)
        {
            var lc=lancs.Where(l=>l.ContaBancariaId==c.Id).ToList();
            decimal saldo=c.SaldoInicial+lc.Where(l=>l.Baixado&&l.DataPagamento!.Value.Date<hoje).Sum(Assinado);
            var statusTodos=_statusSelecionados.Count==5;
            var mostrarVencidos = _vencidos.IsChecked == true;
            var periodo=lc.Where(l =>
                    l.DataPagamento!.Value.Date <= fim &&
                    (
                        // Período normal: ao desligar VENCIDOS, não mostra títulos em aberto já vencidos.
                        (l.DataPagamento.Value.Date >= inicio && (mostrarVencidos || l.Baixado || l.DataPagamento.Value.Date >= hoje))
                        // VENCIDOS ligado: inclui também os títulos em aberto anteriores à data inicial.
                        || (mostrarVencidos && !l.Baixado && l.DataPagamento.Value.Date < inicio)
                    ))
                .Where(l=>statusTodos || _statusSelecionados.Contains(l.TipoExibicao??""))
                .Where(l=>string.IsNullOrWhiteSpace(_pesquisa)||Texto(l).Contains(_pesquisa,StringComparison.OrdinalIgnoreCase))
                .OrderBy(l=>l.DataPagamento).ThenBy(l=>l.Id).ToList();
            decimal ent=0,sai=0; foreach(var l in periodo){var v=Assinado(l);if(v>=0)ent+=v;else sai+=Math.Abs(v);}
            // O cabeçalho da conta aparece nos dois modos. No AGRUPAR ficam
            // somente os cabeçalhos/resumos; no DESAGRUPAR aparecem os lançamentos.
            linhas.Add(Linha.Conta(c.Nome,ent,sai,saldo+periodo.Sum(Assinado),saldo));
            if(_agrupar.IsChecked!=true)
            {
                foreach(var l in periodo)
                {
                    var v=Assinado(l); saldo+=v;
                    linhas.Add(Linha.De(l,saldo,hoje));
                }
                // Destaca somente o saldo final (última linha) de cada conta.
                if(linhas.Count>0 && !linhas[^1].EhConta) linhas[^1].EhSaldoFinal=true;
            }
            // Uma linha em branco separa visualmente uma conta da próxima.
            linhas.Add(Linha.Espaco());
        }
        _grid.ItemsSource=linhas;
    }

    void Grid_DoubleClick(object sender, MouseButtonEventArgs e)
    {
        if(_grid.SelectedItem is not Linha x || x.LancamentoId<=0) return;
        if(Window.GetWindow(this) is MainWindow w) w.AbrirLancamentoPorId(x.LancamentoId);
    }

    void Grid_LoadingRow(object? sender, DataGridRowEventArgs e)
    {
        if(e.Row.Item is not Linha x) return;
        e.Row.FontWeight=x.EhConta||x.EhSaldo?FontWeights.SemiBold:FontWeights.Normal;
        e.Row.Background=x.EhConta?Brush("#F1ECFA"):Brush("#FFFFFF");
        e.Row.ClipToBounds=true;
        if (x.EhEspaco)
        {
            e.Row.MinHeight = 14;
            e.Row.MaxHeight = 14;
            e.Row.Height = 14;
        }
        else if (x.EhConta)
        {
            // Faixa lilás: altura fixa e idêntica em TODAS as contas.
            // Min/Max evitam que tema, DPI ou reciclagem do DataGrid alterem a altura.
            e.Row.MinHeight = 28;
            e.Row.MaxHeight = 28;
            e.Row.Height = 28;
        }
        else
        {
            e.Row.MinHeight = 28;
            e.Row.MaxHeight = 28;
            e.Row.Height = 28;
        }
        if(x.Vencido) e.Row.ToolTip=x.Atraso;
    }

    void AtualizarTextoContas()
    {
        var total=_contasRepo.Listar().Count(x=>x.Ativo);
        _conta.Content = _contasSelecionadas.Count==0 ? "Nenhuma ▼" : (_contasSelecionadas.Count==total ? "Todas ▼" : (_contasSelecionadas.Count==1 ? "1 selecionada ▼" : $"{_contasSelecionadas.Count} selecionadas ▼"));
    }

    void AtualizarTextoStatus()
    {
        _status.Content = _statusSelecionados.Count == 5 ? "Todos ▼" : (_statusSelecionados.Count == 0 ? "Nenhum ▼" : $"{_statusSelecionados.Count} selecionado(s) ▼");
    }

    void PersonalizarStatus()
    {
        var opcoes=new[]{"Pagar","Receber","Pago","Recebido","Transferência"};
        var win=new Window{Title="Selecionar Status",Width=390,Height=390,WindowStartupLocation=WindowStartupLocation.CenterOwner,Owner=Window.GetWindow(this),ResizeMode=ResizeMode.NoResize};
        var root=new DockPanel{Margin=new Thickness(18)};
        var rodape=new StackPanel{Orientation=Orientation.Horizontal,HorizontalAlignment=HorizontalAlignment.Right,Margin=new Thickness(0,12,0,0)}; DockPanel.SetDock(rodape,Dock.Bottom);
        var ok=Btn("OK"); var cancelar=Btn("CANCELAR"); cancelar.Margin=new Thickness(8,0,0,0); rodape.Children.Add(ok); rodape.Children.Add(cancelar); root.Children.Add(rodape);
        var corpo=new StackPanel(); root.Children.Add(corpo);
        var todos=new CheckBox{Content="Todos",FontWeight=FontWeights.SemiBold,VerticalContentAlignment=VerticalAlignment.Center,Margin=new Thickness(2,2,2,10)}; corpo.Children.Add(todos);
        var checks=new List<(string Nome,CheckBox Cb)>();
        foreach(var nome in opcoes){var cb=new CheckBox{Content=nome,IsChecked=_statusSelecionados.Contains(nome),VerticalContentAlignment=VerticalAlignment.Center,Height=32,Margin=new Thickness(2,0,2,0)}; checks.Add((nome,cb)); corpo.Children.Add(cb);}
        var ajustando=false;
        void Sync(){if(ajustando)return;ajustando=true;todos.IsChecked=checks.All(x=>x.Cb.IsChecked==true);ajustando=false;}
        foreach(var x in checks){x.Cb.Checked+=(_,__)=>Sync();x.Cb.Unchecked+=(_,__)=>Sync();}
        todos.Checked+=(_,__)=>{if(ajustando)return;ajustando=true;foreach(var x in checks)x.Cb.IsChecked=true;ajustando=false;};
        todos.Unchecked+=(_,__)=>{if(ajustando)return;ajustando=true;foreach(var x in checks)x.Cb.IsChecked=false;ajustando=false;}; Sync();
        ok.Click+=(_,__)=>{_statusSelecionados.Clear();foreach(var x in checks.Where(x=>x.Cb.IsChecked==true))_statusSelecionados.Add(x.Nome);AtualizarTextoStatus();SalvarPreferencias();win.DialogResult=true;};
        cancelar.Click+=(_,__)=>win.DialogResult=false; win.Content=root; if(win.ShowDialog()==true) Atualizar();
    }

    void PersonalizarContas()
    {
        var contas=_contasRepo.Listar().Where(x=>x.Ativo).OrderBy(x=>x.Nome).ToList();
        var win=new Window{Title="Selecionar Contas",Width=420,Height=Math.Min(560,190+contas.Count*34),WindowStartupLocation=WindowStartupLocation.CenterOwner,Owner=Window.GetWindow(this),ResizeMode=ResizeMode.NoResize};
        var root=new DockPanel{Margin=new Thickness(18)};
        var rodape=new StackPanel{Orientation=Orientation.Horizontal,HorizontalAlignment=HorizontalAlignment.Right,Margin=new Thickness(0,12,0,0)}; DockPanel.SetDock(rodape,Dock.Bottom);
        var ok=Btn("OK"); var cancelar=Btn("CANCELAR"); cancelar.Margin=new Thickness(8,0,0,0); rodape.Children.Add(ok); rodape.Children.Add(cancelar); root.Children.Add(rodape);
        var corpo=new StackPanel(); root.Children.Add(corpo);
        var todos=new CheckBox{Content="Todas",FontWeight=FontWeights.SemiBold,VerticalContentAlignment=VerticalAlignment.Center,Height=32,Margin=new Thickness(2,2,2,10)}; corpo.Children.Add(todos);
        var scroll=new ScrollViewer{VerticalScrollBarVisibility=ScrollBarVisibility.Auto,MaxHeight=340}; var lista=new StackPanel(); scroll.Content=lista; corpo.Children.Add(scroll);
        var checks=new List<(long Id,CheckBox Cb)>();
        foreach(var c in contas){var cb=new CheckBox{Content=c.Nome,IsChecked=_contasSelecionadas.Contains(c.Id),VerticalContentAlignment=VerticalAlignment.Center,Height=32,Margin=new Thickness(2,0,2,0)};checks.Add((c.Id,cb));lista.Children.Add(cb);}
        var ajustando=false;
        void Sync(){if(ajustando)return;ajustando=true;todos.IsChecked=checks.Count>0&&checks.All(x=>x.Cb.IsChecked==true);ajustando=false;}
        foreach(var x in checks){x.Cb.Checked+=(_,__)=>Sync();x.Cb.Unchecked+=(_,__)=>Sync();}
        todos.Checked+=(_,__)=>{if(ajustando)return;ajustando=true;foreach(var x in checks)x.Cb.IsChecked=true;ajustando=false;};
        todos.Unchecked+=(_,__)=>{if(ajustando)return;ajustando=true;foreach(var x in checks)x.Cb.IsChecked=false;ajustando=false;}; Sync();
        ok.Click+=(_,__)=>{_contasSelecionadas.Clear();foreach(var x in checks.Where(x=>x.Cb.IsChecked==true))_contasSelecionadas.Add(x.Id);AtualizarTextoContas();SalvarPreferencias();win.DialogResult=true;};
        cancelar.Click+=(_,__)=>win.DialogResult=false; win.Content=root; if(win.ShowDialog()==true) Atualizar();
    }

    void SalvarPreferencias()
    {
        try
        {
            Directory.CreateDirectory(Path.GetDirectoryName(PreferenciasPath)!);
            var contaId=0L;
            var larguras=_grid.Columns.Select(c=>c.ActualWidth).ToArray();
            var pref=new FluxoPrefs(_dataInicial.SelectedDate,_dataFinal.SelectedDate,_vencidos.IsChecked==true,string.Join("|",_statusSelecionados.OrderBy(x=>x)),contaId,_contasSelecionadas.ToArray(),_agrupar.IsChecked==true,_pesquisa,larguras);
            File.WriteAllText(PreferenciasPath,JsonSerializer.Serialize(pref));
        } catch { }
    }

    void CarregarPreferencias()
    {
        _carregandoPreferencias=true;
        try
        {
            if(!File.Exists(PreferenciasPath)){return;}
            var pref=JsonSerializer.Deserialize<FluxoPrefs>(File.ReadAllText(PreferenciasPath));
            if(pref is null){return;}
            _dataInicial.SelectedDate=pref.DataInicial??DateTime.Today; _dataFinal.SelectedDate=pref.DataFinal??DateTime.Today.AddDays(7);
            _vencidos.IsChecked=pref.Vencidos; _statusSelecionados.Clear(); foreach(var st in (pref.Status??"Pagar|Receber|Pago|Recebido|Transferência").Split('|',StringSplitOptions.RemoveEmptyEntries)) if(st!="Todos") _statusSelecionados.Add(st); if(_statusSelecionados.Count==0) foreach(var st in new[]{"Pagar","Receber","Pago","Recebido","Transferência"}) _statusSelecionados.Add(st); AtualizarTextoStatus();
            _agrupar.IsChecked=pref.Agrupar; _pesquisa=pref.Pesquisa??"";
            _contasSelecionadas.Clear(); foreach(var id in pref.ContasSelecionadas??Array.Empty<long>()) _contasSelecionadas.Add(id);
            if(_contasSelecionadas.Count==0 && pref.ContaId>0) _contasSelecionadas.Add(pref.ContaId); AtualizarTextoContas();
            if(pref.LargurasColunas is { Length: > 0 })
            {
                for(int i=0;i<Math.Min(pref.LargurasColunas.Length,_grid.Columns.Count);i++)
                    if(pref.LargurasColunas[i]>=_grid.Columns[i].MinWidth) _grid.Columns[i].Width=new DataGridLength(pref.LargurasColunas[i]);
            }
        } catch { } finally {_carregandoPreferencias=false;}
    }

    void PesquisaAvancada()
    {
        var win=new Window{Title="Pesquisa Avançada",Width=570,Height=210,WindowStartupLocation=WindowStartupLocation.CenterOwner,Owner=Window.GetWindow(this),ResizeMode=ResizeMode.NoResize};
        var root=new Grid{Margin=new Thickness(18)};
        root.RowDefinitions.Add(new RowDefinition{Height=GridLength.Auto}); root.RowDefinitions.Add(new RowDefinition{Height=new GridLength(42)}); root.RowDefinitions.Add(new RowDefinition{Height=GridLength.Auto});
        var info=new TextBlock{Text="Pesquisar por descrição, documento, cliente/fornecedor ou plano de conta:",Margin=new Thickness(0,0,0,8),VerticalAlignment=VerticalAlignment.Center};Grid.SetRow(info,0);root.Children.Add(info);
        var t=new TextBox{Text=_pesquisa,Height=32,VerticalContentAlignment=VerticalAlignment.Center,Margin=new Thickness(0,0,0,8)};Grid.SetRow(t,1);root.Children.Add(t);
        var botoes=new StackPanel{Orientation=Orientation.Horizontal,HorizontalAlignment=HorizontalAlignment.Right,Margin=new Thickness(0,8,0,0)};var b=Btn("PESQUISAR");var cancelar=Btn("CANCELAR");cancelar.Margin=new Thickness(8,0,0,0);botoes.Children.Add(b);botoes.Children.Add(cancelar);Grid.SetRow(botoes,2);root.Children.Add(botoes);
        b.Click+=(_,__)=>{_pesquisa=t.Text.Trim();win.DialogResult=true;};cancelar.Click+=(_,__)=>win.DialogResult=false;t.KeyDown+=(_,e)=>{if(e.Key==Key.Enter){_pesquisa=t.Text.Trim();win.DialogResult=true;}};win.Content=root;
        if(win.ShowDialog()==true) Atualizar();
    }

    void AbrirRelatorio()
    {
        var win=new Window{Title="Relatório - Fluxo de Caixa por Conta",Width=1000,Height=700,WindowStartupLocation=WindowStartupLocation.CenterOwner,Owner=Window.GetWindow(this)};
        var painel=new DockPanel{Margin=new Thickness(12)};
        var botoesRelatorio=new StackPanel{Orientation=Orientation.Horizontal,HorizontalAlignment=HorizontalAlignment.Right};
        var imprimir=Btn("IMPRIMIR");
        var fechar=Btn("FECHAR"); fechar.Margin=new Thickness(8,0,0,0); fechar.Click+=(_,__)=>win.Close();
        botoesRelatorio.Children.Add(imprimir); botoesRelatorio.Children.Add(fechar);
        DockPanel.SetDock(botoesRelatorio,Dock.Bottom); painel.Children.Add(botoesRelatorio);

        var origem=(_grid.ItemsSource as IEnumerable<Linha>)?.ToList() ?? new List<Linha>();
        var relatorio=new List<RelatorioLinha>();
        for(int i=0;i<origem.Count;i++)
        {
            var x=origem[i];
            if(x.EhConta)
            {
                decimal saldoInicial=(i+1<origem.Count && origem[i+1].EhSaldo)?origem[i+1].Saldo:0m;
                relatorio.Add(RelatorioLinha.Conta(x,saldoInicial));
                if(i+1<origem.Count && origem[i+1].EhSaldo) i++;
                continue;
            }
            if(x.EhEspaco){ relatorio.Add(RelatorioLinha.Espaco()); continue; }
            if(!x.EhSaldo) relatorio.Add(RelatorioLinha.Movimento(x));
        }

        var copia=new DataGrid{AutoGenerateColumns=false,IsReadOnly=true,CanUserAddRows=false,ItemsSource=relatorio,Margin=new Thickness(0,0,0,10),RowHeight=30,ColumnHeaderHeight=32,FontSize=13,HeadersVisibility=DataGridHeadersVisibility.Column};
        copia.Columns.Add(ColRelatorio("Status","Status",115,false,true));
        copia.Columns.Add(ColRelatorio("Vencimento","Vencimento",115,false,true));
        copia.Columns.Add(ColRelatorio("Descrição","Descricao",new DataGridLength(1.5,DataGridLengthUnitType.Star),false));
        copia.Columns.Add(ColRelatorio("Plano de Conta","Plano",new DataGridLength(1.2,DataGridLengthUnitType.Star),false));
        copia.Columns.Add(ColRelatorio("Centro de Custo","CentroCusto",new DataGridLength(1.0,DataGridLengthUnitType.Star),false));
        copia.Columns.Add(ColRelatorio("Valor","Valor",130,true));
        copia.Columns.Add(ColRelatorio("Saldo","Saldo",130,true));
        copia.LoadingRow+=(_,e)=>
        {
            if(e.Row.Item is not RelatorioLinha r) return;
            e.Row.Background=r.EhConta?Brush("#D9E1E8"):Brush("#FFFFFF");
            e.Row.Height=r.EhEspaco?14:30;
            e.Row.FontWeight=(r.EhConta||r.EhSaldoFinal)?FontWeights.Bold:FontWeights.Normal;
            e.Row.Foreground=Brush("#000000");
        };
        imprimir.Click+=(_,__)=>
        {
            var dlg=new PrintDialog();
            if(dlg.ShowDialog()!=true) return;
            copia.UpdateLayout();
            dlg.PrintVisual(copia,"Fluxo de Caixa por Conta");
        };
        painel.Children.Add(copia); win.Content=painel; win.ShowDialog();
    }

    static DataGridTextColumn ColRelatorio(string h,string p,double w,bool direita,bool centralizar=false)=>ColRelatorio(h,p,new DataGridLength(w),direita,centralizar);
    static DataGridTextColumn ColRelatorio(string h,string p,DataGridLength w,bool direita,bool centralizar=false)
    {
        var c=new DataGridTextColumn{Header=h,Binding=new Binding(p),Width=w};
        var cab=new Style(typeof(DataGridColumnHeader));
        cab.Setters.Add(new Setter(Control.HorizontalContentAlignmentProperty,HorizontalAlignment.Center));
        cab.Setters.Add(new Setter(Control.FontWeightProperty,FontWeights.Bold));
        cab.Setters.Add(new Setter(Control.PaddingProperty,new Thickness(6,0,8,0)));
        c.HeaderStyle=cab;
        var st=new Style(typeof(TextBlock));
        st.Setters.Add(new Setter(TextBlock.VerticalAlignmentProperty,VerticalAlignment.Center));
        st.Setters.Add(new Setter(TextBlock.TextAlignmentProperty,centralizar?TextAlignment.Center:(direita?TextAlignment.Right:TextAlignment.Left)));
        st.Setters.Add(new Setter(TextBlock.MarginProperty,direita?new Thickness(4,0,8,0):new Thickness(6,0,6,0)));
        var conta=new DataTrigger{Binding=new Binding("EhConta"),Value=true};
        conta.Setters.Add(new Setter(TextBlock.FontWeightProperty,FontWeights.Bold));
        if(p=="Descricao") conta.Setters.Add(new Setter(TextBlock.TextAlignmentProperty,TextAlignment.Center));
        // O saldo inicial exibido na faixa da conta deve ocupar exatamente a mesma
        // posição horizontal dos demais saldos da coluna (direita + mesmo recuo).
        if(p=="Saldo")
        {
            // Cabeçalho da conta: usa exatamente o mesmo alinhamento/recuo dos
            // demais valores da coluna Saldo.
            conta.Setters.Add(new Setter(TextBlock.HorizontalAlignmentProperty,HorizontalAlignment.Stretch));
            conta.Setters.Add(new Setter(TextBlock.TextAlignmentProperty,TextAlignment.Right));
            conta.Setters.Add(new Setter(TextBlock.MarginProperty,new Thickness(4,0,8,0)));
        }
        st.Triggers.Add(conta);
        var final=new DataTrigger{Binding=new Binding("EhSaldoFinal"),Value=true};
        final.Setters.Add(new Setter(TextBlock.FontWeightProperty,FontWeights.Bold));
        final.Setters.Add(new Setter(TextBlock.ForegroundProperty,Brush("#000000")));
        st.Triggers.Add(final); c.ElementStyle=st;
        return c;
    }

    static string Texto(Lancamento l)=>$"{l.ClienteFornecedorNome} {l.Descricao} {l.NumeroDocumento} {l.PlanoContasNome} {l.GrupoContasNome}";
    static decimal Assinado(Lancamento l)=>l.Tipo.Equals("Pagar",StringComparison.OrdinalIgnoreCase)||l.Tipo.Equals("Pago",StringComparison.OrdinalIgnoreCase)?-Math.Abs(l.Valor):l.Tipo.Equals("Receber",StringComparison.OrdinalIgnoreCase)||l.Tipo.Equals("Recebido",StringComparison.OrdinalIgnoreCase)?Math.Abs(l.Valor):l.Valor;
    static TextBlock Lbl(string s)=>new(){Text=s,VerticalAlignment=VerticalAlignment.Center,Margin=new Thickness(4,0,2,0)};
    static Button Btn(string s)=>new(){Content=s,Height=30,Padding=new Thickness(12,0,12,0),FontWeight=FontWeights.SemiBold};
    static SolidColorBrush Brush(string hex)=>(SolidColorBrush)new BrushConverter().ConvertFromString(hex)!;
    static Style CabecalhoColuna()
    {
        var st=new Style(typeof(DataGridColumnHeader));
        st.Setters.Add(new Setter(Control.HorizontalContentAlignmentProperty,HorizontalAlignment.Center));
        st.Setters.Add(new Setter(Control.VerticalContentAlignmentProperty,VerticalAlignment.Center));
        st.Setters.Add(new Setter(Control.FontWeightProperty,FontWeights.Bold));
        st.Setters.Add(new Setter(Control.FontSizeProperty,13.0));
        st.Setters.Add(new Setter(Control.BackgroundProperty,Brush("#FAFAFA")));
        st.Setters.Add(new Setter(Control.BorderBrushProperty,Brush("#D3D3D3")));
        st.Setters.Add(new Setter(Control.BorderThicknessProperty,new Thickness(0,0,1,1)));
        return st;
    }
    static DataGridTextColumn Col(string h,string p,double w)=>Col(h,p,new DataGridLength(w));
    static DataGridTextColumn Col(string h,string p,DataGridLength w)
    {
        var c=new DataGridTextColumn{Header=h,Binding=new Binding(p),Width=w};
        var st=new Style(typeof(TextBlock));
        st.Setters.Add(new Setter(TextBlock.VerticalAlignmentProperty,VerticalAlignment.Center));
        st.Setters.Add(new Setter(TextBlock.MarginProperty,new Thickness(8,0,8,0)));
        var conta=new DataTrigger{Binding=new Binding("EhConta"),Value=true};
        conta.Setters.Add(new Setter(TextBlock.FontWeightProperty,FontWeights.Bold));
        st.Triggers.Add(conta); c.ElementStyle=st; return c;
    }
    static DataGridTextColumn ColCentro(string h,string p,double w)=>ColCentro(h,p,new DataGridLength(w));
    static DataGridTextColumn ColCentro(string h,string p,DataGridLength w)
    {
        var c=Col(h,p,w); var st=new Style(typeof(TextBlock));
        st.Setters.Add(new Setter(TextBlock.VerticalAlignmentProperty,VerticalAlignment.Center));
        st.Setters.Add(new Setter(TextBlock.TextAlignmentProperty,TextAlignment.Center));
        st.Setters.Add(new Setter(TextBlock.MarginProperty,new Thickness(6,0,6,0)));
        var conta=new DataTrigger{Binding=new Binding("EhConta"),Value=true}; conta.Setters.Add(new Setter(TextBlock.FontWeightProperty,FontWeights.Bold)); st.Triggers.Add(conta);
        c.ElementStyle=st; return c;
    }
    static DataGridTextColumn ColVencimento(string h,string p,double w)
    {
        var c=ColCentro(h,p,w);

        // A faixa da conta possui DUAS linhas reais (Conta: + nome). O estilo da
        // célula também é controlado aqui para impedir que o DataGrid recorte a
        // segunda linha quando a linha normal da grade usa RowHeight=28.
        var cell=new Style(typeof(DataGridCell));
        cell.Setters.Add(new Setter(Control.VerticalContentAlignmentProperty,VerticalAlignment.Stretch));
        cell.Setters.Add(new Setter(Control.HorizontalContentAlignmentProperty,HorizontalAlignment.Stretch));
        cell.Setters.Add(new Setter(Control.PaddingProperty,new Thickness(0)));
        c.CellStyle=cell;

        var st=new Style(typeof(TextBlock));
        st.Setters.Add(new Setter(TextBlock.VerticalAlignmentProperty,VerticalAlignment.Center));
        st.Setters.Add(new Setter(TextBlock.HorizontalAlignmentProperty,HorizontalAlignment.Stretch));
        st.Setters.Add(new Setter(TextBlock.TextAlignmentProperty,TextAlignment.Center));
        st.Setters.Add(new Setter(TextBlock.MarginProperty,new Thickness(6,0,6,0)));
        st.Setters.Add(new Setter(TextBlock.TextWrappingProperty,TextWrapping.NoWrap));
        var conta=new DataTrigger{Binding=new Binding("EhConta"),Value=true};
        conta.Setters.Add(new Setter(TextBlock.FontWeightProperty,FontWeights.Bold));
        conta.Setters.Add(new Setter(TextBlock.FontSizeProperty,13.0));
        conta.Setters.Add(new Setter(TextBlock.LineHeightProperty,18.0));
        conta.Setters.Add(new Setter(TextBlock.LineStackingStrategyProperty,LineStackingStrategy.BlockLineHeight));
        conta.Setters.Add(new Setter(TextBlock.VerticalAlignmentProperty,VerticalAlignment.Center));
        conta.Setters.Add(new Setter(TextBlock.MarginProperty,new Thickness(6,0,6,0)));
        st.Triggers.Add(conta); c.ElementStyle=st; return c;
    }
    static DataGridTextColumn ColDescricao(string h,string p,DataGridLength w)
    {
        var c=Col(h,p,w); var st=new Style(typeof(TextBlock));
        st.Setters.Add(new Setter(TextBlock.VerticalAlignmentProperty,VerticalAlignment.Center));
        st.Setters.Add(new Setter(TextBlock.MarginProperty,new Thickness(8,0,8,0)));
        var conta=new DataTrigger{Binding=new Binding("EhConta"),Value=true};
        conta.Setters.Add(new Setter(TextBlock.FontWeightProperty,FontWeights.Bold));
        conta.Setters.Add(new Setter(TextBlock.TextAlignmentProperty,TextAlignment.Center));
        st.Triggers.Add(conta); c.ElementStyle=st; return c;
    }
    static DataGridTextColumn ColDireita(string h,string p,double w){var c=Col(h,p,w);var st=new Style(typeof(TextBlock));st.Setters.Add(new Setter(TextBlock.TextAlignmentProperty,TextAlignment.Right));st.Setters.Add(new Setter(TextBlock.MarginProperty,new Thickness(0,0,8,0)));c.ElementStyle=st;return c;}
    static DataGridTextColumn ColSaldoFinal(string h,string p,double w)
    {
        var c=ColDireita(h,p,w);
        var cell=new Style(typeof(DataGridCell));
        var final=new DataTrigger{Binding=new Binding("EhSaldoFinal"),Value=true};
        final.Setters.Add(new Setter(Control.ForegroundProperty,Brush("#000000")));
        final.Setters.Add(new Setter(Control.FontWeightProperty,FontWeights.Bold));
        cell.Triggers.Add(final);
        var contaSaldo=new DataTrigger{Binding=new Binding("EhConta"),Value=true};
        contaSaldo.Setters.Add(new Setter(Control.FontWeightProperty,FontWeights.Bold));
        cell.Triggers.Add(contaSaldo); c.CellStyle=cell;
        var texto=new Style(typeof(TextBlock));
        texto.Setters.Add(new Setter(TextBlock.TextAlignmentProperty,TextAlignment.Right));
        texto.Setters.Add(new Setter(TextBlock.MarginProperty,new Thickness(0,0,8,0)));
        var textoFinal=new DataTrigger{Binding=new Binding("EhSaldoFinal"),Value=true};
        textoFinal.Setters.Add(new Setter(TextBlock.ForegroundProperty,Brush("#000000")));
        textoFinal.Setters.Add(new Setter(TextBlock.FontWeightProperty,FontWeights.Bold));
        texto.Triggers.Add(textoFinal);
        var textoConta=new DataTrigger{Binding=new Binding("EhConta"),Value=true};
        textoConta.Setters.Add(new Setter(TextBlock.FontWeightProperty,FontWeights.Bold));
        texto.Triggers.Add(textoConta); c.ElementStyle=texto;
        return c;
    }

    static void PrepararDataPicker(DatePicker picker)
    {
        picker.Loaded += (_,__) =>
        {
            if(picker.Template.FindName("PART_TextBox",picker) is not DatePickerTextBox tb) return;
            tb.HorizontalContentAlignment=HorizontalAlignment.Center;
            tb.VerticalContentAlignment=VerticalAlignment.Center;
            tb.LostKeyboardFocus += (_,__) => NormalizarDataDigitada(picker,tb);
            tb.KeyDown += (_,e) => { if(e.Key==Key.Enter || e.Key==Key.Tab) NormalizarDataDigitada(picker,tb); };
        };
    }
    static void NormalizarDataDigitada(DatePicker picker, DatePickerTextBox tb)
    {
        var t=new string((tb.Text??"").Where(char.IsDigit).ToArray());
        DateTime d;
        if(t.Length==4 && DateTime.TryParseExact(t+DateTime.Today.Year,"ddMMyyyy",CultureInfo.InvariantCulture,DateTimeStyles.None,out d)) picker.SelectedDate=d;
        else if(t.Length==8 && DateTime.TryParseExact(t,"ddMMyyyy",CultureInfo.InvariantCulture,DateTimeStyles.None,out d)) picker.SelectedDate=d;
    }
    sealed record ContaFiltro(long Id,string Nome);
    sealed record FluxoPrefs(DateTime? DataInicial,DateTime? DataFinal,bool Vencidos,string Status,long ContaId,long[] ContasSelecionadas,bool Agrupar,string Pesquisa,double[]? LargurasColunas);


    sealed class RelatorioLinha
    {
        public string Status{get;set;}=""; public string Vencimento{get;set;}=""; public string Descricao{get;set;}=""; public string Plano{get;set;}=""; public string CentroCusto{get;set;}=""; public string Valor{get;set;}=""; public string Saldo{get;set;}=""; public bool EhConta{get;set;} public bool EhSaldoFinal{get;set;} public bool EhEspaco{get;set;}
        static string N(decimal v)=>v<0?$"({Math.Abs(v):N2})":v.ToString("N2",CultureInfo.GetCultureInfo("pt-BR"));
        public static RelatorioLinha Conta(Linha x,decimal inicial)
        {
            return new()
            {
                EhConta=true,
                Status="Conta:",
                Vencimento=x.ContaNome,
                Descricao=$"Entradas: {N(x.ContaEntradas)}     Saídas: {N(x.ContaSaidas)}",
                Plano="",
                Valor="",
                Saldo=N(inicial)
            };
        }
        public static RelatorioLinha Movimento(Linha x)=>new(){Status=x.Status,Vencimento=x.DataExibicao,Descricao=x.Descricao,Plano=x.Plano,CentroCusto=x.CentroCusto,Valor=x.ValorExibicao,Saldo=x.SaldoExibicao,EhSaldoFinal=x.EhSaldoFinal};
        public static RelatorioLinha Espaco()=>new(){EhEspaco=true};
    }

    sealed class Linha
    {
        public long LancamentoId{get;set;} public string Status{get;set;}=""; public DateTime? Data{get;set;} public string Descricao{get;set;}=""; public string Plano{get;set;}=""; public string CentroCusto{get;set;}=""; public decimal Valor{get;set;} public decimal Saldo{get;set;} public bool EhConta{get;set;} public bool EhSaldo{get;set;} public bool EhSaldoFinal{get;set;} public bool EhEspaco{get;set;} public bool Vencido{get;set;} public string Atraso{get;set;}="";
        public string ContaNome{get;set;}="";
        public decimal ContaEntradas{get;set;} public decimal ContaSaidas{get;set;} public decimal ContaSaldoFinal{get;set;}
        public string DataExibicao=>Data?.ToString("dd/MM/yyyy")??"";
        public string VencimentoExibicao=>EhConta?$"Entradas: {ContaEntradas:N2}     Saídas: {ContaSaidas:N2}":DataExibicao;
        public string ValorExibicao=>EhConta||EhSaldo||EhEspaco?"":Math.Abs(Valor).ToString("N2",CultureInfo.GetCultureInfo("pt-BR"));
        public string SaldoExibicao=>EhEspaco?"":(Saldo<0?$"({Math.Abs(Saldo):N2})":Saldo.ToString("N2",CultureInfo.GetCultureInfo("pt-BR")));
        public static Linha Conta(string n,decimal e,decimal s,decimal f,decimal inicial)=>new(){EhConta=true,Status=$"Conta: {n}",ContaNome=n,ContaEntradas=e,ContaSaidas=s,ContaSaldoFinal=f,Descricao="",Plano="",CentroCusto="",Saldo=inicial};
        public static Linha Espaco()=>new(){EhEspaco=true};
        public static Linha De(Lancamento l,decimal saldo,DateTime hoje){var tipo=l.TipoExibicao;var v=Assinado(l);var venc=!l.Baixado&&l.DataPagamento!.Value.Date<hoje;var dias=venc?(hoje-l.DataPagamento.Value.Date).Days:0;return new(){LancamentoId=l.Id,Status=tipo,Data=l.DataPagamento,Descricao=string.IsNullOrWhiteSpace(l.ClienteFornecedorNome)?l.Descricao:$"{l.ClienteFornecedorNome} - {l.Descricao}",Plano=l.PlanoContasNome,CentroCusto=l.CentroCustosNome,Valor=v,Saldo=saldo,Vencido=venc,Atraso=venc?$"Vencido há {dias} dia(s)":""};}
    }
}
