using FinanceiroMasterPro.Infrastructure.Data;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace FinanceiroMasterPro.Desktop.Views;

public partial class ClienteFornecedorView : UserControl
{
    private readonly ClienteFornecedorRepository _repository = new();

    private List<ClienteFornecedor> _itens = new();

    private long _idAtual = 0;

    public ClienteFornecedorView()
    {
        InitializeComponent();

        Carregar();
        Novo();
    }

    private void Carregar()
    {
        _itens = _repository.Listar();

        GridClientes.ItemsSource = null;
        GridClientes.ItemsSource = _itens;
    }

    private void Novo()
    {
        _idAtual = 0;

        TxtNome.Clear();
        TxtDocumento.Clear();

        CmbTipo.SelectedIndex = 0;

        ChkAtivo.IsChecked = true;

        GridClientes.SelectedItem = null;

        TxtNome.Focus();
    }

    private string ObterTipoSelecionado()
    {
        if (CmbTipo.SelectedItem is ComboBoxItem item)
        {
            return item.Content?.ToString() ?? "";
        }

        return "";
    }

    private void SelecionarTipo(string tipo)
    {
        foreach (var objeto in CmbTipo.Items)
        {
            if (objeto is ComboBoxItem item &&
                item.Content?.ToString() == tipo)
            {
                CmbTipo.SelectedItem = item;
                return;
            }
        }

        CmbTipo.SelectedIndex = 0;
    }

    private void Novo_Click(
        object sender,
        RoutedEventArgs e)
    {
        Novo();
    }

    private void Salvar_Click(
        object sender,
        RoutedEventArgs e)
    {
        try
        {
            if (string.IsNullOrWhiteSpace(TxtNome.Text))
            {
                MessageBox.Show(
                    "Informe o nome do Cliente / Fornecedor.",
                    "Financeiro Master Pro",
                    MessageBoxButton.OK,
                    MessageBoxImage.Information);

                TxtNome.Focus();
                return;
            }

            var item = new ClienteFornecedor
            {
                Id = _idAtual,
                Nome = TxtNome.Text,
                Documento = TxtDocumento.Text,
                Tipo = ObterTipoSelecionado(),
                Ativo = ChkAtivo.IsChecked == true
            };

            _idAtual = _repository.Salvar(item);

            MessageBox.Show(
                "Cliente / Fornecedor salvo com sucesso.",
                "Financeiro Master Pro",
                MessageBoxButton.OK,
                MessageBoxImage.Information);

            Carregar();
            Novo();
        }
        catch (System.Exception ex)
        {
            MessageBox.Show(
                $"Não foi possível salvar o Cliente / Fornecedor.\n\n{ex.Message}",
                "Financeiro Master Pro",
                MessageBoxButton.OK,
                MessageBoxImage.Error);
        }
    }

    private void GridClientes_SelectionChanged(
        object sender,
        SelectionChangedEventArgs e)
    {
        if (GridClientes.SelectedItem
            is not ClienteFornecedor item)
        {
            return;
        }

        _idAtual = item.Id;

        TxtNome.Text = item.Nome;
        TxtDocumento.Text = item.Documento;

        SelecionarTipo(item.Tipo);

        ChkAtivo.IsChecked = item.Ativo;
    }

    private void AlterarStatus_Click(
        object sender,
        RoutedEventArgs e)
    {
        if (_idAtual == 0)
        {
            MessageBox.Show(
                "Selecione um Cliente / Fornecedor na lista.",
                "Financeiro Master Pro",
                MessageBoxButton.OK,
                MessageBoxImage.Information);

            return;
        }

        bool novoStatus =
            ChkAtivo.IsChecked != true;

        _repository.AlterarStatus(
            _idAtual,
            novoStatus);

        Carregar();
        Novo();
    }

    private void Pesquisar_TextChanged(
        object sender,
        TextChangedEventArgs e)
    {
        string pesquisa =
            TxtPesquisar.Text.Trim().ToLower();

        if (string.IsNullOrWhiteSpace(pesquisa))
        {
            GridClientes.ItemsSource = _itens;
            return;
        }

        GridClientes.ItemsSource =
            _itens
                .Where(x =>
                    PesquisaAvancada.Texto(x.Nome,pesquisa) ||
                    PesquisaAvancada.Texto(x.Documento,pesquisa) ||
                    PesquisaAvancada.Texto(x.Tipo,pesquisa))
                .ToList();
    }

    private void Alterar_Click(object sender, RoutedEventArgs e)
    {
        if (_idAtual == 0)
        {
            MessageBox.Show("Selecione um cadastro na lista para alterar.", "Financeiro Master Pro", MessageBoxButton.OK, MessageBoxImage.Information);
            return;
        }
        Salvar_Click(sender, e);
    }

    private void Excluir_Click(object sender, RoutedEventArgs e)
    {
        if (_idAtual == 0)
        {
            MessageBox.Show("Selecione um cadastro na lista para excluir.", "Financeiro Master Pro", MessageBoxButton.OK, MessageBoxImage.Information);
            return;
        }

        var resposta = MessageBox.Show(
            "Deseja realmente excluir este cadastro?\n\nSe ele estiver vinculado a lançamentos, parcelamentos ou rateios, a exclusão será bloqueada para proteger os dados.",
            "Financeiro Master Pro",
            MessageBoxButton.YesNo,
            MessageBoxImage.Warning);
        if (resposta != MessageBoxResult.Yes) return;

        try
        {
            _repository.Excluir(_idAtual);
            Carregar();
            Novo();
        }
        catch (System.Exception ex)
        {
            MessageBox.Show(ex.Message, "Financeiro Master Pro", MessageBoxButton.OK, MessageBoxImage.Information);
        }
    }

    private void Cadastro_PreviewKeyDown(object sender, KeyEventArgs e)
    {
        if (e.Key != Key.Enter) return;
        if (Keyboard.FocusedElement is Button) return;
        e.Handled = true;
        (Keyboard.FocusedElement as UIElement)?.MoveFocus(new TraversalRequest(FocusNavigationDirection.Next));
    }
}
