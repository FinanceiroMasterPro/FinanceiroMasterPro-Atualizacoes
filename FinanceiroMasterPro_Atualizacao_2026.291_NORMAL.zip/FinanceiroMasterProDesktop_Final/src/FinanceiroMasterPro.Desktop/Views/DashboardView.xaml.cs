using FinanceiroMasterPro.Infrastructure.Data;
using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;

namespace FinanceiroMasterPro.Desktop.Views;

public partial class DashboardView : UserControl
{
    readonly LancamentoRepository _repo = new();
    readonly ContaBancariaRepository _contas = new();
    List<Lancamento> _todos = new();
    List<Lancamento> _dados = new();
    bool _carregando = true;
    static readonly string[] Meses={"JAN","FEV","MAR","ABR","MAI","JUN","JUL","AGO","SET","OUT","NOV","DEZ"};
    public DashboardView(){InitializeComponent(); Loaded += (_,__)=>Carregar();}
    void Carregar(){
        _todos=_repo.Listar().Where(x=>x.Ativo).ToList();
        var anos=_todos.Select(x=>(x.DataPagamento??x.DataEmissao).Year).Distinct().OrderByDescending(x=>x).ToList();
        CmbAno.ItemsSource=anos; CmbAno.SelectedItem=anos.Contains(DateTime.Today.Year)?DateTime.Today.Year:anos.FirstOrDefault();
        var contas=new List<string>{"TODAS AS CONTAS"}; contas.AddRange(_contas.Listar().Where(x=>x.Ativo).Select(x=>x.Nome).OrderBy(x=>x));
        CmbConta.ItemsSource=contas; CmbConta.SelectedIndex=0; _carregando=false; Atualizar();
    }
    void Filtro_Changed(object s, SelectionChangedEventArgs e){if(!_carregando)Atualizar();}
    void Atualizar_Click(object s,RoutedEventArgs e)=>Atualizar();
    static decimal Assinado(Lancamento x)=>x.Tipo.Equals("Pagar",StringComparison.OrdinalIgnoreCase)?-Math.Abs(x.Valor):Math.Abs(x.Valor);
    static bool EhTransferencia(Lancamento x)
    {
        static bool Tem(string? v) => !string.IsNullOrWhiteSpace(v) &&
            (v.Contains("TRANSFER", StringComparison.OrdinalIgnoreCase) ||
             v.Contains("TRANSF.", StringComparison.OrdinalIgnoreCase));
        return Tem(x.Tipo) || Tem(x.GrupoContasNome) || Tem(x.FluxoCaixaNome) ||
               Tem(x.PlanoContasNome) || Tem(x.Descricao);
    }
    void Atualizar(){
        if(CmbAno.SelectedItem is not int ano)return;
        string conta=CmbConta.SelectedItem?.ToString()??"TODAS AS CONTAS";
        _dados=_todos.Where(x=>(x.DataPagamento??x.DataEmissao).Year==ano && (conta=="TODAS AS CONTAS"||x.ContaBancariaNome==conta)).ToList();
        var real=_dados.Where(x=>x.Baixado).ToList();
        var realFinanceiro=real.Where(x=>!EhTransferencia(x)).ToList();
        var pend=_dados.Where(x=>!x.Baixado && !EhTransferencia(x)).ToList();
        decimal rec=realFinanceiro.Where(x=>!x.Tipo.Equals("Pagar",StringComparison.OrdinalIgnoreCase)).Sum(x=>Math.Abs(x.Valor));
        decimal pag=realFinanceiro.Where(x=>x.Tipo.Equals("Pagar",StringComparison.OrdinalIgnoreCase)).Sum(x=>Math.Abs(x.Valor));
        decimal ar=pend.Where(x=>!x.Tipo.Equals("Pagar",StringComparison.OrdinalIgnoreCase)).Sum(x=>Math.Abs(x.Valor));
        decimal ap=pend.Where(x=>x.Tipo.Equals("Pagar",StringComparison.OrdinalIgnoreCase)).Sum(x=>Math.Abs(x.Valor));
        TxtRecebido.Text=Moeda(rec);TxtPago.Text=Moeda(pag);TxtAReceber.Text=Moeda(ar);TxtAPagar.Text=Moeda(ap);TxtResultado.Text=Moeda(rec-pag);
        TxtSaldo.Text=Moeda(realFinanceiro.Sum(Assinado));
        DesenharTudo();
    }
    static string Moeda(decimal v)=>v.ToString("C2",CultureInfo.GetCultureInfo("pt-BR"));
    void Chart_SizeChanged(object s,SizeChangedEventArgs e){if(!_carregando)DesenharTudo();}
    void DesenharTudo(){
        if(_dados==null)return;
        var real=_dados.Where(x=>x.Baixado && !EhTransferencia(x)).ToList();
        var receitas=Enumerable.Range(1,12).Select(m=>real.Where(x=>(x.DataPagamento??x.DataEmissao).Month==m&&!x.Tipo.Equals("Pagar",StringComparison.OrdinalIgnoreCase)).Sum(x=>Math.Abs(x.Valor))).ToArray();
        var despesas=Enumerable.Range(1,12).Select(m=>real.Where(x=>(x.DataPagamento??x.DataEmissao).Month==m&&x.Tipo.Equals("Pagar",StringComparison.OrdinalIgnoreCase)).Sum(x=>Math.Abs(x.Valor))).ToArray();
        BarrasMensais(ChartMensal,receitas,despesas);
        decimal acc=0; var acumulado=receitas.Zip(despesas,(r,d)=>acc+=r-d).ToArray(); Linha(ChartSaldo,acumulado);
        var dg=real.Where(x=>x.Tipo.Equals("Pagar",StringComparison.OrdinalIgnoreCase)).GroupBy(x=>string.IsNullOrWhiteSpace(x.GrupoContasNome)?"SEM GRUPO":x.GrupoContasNome).Select(g=>(g.Key,g.Sum(x=>Math.Abs(x.Valor)))).OrderByDescending(x=>x.Item2).Take(8).ToList();
        var rg=real.Where(x=>!x.Tipo.Equals("Pagar",StringComparison.OrdinalIgnoreCase)).GroupBy(x=>string.IsNullOrWhiteSpace(x.GrupoContasNome)?"SEM GRUPO":x.GrupoContasNome).Select(g=>(g.Key,g.Sum(x=>Math.Abs(x.Valor)))).OrderByDescending(x=>x.Item2).Take(8).ToList();
        BarrasHoriz(ChartDespesas,dg,true); BarrasHoriz(ChartReceitas,rg,false);
        var cg=real.GroupBy(x=>string.IsNullOrWhiteSpace(x.ContaBancariaNome)?"SEM CONTA":x.ContaBancariaNome).Select(g=>(g.Key,g.Sum(Assinado))).OrderByDescending(x=>Math.Abs(x.Item2)).Take(8).ToList();
        BarrasHoriz(ChartContas,cg,false);
        decimal ar=_dados.Where(x=>!x.Baixado&&!x.Tipo.Equals("Pagar",StringComparison.OrdinalIgnoreCase)).Sum(x=>Math.Abs(x.Valor));
        decimal ap=_dados.Where(x=>!x.Baixado&&x.Tipo.Equals("Pagar",StringComparison.OrdinalIgnoreCase)).Sum(x=>Math.Abs(x.Valor));
        BarrasHoriz(ChartPendentes,new List<(string,decimal)>{("A RECEBER",ar),("A PAGAR",ap)},false);
    }
    static void Limpar(Canvas c){c.Children.Clear();}
    static TextBlock T(string text,double x,double y,int size=10,FontWeight? weight=null){var t=new TextBlock{Text=text,FontSize=size,Foreground=new SolidColorBrush(Color.FromRgb(18,58,99)),FontWeight=weight??FontWeights.Normal};Canvas.SetLeft(t,x);Canvas.SetTop(t,y);return t;}
    static void BarrasMensais(Canvas c,decimal[] r,decimal[] d){Limpar(c);double w=c.ActualWidth,h=c.ActualHeight;if(w<100||h<100)return;decimal max=Math.Max(1,Math.Max(r.Max(),d.Max()));double bw=(w-45)/12;
      for(int i=0;i<12;i++){double hr=(double)(r[i]/max)*(h-55),hd=(double)(d[i]/max)*(h-55);var a=new Rectangle{Width=Math.Max(3,bw*.32),Height=hr,Fill=new SolidColorBrush(Color.FromRgb(43,127,195)),ToolTip=$"{Meses[i]} Receitas: {Moeda(r[i])}"};
        ToolTipService.SetInitialShowDelay(a,0); ToolTipService.SetBetweenShowDelay(a,0); ToolTipService.SetShowDuration(a,60000);var b=new Rectangle{Width=Math.Max(3,bw*.32),Height=hd,Fill=new SolidColorBrush(Color.FromRgb(155,171,185)),ToolTip=$"{Meses[i]} Despesas: {Moeda(d[i])}"};
        ToolTipService.SetInitialShowDelay(b,0); ToolTipService.SetBetweenShowDelay(b,0); ToolTipService.SetShowDuration(b,60000);Canvas.SetLeft(a,30+i*bw);Canvas.SetTop(a,h-30-hr);Canvas.SetLeft(b,30+i*bw+bw*.36);Canvas.SetTop(b,h-30-hd);c.Children.Add(a);c.Children.Add(b);c.Children.Add(T(Meses[i],28+i*bw,h-25,8));}}
    static void Linha(Canvas c,decimal[] v){Limpar(c);double w=c.ActualWidth,h=c.ActualHeight;if(w<100||h<100)return;decimal min=Math.Min(0,v.Min()),max=Math.Max(1,v.Max()),range=Math.Max(1,max-min);Point? prev=null;for(int i=0;i<12;i++){double x=35+i*(w-55)/11,y=15+(double)((max-v[i])/range)*(h-50);var p=new Ellipse{Width=7,Height=7,Fill=new SolidColorBrush(Color.FromRgb(43,127,195)),ToolTip=$"{Meses[i]}: {Moeda(v[i])}"};
        ToolTipService.SetInitialShowDelay(p,0); ToolTipService.SetBetweenShowDelay(p,0); ToolTipService.SetShowDuration(p,60000);Canvas.SetLeft(p,x-3);Canvas.SetTop(p,y-3);c.Children.Add(p);if(prev!=null){var l=new Line{X1=prev.Value.X,Y1=prev.Value.Y,X2=x,Y2=y,Stroke=new SolidColorBrush(Color.FromRgb(43,127,195)),StrokeThickness=2};c.Children.Insert(0,l);}prev=new Point(x,y);c.Children.Add(T(Meses[i],x-8,h-24,8));}}
    static void BarrasHoriz(Canvas c,List<(string,decimal)> data,bool desp){Limpar(c);double w=c.ActualWidth,h=c.ActualHeight;if(w<100||h<100||data.Count==0)return;decimal max=Math.Max(1,data.Max(x=>Math.Abs(x.Item2)));double rh=(h-15)/data.Count;for(int i=0;i<data.Count;i++){var z=data[i];double bw=(double)(Math.Abs(z.Item2)/max)*(w*.52);c.Children.Add(T(z.Item1,5,i*rh+4,9,FontWeights.SemiBold));var r=new Rectangle{Width=bw,Height=Math.Max(7,rh*.35),Fill=new SolidColorBrush(desp?Color.FromRgb(155,171,185):Color.FromRgb(43,127,195)),ToolTip=$"{z.Item1}: {Moeda(z.Item2)}"};
        ToolTipService.SetInitialShowDelay(r,0); ToolTipService.SetBetweenShowDelay(r,0); ToolTipService.SetShowDuration(r,60000);Canvas.SetLeft(r,w*.42);Canvas.SetTop(r,i*rh+3);c.Children.Add(r);c.Children.Add(T(Moeda(z.Item2),w*.42+bw+5,i*rh+2,9));}}
}