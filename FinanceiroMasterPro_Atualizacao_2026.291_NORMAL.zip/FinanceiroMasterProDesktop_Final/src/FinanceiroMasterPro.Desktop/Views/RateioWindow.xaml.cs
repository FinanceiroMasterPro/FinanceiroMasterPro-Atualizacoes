using FinanceiroMasterPro.Infrastructure.Data;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Windows;

namespace FinanceiroMasterPro.Desktop.Views;

public partial class RateioWindow : Window
{
    private readonly CultureInfo _pt = new("pt-BR");
    private readonly decimal _valorTotal;
    private readonly long? _centroOriginalId;
    private readonly string _centroOriginalNome;
    public List<RateioItem> Itens { get; } = new();

    public RateioWindow(decimal valorTotal, List<PlanoContas> planos, List<CentroCustos> centros, long? centroOriginalId, string centroOriginalNome, List<RateioItem>? existentes = null)
    {
        InitializeComponent();
        _valorTotal = decimal.Round(valorTotal, 2, MidpointRounding.AwayFromZero);
        _centroOriginalId=centroOriginalId; _centroOriginalNome=centroOriginalNome;
        PlanoContas.ItemsSource = planos;
        CentroCustos.ItemsSource = centros;
        TxtValorLancamento.Text = _valorTotal.ToString("N2", _pt);
        if (existentes != null) Itens.AddRange(existentes.Select(x => new RateioItem { PlanoContasId=x.PlanoContasId, PlanoContasNome=x.PlanoContasNome, CentroCustosId=x.CentroCustosId, CentroCustosNome=x.CentroCustosNome, Percentual=x.Percentual, Valor=x.Valor }));
        Atualizar();
    }

    private bool Ler(string texto, out decimal valor) => decimal.TryParse(texto.Trim().Replace("R$", "").Replace(" ", ""), NumberStyles.Number, _pt, out valor);

    private void Adicionar_Click(object sender, RoutedEventArgs e)
    {
        if (PlanoContas.SelectedItem is not PlanoContas plano) { MessageBox.Show("Selecione o Plano de Contas."); return; }
        var centro=CentroCustos.SelectedItem as CentroCustos;
        long? centroId=centro?.Id ?? _centroOriginalId;
        string centroNome=centro?.Nome ?? _centroOriginalNome;
        if (Itens.Any(x => x.PlanoContasId==plano.Id && x.CentroCustosId==centroId)) { MessageBox.Show("Este Plano de Contas/Centro de Custos já foi incluído."); return; }

        decimal valor;
        decimal percentual;
        bool temValor = Ler(ValorRateio.Text, out valor) && valor != 0;
        bool temPercentual = Ler(Percentual.Text, out percentual) && percentual != 0;
        if (!temValor && !temPercentual) { MessageBox.Show("Informe o VALOR ou o PERCENTUAL do rateio."); return; }

        if (!temValor) valor = decimal.Round(_valorTotal * percentual / 100m, 2, MidpointRounding.AwayFromZero);
        if (!temPercentual) percentual = _valorTotal == 0 ? 0 : decimal.Round(valor / _valorTotal * 100m, 4, MidpointRounding.AwayFromZero);
        if (valor == 0) { MessageBox.Show("O valor do rateio não pode ser zero."); return; }

        Itens.Add(new RateioItem { PlanoContasId=plano.Id, PlanoContasNome=plano.Nome, CentroCustosId=centroId, CentroCustosNome=centroNome, Percentual=percentual, Valor=valor });
        PlanoContas.SelectedItem=null; CentroCustos.SelectedItem = null; Percentual.Clear(); ValorRateio.Clear(); Atualizar();
        var totalAtual=Itens.Sum(x=>x.Valor);
        if((_valorTotal>=0 && totalAtual>_valorTotal)||(_valorTotal<0 && totalAtual<_valorTotal))
            MessageBox.Show("ESTE VALOR ULTRAPASSA O SALDO A RATEAR.\n\nContinue com os ajustes até a DIFERENÇA chegar a 0,00.","Financeiro Master Pro");
    }

    private void Remover_Click(object sender, RoutedEventArgs e)
    {
        if (GridRateio.SelectedItem is RateioItem item) { Itens.Remove(item); Atualizar(); }
    }

    private void Ajustar_Click(object sender, RoutedEventArgs e)
    {
        if (Itens.Count == 0) { MessageBox.Show("Inclua pelo menos um item antes de ajustar."); return; }
        decimal total = Itens.Sum(x => x.Valor);
        decimal diferenca = decimal.Round(_valorTotal - total, 2, MidpointRounding.AwayFromZero);
        var ultimo = Itens[^1];
        ultimo.Valor = decimal.Round(ultimo.Valor + diferenca, 2, MidpointRounding.AwayFromZero);
        ultimo.Percentual = _valorTotal == 0 ? 0 : decimal.Round(ultimo.Valor / _valorTotal * 100m, 4, MidpointRounding.AwayFromZero);
        if (ultimo.Valor == 0) { MessageBox.Show("O ajuste faria o último item ficar zerado. Altere os valores do rateio."); return; }
        Atualizar();
    }

    private void Atualizar()
    {
        GridRateio.ItemsSource = null; GridRateio.ItemsSource = Itens;
        decimal total = decimal.Round(Itens.Sum(x => x.Valor), 2, MidpointRounding.AwayFromZero);
        decimal diferenca = decimal.Round(_valorTotal - total, 2, MidpointRounding.AwayFromZero);
        TxtTotalValor.Text = total.ToString("N2", _pt);
        TxtDiferenca.Text = diferenca.ToString("N2", _pt);
    }

    private void Salvar_Click(object sender, RoutedEventArgs e)
    {
        if (Itens.Count < 1) { MessageBox.Show("Informe pelo menos 1 item no rateio."); return; }
        decimal diferenca = decimal.Round(_valorTotal - Itens.Sum(x => x.Valor), 2, MidpointRounding.AwayFromZero);
        if (diferenca != 0) { MessageBox.Show($"A diferença precisa ficar em 0,00. Diferença atual: {diferenca.ToString("N2", _pt)}\n\nUse AJUSTAR ÚLTIMO = 0,00."); return; }
        DialogResult = true;
    }

    private void Cancelar_Click(object sender, RoutedEventArgs e) => DialogResult = false;
}
