using System.Collections.Generic; using System.Windows; using System.Windows.Controls; using System.Windows.Input; using FinanceiroMasterPro.Infrastructure.Data;
namespace FinanceiroMasterPro.Desktop.Views;
public partial class RateiosView:UserControl{
 readonly RateioRepository _repo=new(); List<RateioResumo> _dados=new();
 public RateiosView(){InitializeComponent();Loaded+=(_,__)=>Carregar();}
 void Carregar(){_repo.SincronizarIdentificacaoRateios();_dados=_repo.ListarRateios();GridRateios.ItemsSource=_dados;if(_dados.Count>0)GridRateios.SelectedIndex=0;}
 void GridRateios_SelectionChanged(object sender,SelectionChangedEventArgs e)=>GridItens.ItemsSource=(GridRateios.SelectedItem as RateioResumo)?.Itens;
 void GridRateios_MouseDoubleClick(object sender,MouseButtonEventArgs e){if(GridRateios.SelectedItem is not RateioResumo r)return;(Window.GetWindow(this) as MainWindow)?.AbrirLancamentoPorId(r.LancamentoId);}
}