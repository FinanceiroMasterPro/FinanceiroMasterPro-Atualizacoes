using FinanceiroMasterPro.Infrastructure.Data;using System.Windows;
namespace FinanceiroMasterPro.Desktop.Views;
public partial class ClassificacaoEscolhaWindow:Window{
 public ClassificacaoPlano? Escolhida=>Lista.SelectedItem as ClassificacaoPlano;
 public ClassificacaoEscolhaWindow(IEnumerable<ClassificacaoPlano> itens){InitializeComponent();Lista.ItemsSource=itens;Lista.SelectedIndex=0;}
 void Ok_Click(object s,RoutedEventArgs e){if(Escolhida==null)return;DialogResult=true;}
}