﻿using FinanceiroMasterPro.Infrastructure.Data;
using FinanceiroMasterPro.Infrastructure.Security;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Data;
using System.Windows.Threading;
using System.Windows.Media;
namespace FinanceiroMasterPro.Desktop.Views;

public partial class LancamentosView : UserControl
{
    private string _destinoVoltar = "FLUXO_CONTAS";

    public void HabilitarVoltarTelaAnterior(string destino = "FLUXO_CONTAS")
    {
        _destinoVoltar = destino;
        BtnVoltarTelaAnterior.Visibility = Visibility.Visible;
    }

    private void VoltarTelaAnterior_Click(object sender, RoutedEventArgs e)
    {
        if (Window.GetWindow(this) is not MainWindow w) return;
        if (_destinoVoltar == "DFC_CAIXA") w.VoltarParaDfcCaixa();
        else if (_destinoVoltar == "RELATORIO_LANCAMENTOS") w.VoltarParaRelatorioLancamentos();
        else w.VoltarParaFluxoContas();
    }

    public void AtualizarGradePreservandoFiltros()
    {
        _lancamentoExclusivoId = null;
        CarregarLancamentos();
        GridLancamentos.SelectedItem = null;
    }

    private void LimparTela_Click(object sender, RoutedEventArgs e)
    {
        // Se veio do relatório/consulta isolada, volta à grade completa preservando filtros.
        if (_lancamentoExclusivoId.HasValue)
        {
            _lancamentoExclusivoId = null;
            CarregarLancamentos();
            GridLancamentos.SelectedItem = null;
            Novo();
            return;
        }

        // Em NOVO/ALTERAÇÃO, funciona como CANCELAR: descarta somente o que está
        // digitado no painel. Não apaga lançamento salvo e não limpa TIPO/STATUS filtros.
        Novo();
    }
    private readonly LancamentoRepository _repository = new();
    private readonly ParcelamentoRepository _parcelamentoRepository = new();
    private readonly RateioRepository _rateioRepository = new();
    private readonly ContaBancariaRepository _contaRepository = new();
    private readonly ClienteFornecedorRepository _clienteRepository = new();
    private readonly PlanoContasRepository _planoRepository = new();
    private readonly CentroCustosRepository _centroRepository = new();
    private readonly GrupoContasRepository _grupoRepository = new();
    private readonly FluxoCaixaRepository _fluxoRepository = new();
    private readonly ClassificacaoPlanoRepository _classificacaoRepository = new();

    private readonly CultureInfo _culturaBrasil = new("pt-BR");

    private List<Lancamento> _lancamentos = new();

    private long _idAtual;
    private bool _modoAlteracao;
    private long? _lancamentoExclusivoId;

    private bool _layoutCarregado;
    private bool _salvandoLayout;
    private bool _eventoLarguraLigado;
    private bool _alterandoBaixaGrade;
    private bool _confirmandoPlanoPorEnter;
    private long? _contaFiltroId;
    private DateTime? _dfcDataInicial;
    private DateTime? _dfcDataFinal;
    private bool _carregandoPreferenciaStatus = true;
    private readonly HashSet<string> _tiposFiltroSelecionados = new(StringComparer.OrdinalIgnoreCase) { "Pagar", "Receber", "Pago", "Recebido", "Transferência" };
    private readonly HashSet<string> _statusFiltroSelecionados = new(StringComparer.OrdinalIgnoreCase) { "Aberto", "Fechado" };

    private string ArquivoPreferenciaStatus => Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "FinanceiroMasterPro", "PreferenciasStatusLancamentos.json");

    private string ArquivoLayout =>
        Path.Combine(
            Environment.GetFolderPath(
                Environment.SpecialFolder.LocalApplicationData),
            "FinanceiroMasterPro",
            "LancamentosGridLayout.json");

    public LancamentosView()
    {
        InitializeComponent();
        CarregarLargurasSaldos();
        CarregarLarguraPainelSaldos();
        CarregarLayoutGradeLancamentos();

        Language =
            System.Windows.Markup.XmlLanguage
                .GetLanguage("pt-BR");

        KeyboardNavigation.SetTabNavigation(
            this,
            KeyboardNavigationMode.Continue);

        CarregarCadastros();
        CarregarStatusPreferido();
        CarregarLancamentos();
        CarregarOrdenacaoGrade();
        Novo();
    }

    


    public void SelecionarContaParaNovo(long contaId)
    {
        Novo();
        Conta.SelectedItem = _contaRepository.Listar().FirstOrDefault(x => x.Id == contaId);
        SelecionarTipo("Pagar");
    }

    public void AbrirLancamentoPorId(long lancamentoId)
    {
        _contaFiltroId=null;
        _rateioRepository.SincronizarIdentificacaoRateios();
        _lancamentos=_repository.Listar();
        var rateados=_rateioRepository.ListarLancamentosRateados();
        var numerosRateio=_rateioRepository.ListarNumerosRateio();
        var parcelados=_parcelamentoRepository.ListarLancamentosParcelados();
        foreach(var l in _lancamentos)
        {
            l.PossuiRateio=rateados.Contains(l.Id);
            l.NumeroRateio=numerosRateio.TryGetValue(l.Id,out var nr)?nr:0;
            l.PossuiParcelamento=parcelados.Contains(l.Id);
        }
        GridLancamentos.ItemsSource=_lancamentos;
        var item=_lancamentos.FirstOrDefault(x=>x.Id==lancamentoId);
        if(item==null){MessageBox.Show("Lançamento de origem do rateio não localizado.","Financeiro Master Pro");return;}
        GridLancamentos.SelectedItem=item;
        GridLancamentos.ScrollIntoView(item);
        Alterar_Click(this,new RoutedEventArgs());
    }

    public void AbrirSomenteLancamentoPorId(long lancamentoId)
    {
        _lancamentoExclusivoId = lancamentoId;
        _contaFiltroId = null;
        _rateioRepository.SincronizarIdentificacaoRateios();
        _lancamentos = _repository.Listar().Where(x => x.Id == lancamentoId).ToList();
        var item = _lancamentos.FirstOrDefault();
        if (item == null)
        {
            MessageBox.Show("Lançamento não localizado.", "Financeiro Master Pro");
            return;
        }
        GridLancamentos.ItemsSource = _lancamentos;
        GridLancamentos.GridLinesVisibility = DataGridGridLinesVisibility.All;
        GridLancamentos.SelectedItem = item;
        GridLancamentos.ScrollIntoView(item);
        Alterar_Click(this, new RoutedEventArgs());
        // Alterar_Click pode reaplicar filtros; garantimos que a grade continue mostrando somente o escolhido.
        GridLancamentos.ItemsSource = _lancamentos.Where(x => x.Id == lancamentoId).ToList();
    }

    public void FiltrarPorConta(long contaId)
    {
        var c = _contaRepository.Listar().FirstOrDefault(x => x.Id == contaId);
        _contaFiltroId = contaId;
        AtualizarTituloContaFiltro(c?.Nome);

        // Em uma conta específica, o painel sempre começa usando a conta
        // que está aberta no momento. O campo continua habilitado para troca manual.
        if (c != null)
        {
            Conta.SelectedItem = (Conta.ItemsSource as IEnumerable<ContaBancaria>)?.FirstOrDefault(x => x.Id == contaId) ?? c;
            Conta.Text = c.Nome;
        }

        AplicarFiltros();
    }
    // =========================================================
    // LAYOUT DA GRADE
    // =========================================================
    private void LancamentosView_Loaded(
        object sender,
        RoutedEventArgs e)
    {
        CarregarLayoutGrade();

        if (!_eventoLarguraLigado)
        {
            GridLancamentos.AddHandler(
                Thumb.DragCompletedEvent,
                new DragCompletedEventHandler(
                    GridLancamentos_ColumnResizeCompleted));

            GridLancamentos.PreviewMouseLeftButtonUp += (_, __) => SalvarLayoutGrade();
            _eventoLarguraLigado = true;
        }
    }

    private void LancamentosView_SalvarLayoutUnloaded(
        object sender,
        RoutedEventArgs e)
    {
        SalvarLayoutGrade();
    }

    private void GridLancamentos_ColumnReordered(
        object sender,
        DataGridColumnEventArgs e)
    {
        Dispatcher.BeginInvoke(new Action(SalvarLayoutGradeLancamentos), System.Windows.Threading.DispatcherPriority.Background);
        SalvarLayoutGrade();
    }

    private void GridLancamentos_ColumnDisplayIndexChanged(
        object? sender,
        DataGridColumnEventArgs e)
    {
        Dispatcher.BeginInvoke(new Action(SalvarLayoutGradeLancamentos), System.Windows.Threading.DispatcherPriority.Background);
        SalvarLayoutGrade();
    }

    private void GridLancamentos_ColumnResizeCompleted(
        object sender,
        DragCompletedEventArgs e)
    {
        SalvarLayoutGrade();
    }

    private void SalvarLayoutGrade()
    {
        if (!_layoutCarregado ||
            _salvandoLayout ||
            GridLancamentos == null)
            return;

        try
        {
            _salvandoLayout = true;

            string? pasta =
                Path.GetDirectoryName(ArquivoLayout);

            if (!string.IsNullOrWhiteSpace(pasta))
                Directory.CreateDirectory(pasta);

            var configuracao =
                GridLancamentos.Columns
                    .Select(
                        (coluna, indice) =>
                            new ConfiguracaoColuna
                            {
                                IndiceOriginal = indice,
                                DisplayIndex = coluna.DisplayIndex,
                                Largura = coluna.ActualWidth
                            })
                    .ToList();

            File.WriteAllText(
                ArquivoLayout,
                JsonSerializer.Serialize(
                    configuracao,
                    new JsonSerializerOptions
                    {
                        WriteIndented = true
                    }));
        }
        catch
        {
        }
        finally
        {
            _salvandoLayout = false;
        }
    }

    private void CarregarLayoutGrade()
    {
        if (_layoutCarregado)
            return;

        try
        {
            _salvandoLayout = true;

            if (File.Exists(ArquivoLayout))
            {
                var configuracao =
                    JsonSerializer.Deserialize<
                        List<ConfiguracaoColuna>>(
                            File.ReadAllText(ArquivoLayout));

                if (configuracao != null)
                {
                    foreach (var item in configuracao)
                    {
                        if (item.IndiceOriginal < 0 ||
                            item.IndiceOriginal >=
                            GridLancamentos.Columns.Count)
                            continue;

                        if (item.Largura >= 35 &&
                            item.Largura <= 1000)
                        {
                            GridLancamentos
                                .Columns[item.IndiceOriginal]
                                .Width =
                                new DataGridLength(
                                    item.Largura,
                                    DataGridLengthUnitType.Pixel);
                        }
                    }

                    foreach (var item in
                             configuracao.OrderBy(
                                 x => x.DisplayIndex))
                    {
                        if (item.IndiceOriginal < 0 ||
                            item.IndiceOriginal >=
                            GridLancamentos.Columns.Count)
                            continue;

                        int destino =
                            Math.Max(
                                0,
                                Math.Min(
                                    item.DisplayIndex,
                                    GridLancamentos.Columns.Count - 1));

                        GridLancamentos
                            .Columns[item.IndiceOriginal]
                            .DisplayIndex = destino;
                    }
                }
            }
        }
        catch
        {
        }
        finally
        {
            _salvandoLayout = false;
            _layoutCarregado = true;
        }
    }

    private sealed class ConfiguracaoColuna
    {
        public int IndiceOriginal { get; set; }
        public int DisplayIndex { get; set; }
        public double Largura { get; set; }
    }

    private string ArquivoOrdenacaoGrade => Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
        "FinanceiroMasterPro", "LancamentosGridSort.txt");

    private void GridLancamentos_Sorting(object sender, DataGridSortingEventArgs e)
    {
        Dispatcher.BeginInvoke(new Action(SalvarOrdenacaoGrade), DispatcherPriority.Background);
    }

    private void SalvarOrdenacaoGrade()
    {
        try
        {
            var view = CollectionViewSource.GetDefaultView(GridLancamentos.ItemsSource);
            var sort = view?.SortDescriptions.FirstOrDefault();
            if (sort == null || string.IsNullOrWhiteSpace(sort.Value.PropertyName)) return;
            Directory.CreateDirectory(Path.GetDirectoryName(ArquivoOrdenacaoGrade)!);
            File.WriteAllText(ArquivoOrdenacaoGrade,
                sort.Value.PropertyName + "|" + sort.Value.Direction.ToString());
        }
        catch { }
    }

    private void CarregarOrdenacaoGrade()
    {
        try
        {
            if (!File.Exists(ArquivoOrdenacaoGrade) || GridLancamentos.ItemsSource == null) return;
            var p = File.ReadAllText(ArquivoOrdenacaoGrade).Split('|');
            if (p.Length != 2 || !Enum.TryParse<ListSortDirection>(p[1], out var direcao)) return;
            var view = CollectionViewSource.GetDefaultView(GridLancamentos.ItemsSource);
            if (view == null) return;
            view.SortDescriptions.Clear();
            view.SortDescriptions.Add(new SortDescription(p[0], direcao));
            foreach (var coluna in GridLancamentos.Columns)
            {
                var caminho = coluna.SortMemberPath;
                if (string.IsNullOrWhiteSpace(caminho) && coluna is DataGridBoundColumn bc && bc.Binding is Binding b)
                    caminho = b.Path?.Path ?? "";
                coluna.SortDirection = caminho == p[0]
                    ? (direcao == ListSortDirection.Ascending ? ListSortDirection.Ascending : ListSortDirection.Descending)
                    : null;
            }
        }
        catch { }
    }

    // =========================================================
    // ENTER COMO TAB
    // =========================================================
    private void LancamentosView_PreviewKeyDown(
        object sender,
        KeyEventArgs e)
    {
        if(e.Key==Key.Enter){
            ComboBox? lookup=null;
            DependencyObject? d=e.OriginalSource as DependencyObject;
            while(d!=null){
                if(d is ComboBox cb){lookup=cb;break;}
                d=VisualTreeHelper.GetParent(d);
            }
            if(lookup is not null && _lookupBase.ContainsKey(lookup)){
                // Plano de Contas precisa validar pelo TEXTO antes de o ENTER virar TAB.
                // Isso cobre inclusive nomes duplicados, sem depender do item que o ComboBox
                // selecionou silenciosamente durante a digitação.
                if(lookup==PlanoContas || lookup==CentroCustos || lookup==GrupoContas || lookup==FluxoCaixa){
                    if(ConfirmarClassificacaoPorEnter(lookup)){
                        e.Handled=true;
                        AvancarAposLookup(lookup);
                    }else{
                        // Mesmo quando a escolha for cancelada, não deixa o ENTER escapar
                        // e prosseguir com uma classificação arbitrária.
                        e.Handled=true;
                    }
                    return;
                }
                if(ConfirmarLookup(lookup)){
                    e.Handled=true;
                    AvancarAposLookup(lookup);
                    return;
                }
            }
        }

        if (e.Key != Key.Enter)
            return;

        // Sequência rápida de digitação: VALOR -> ANOTAÇÕES -> SALVAR.
        if (ReferenceEquals(Keyboard.FocusedElement, Valor))
        {
            Anotacoes.Focus();
            Anotacoes.CaretIndex = Anotacoes.Text.Length;
            e.Handled = true;
            return;
        }
        if (ReferenceEquals(Keyboard.FocusedElement, Anotacoes))
        {
            BtnSalvar.Focus();
            e.Handled = true;
            return;
        }

        if (Keyboard.FocusedElement is Button)
            return;

        if (Keyboard.FocusedElement is ComboBox combo &&
            combo.IsDropDownOpen)
        {
            combo.IsDropDownOpen = false;
            e.Handled = true;
            return;
        }

        if (Keyboard.FocusedElement is UIElement elemento)
        {
            elemento.MoveFocus(
                new TraversalRequest(
                    FocusNavigationDirection.Next));

            e.Handled = true;
        }
    

        // ENTER = TAB para os campos de edição do lançamento.
        if(e.Key==Key.Enter && !e.Handled && e.OriginalSource is Control ctrl &&
           ctrl is not Button && !(ctrl is TextBox tx && tx.AcceptsReturn)){
            e.Handled=true;
            ctrl.MoveFocus(new TraversalRequest(FocusNavigationDirection.Next));
            return;
        }
}

    // =========================================================
    // CADASTROS
    // =========================================================
    private void CarregarCadastros()
    {
        Conta.ItemsSource =
            _contaRepository.Listar().Where(x => x.Ativo).ToList();

        Cliente.ItemsSource =
            _clienteRepository.Listar().Where(x => x.Ativo).ToList();

        PlanoContas.ItemsSource =
            _planoRepository.Listar().Where(x => x.Ativo).ToList();

        CentroCustos.ItemsSource =
            _centroRepository.Listar().Where(x => x.Ativo).ToList();

        GrupoContas.ItemsSource =
            _grupoRepository.Listar().Where(x => x.Ativo).ToList();

        FluxoCaixa.ItemsSource =
            _fluxoRepository.Listar().Where(x => x.Ativo).ToList();
    }

    private readonly Dictionary<ComboBox,List<object>> _lookupBase=new();
    private readonly Dictionary<ComboBox,string> _lookupTexto=new();
    private bool _lookupAlterando;

    private List<object> LookupBase(ComboBox c){
      if(_lookupBase.TryGetValue(c,out var b))return b;
      b=(c.ItemsSource??Array.Empty<object>()).Cast<object>().ToList();_lookupBase[c]=b;return b;
    }
    private static string LookupNome(object? o)=>o?.GetType().GetProperty("Nome")?.GetValue(o)?.ToString()??"";

    private void Lookup_PreviewTextInput(object sender,TextCompositionEventArgs e){
      if(sender is not ComboBox c||_lookupAlterando)return;
      var atual=_lookupTexto.TryGetValue(c,out var d)?d:(c.Text??"");
      // If field already has a selected value, first typed character starts a fresh search.
      if(c.SelectedItem!=null)atual="";
      atual+=e.Text;_lookupTexto[c]=atual;
      MostrarLookup(c,atual);
      e.Handled=true;
    }
    private void MostrarLookup(ComboBox c,string texto){
      var digitosTexto=new string((texto??"").Where(char.IsDigit).ToArray());
      var lista=LookupBase(c).Where(o=>{
        if(string.IsNullOrWhiteSpace(texto))return true;
        var nome=LookupNome(o);
        if(PesquisaAvancada.Texto(nome,texto))return true;
        // Para contas/cartões/documentos: qualquer trecho numérico também localiza.
        if(digitosTexto.Length>0){
          var digitosNome=new string(nome.Where(char.IsDigit).ToArray());
          return digitosNome.Contains(digitosTexto,StringComparison.OrdinalIgnoreCase);
        }
        return false;
      }).ToList();
      try{
        _lookupAlterando=true;
        c.ItemsSource=lista;c.SelectedIndex=-1;c.Text=texto;c.IsDropDownOpen=lista.Count>0;
        c.Dispatcher.BeginInvoke(new Action(()=>{
          if(c.Template.FindName("PART_EditableTextBox",c) is TextBox tb){tb.Text=texto;tb.CaretIndex=tb.Text.Length;tb.SelectionLength=0;tb.Focus();}
        }),System.Windows.Threading.DispatcherPriority.Input);
      }finally{_lookupAlterando=false;}
    }
    private bool ConfirmarLookup(ComboBox c){
      // Use the visible filtered list, not ComboBox.Text.
      object? item=c.SelectedItem;
      if(c.Items.Count==1)item=c.Items[0];
      if(item==null)return false;
      var nome=LookupNome(item);
      try{
        _lookupAlterando=true;
        c.SelectedItem=item;
        c.Text=nome;
        _lookupTexto[c]=nome;
        c.IsDropDownOpen=false;
        if(c.Template.FindName("PART_EditableTextBox",c) is TextBox tb){
          tb.Text=nome;tb.CaretIndex=nome.Length;tb.SelectionLength=0;
        }
      }finally{_lookupAlterando=false;}
      // Keep the actual object selected after editable text update.
      c.SelectedItem=item;
      return true;
    }

    private void AvancarAposLookup(ComboBox c){
      c.Dispatcher.BeginInvoke(new Action(()=>{
        // O TAB já funciona corretamente nesta tela; após confirmar a lupa,
        // o ENTER executa a mesma navegação de foco do TAB.
        var request=new TraversalRequest(FocusNavigationDirection.Next);
        if(c.Template.FindName("PART_EditableTextBox",c) is TextBox tb)
          tb.MoveFocus(request);
        else
          c.MoveFocus(request);
      }),System.Windows.Threading.DispatcherPriority.ApplicationIdle);
    }

    private void Lookup_PreviewKeyDown(object sender,KeyEventArgs e){
      if(sender is not ComboBox c)return;
      if(e.Key==Key.Back){
        var d=_lookupTexto.TryGetValue(c,out var x)?x:(c.Text??"");
        if(d.Length>0)d=d[..^1];_lookupTexto[c]=d;MostrarLookup(c,d);e.Handled=true;return;
      }
      if(e.Key==Key.Down||e.Key==Key.Up){
        if(!c.IsDropDownOpen)MostrarLookup(c,_lookupTexto.TryGetValue(c,out var d)?d:(c.Text??""));
        if(c.Items.Count==0){e.Handled=true;return;}
        int i=c.SelectedIndex;
        i=e.Key==Key.Down?(i<0?0:Math.Min(i+1,c.Items.Count-1)):(i<=0?c.Items.Count-1:i-1);
        _lookupAlterando=true;c.SelectedIndex=i;_lookupAlterando=false;
        if(c.ItemContainerGenerator.ContainerFromIndex(i) is ComboBoxItem ci)ci.BringIntoView();
        e.Handled=true;return;
      }
      if(e.Key==Key.Enter){
        // Normalmente o PreviewKeyDown da própria LancamentosView chega primeiro.
        // Mantemos esta validação aqui também para qualquer cenário em que o evento
        // seja tratado diretamente pelo ComboBox.
        if(c==PlanoContas || c==CentroCustos || c==GrupoContas || c==FluxoCaixa){
          if(ConfirmarClassificacaoPorEnter(c))AvancarAposLookup(c);
          e.Handled=true;return;
        }
        var confirmou=ConfirmarLookup(c);
        if(confirmou)AvancarAposLookup(c);
        e.Handled=true;return;
      }
      if(e.Key==Key.Escape){c.IsDropDownOpen=false;e.Handled=true;}
    }

    private bool ConfirmarClassificacaoPorEnter(ComboBox campo)
    {
        if (campo == PlanoContas) return ConfirmarPlanoContasPorEnter();

        var texto = (_lookupTexto.TryGetValue(campo, out var digitado) ? digitado : campo.Text) ?? "";
        texto = texto.Trim();
        if (string.IsNullOrWhiteSpace(texto)) return false;

        var iguais = LookupBase(campo)
            .Where(x => string.Equals(LookupNome(x).Trim(), texto, StringComparison.OrdinalIgnoreCase))
            .ToList();
        if (iguais.Count <= 1) return ConfirmarLookup(campo);

        var ids = iguais.Select(ObterIdLookup).Where(x => x > 0).ToHashSet();
        var classificacoes = _classificacaoRepository.Listar().Where(x =>
            (campo == CentroCustos && x.CentroCustosId.HasValue && ids.Contains(x.CentroCustosId.Value)) ||
            (campo == GrupoContas && ids.Contains(x.GrupoContasId)) ||
            (campo == FluxoCaixa && ids.Contains(x.FluxoCaixaId))).ToList();

        if (classificacoes.Count > 1)
        {
            var janela = new ClassificacaoEscolhaWindow(classificacoes) { Owner = Window.GetWindow(this) };
            if (janela.ShowDialog() != true || janela.Escolhida == null) return false;
            var escolhida = janela.Escolhida;
            AplicarClassificacaoEscolhida(escolhida);
            long idEscolhido = campo == CentroCustos ? (escolhida.CentroCustosId ?? 0) :
                               campo == GrupoContas ? escolhida.GrupoContasId : escolhida.FluxoCaixaId;
            var item = iguais.FirstOrDefault(x => ObterIdLookup(x) == idEscolhido);
            if (item != null) SelecionarLookup(campo, item);
            return item != null;
        }

        // Mesmo sem vínculo de classificação suficiente, nomes duplicados nunca são
        // aceitos silenciosamente: abre uma escolha simples identificada pelo código.
        var escolha = new EscolherCadastroDuplicadoWindow(iguais, LookupNome) { Owner = Window.GetWindow(this) };
        if (escolha.ShowDialog() != true || escolha.Escolhido == null) return false;
        SelecionarLookup(campo, escolha.Escolhido);
        return true;
    }

    private static long ObterIdLookup(object item)
    {
        var v = item.GetType().GetProperty("Id")?.GetValue(item);
        return v == null ? 0 : Convert.ToInt64(v, CultureInfo.InvariantCulture);
    }

    private void SelecionarLookup(ComboBox campo, object item)
    {
        var nome = LookupNome(item);
        try
        {
            _lookupAlterando = true;
            campo.ItemsSource = LookupBase(campo);
            campo.SelectedItem = item; campo.Text = nome; _lookupTexto[campo] = nome; campo.IsDropDownOpen = false;
            if (campo.Template.FindName("PART_EditableTextBox", campo) is TextBox tb)
            { tb.Text = nome; tb.CaretIndex = nome.Length; tb.SelectionLength = 0; }
        }
        finally { _lookupAlterando = false; }
        campo.SelectedItem = item;
    }

    private bool ConfirmarPlanoContasPorEnter()
    {
        var texto = (_lookupTexto.TryGetValue(PlanoContas, out var digitado) ? digitado : PlanoContas.Text) ?? "";
        texto = texto.Trim();
        if (string.IsNullOrWhiteSpace(texto)) return false;

        // Procura TODOS os Planos ativos com exatamente o nome digitado.
        // O ComboBox filtrado não pode decidir sozinho quando existem nomes iguais.
        var planos = LookupBase(PlanoContas)
            .OfType<PlanoContas>()
            .Where(p => string.Equals((p.Nome ?? "").Trim(), texto, StringComparison.OrdinalIgnoreCase))
            .ToList();

        // Se não houve igualdade exata, mantém o comportamento normal de autocomplete.
        if (planos.Count == 0)
        {
            if (!ConfirmarLookup(PlanoContas)) return false;
            if (PlanoContas.SelectedItem is PlanoContas selecionado)
                AplicarClassificacaoPlano(selecionado);
            return true;
        }

        var ids = planos.Select(p => p.Id).ToHashSet();
        var opcoes = _classificacaoRepository.Listar()
            .Where(x => ids.Contains(x.PlanoContasId))
            .ToList();

        ClassificacaoPlano? escolhida = null;
        if (opcoes.Count > 1)
        {
            var janela = new ClassificacaoEscolhaWindow(opcoes)
            {
                Owner = Window.GetWindow(this)
            };
            if (janela.ShowDialog() != true || janela.Escolhida == null)
                return false;
            escolhida = janela.Escolhida;
        }
        else if (opcoes.Count == 1)
        {
            escolhida = opcoes[0];
        }

        // Se existem Planos homônimos mas não há classificações suficientes para escolher,
        // não inventa uma classificação: conserva a seleção compatível com o texto.
        var planoEscolhido = escolhida != null
            ? planos.FirstOrDefault(p => p.Id == escolhida.PlanoContasId)
            : planos.FirstOrDefault();
        if (planoEscolhido == null) return false;

        try
        {
            _confirmandoPlanoPorEnter = true;
            _lookupAlterando = true;
            PlanoContas.ItemsSource = LookupBase(PlanoContas);
            PlanoContas.SelectedItem = planoEscolhido;
            PlanoContas.Text = planoEscolhido.Nome;
            _lookupTexto[PlanoContas] = planoEscolhido.Nome;
            PlanoContas.IsDropDownOpen = false;
            if (PlanoContas.Template.FindName("PART_EditableTextBox", PlanoContas) is TextBox tb)
            {
                tb.Text = planoEscolhido.Nome;
                tb.CaretIndex = tb.Text.Length;
                tb.SelectionLength = 0;
            }
        }
        finally
        {
            _lookupAlterando = false;
            _confirmandoPlanoPorEnter = false;
        }

        if (escolhida != null)
            AplicarClassificacaoEscolhida(escolhida);
        else
            AplicarClassificacaoPlano(planoEscolhido);

        return true;
    }

    private void AplicarClassificacaoEscolhida(ClassificacaoPlano escolhida)
    {
        var grupo = (GrupoContas.ItemsSource as IEnumerable<GrupoContas>)?.FirstOrDefault(x => x.Id == escolhida.GrupoContasId)
                    ?? _grupoRepository.Listar().FirstOrDefault(x => x.Id == escolhida.GrupoContasId);
        var fluxo = (FluxoCaixa.ItemsSource as IEnumerable<FluxoCaixa>)?.FirstOrDefault(x => x.Id == escolhida.FluxoCaixaId)
                    ?? _fluxoRepository.Listar().FirstOrDefault(x => x.Id == escolhida.FluxoCaixaId);
        Dispatcher.BeginInvoke(new Action(() =>
        {
            if (grupo != null) { GrupoContas.SelectedItem = grupo; GrupoContas.Text = grupo.Nome; }
            if (fluxo != null) { FluxoCaixa.SelectedItem = fluxo; FluxoCaixa.Text = fluxo.Nome; }
        }), System.Windows.Threading.DispatcherPriority.Input);
    }

    private void PlanoContas_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (_confirmandoPlanoPorEnter) return;
        if (PlanoContas.SelectedItem is not PlanoContas plano) return;
        AplicarClassificacaoPlano(plano);
    }

    private void AplicarClassificacaoPlano(PlanoContas plano)
    {
        var opcoes = _classificacaoRepository.Listar(plano.Id);
        if (opcoes.Count == 0) return;

        ClassificacaoPlano? escolhida = opcoes.Count == 1 ? opcoes[0] : null;
        if (opcoes.Count > 1)
        {
            var janela = new ClassificacaoEscolhaWindow(opcoes)
            {
                Owner = Window.GetWindow(this)
            };
            if (janela.ShowDialog() != true) return;
            escolhida = janela.Escolhida;
        }
        if (escolhida == null) return;
        AplicarClassificacaoEscolhida(escolhida);
        // Centro de Custos permanece livre para escolha no lançamento.
    }

    private void CarregarLancamentos()
    {
        _rateioRepository.SincronizarIdentificacaoRateios();
        _lancamentos = _repository.Listar();
        var rateados=_rateioRepository.ListarLancamentosRateados();
        var numerosRateio=_rateioRepository.ListarNumerosRateio();
        var parcelados=_parcelamentoRepository.ListarLancamentosParcelados();
        foreach(var l in _lancamentos)
        {
            l.PossuiRateio=rateados.Contains(l.Id);
            l.NumeroRateio=numerosRateio.TryGetValue(l.Id,out var nr)?nr:0;
            l.PossuiParcelamento=parcelados.Contains(l.Id);
        }
        CarregarSaldosContas();
        AplicarFiltros();
    }

    private void CarregarSaldosContas()
    {
        if (ListaSaldosContas == null) return;
        var contas = _contaRepository.Listar().Where(c => c.Ativo).ToList();
        var linhas = contas.Select(c => new ContaSaldoLinha
        {
            Id = c.Id,
            Nome = c.Nome,
            TipoConta = string.IsNullOrWhiteSpace(c.TipoConta) ? "Conta Bancária" : c.TipoConta,
            Bandeira = c.Bandeira,
            Banco = c.Banco,
            Saldo = c.SaldoInicial + _lancamentos.Where(x => x.ContaBancariaId == c.Id && x.Baixado && x.Ativo)
                .Sum(x => x.Tipo.Equals("Pagar", StringComparison.OrdinalIgnoreCase) ? -Math.Abs(x.Valor) : Math.Abs(x.Valor))
        }).OrderBy(x => OrdemTipo(x.TipoConta)).ThenBy(x => x.Nome).ToList();

        var visao = System.Windows.Data.CollectionViewSource.GetDefaultView(linhas);
        visao.GroupDescriptions.Clear();
        visao.GroupDescriptions.Add(new System.Windows.Data.PropertyGroupDescription(nameof(ContaSaldoLinha.CategoriaTipo)));
        ListaSaldosContas.ItemsSource = visao;
        if (TotalSaldosContas != null)
            TotalSaldosContas.Text = "R$ " + Math.Abs(linhas.Sum(x => x.Saldo)).ToString("N2", _culturaBrasil);
    }

    private void TodasContas_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
        _contaFiltroId = null;
        if (ListaSaldosContas != null) ListaSaldosContas.SelectedItem = null;
        AtualizarTituloContaFiltro();
        AplicarFiltros();
    }

    private void ListaSaldosContas_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (ListaSaldosContas?.SelectedItem is not ContaSaldoLinha linha) return;
        _contaFiltroId = linha.Id;
        AtualizarTituloContaFiltro(linha.Nome);
        AplicarFiltros();
    }

    private void AtualizarTituloContaFiltro(string? nome = null)
    {
        if (TituloLancamentos == null) return;
        TituloLancamentos.Text = _contaFiltroId.HasValue
            ? $"LANÇAMENTOS — {nome ?? _contaRepository.Listar().FirstOrDefault(c => c.Id == _contaFiltroId.Value)?.Nome ?? "CONTA"}"
            : "LANÇAMENTOS — TODAS AS CONTAS";
    }

    private void ListaSaldosContas_MouseDoubleClick(object sender, MouseButtonEventArgs e)
    {
        if (ListaSaldosContas.SelectedItem is not ContaSaldoLinha linha) return;
        if (linha.TipoConta.Equals("Cartão de Crédito", StringComparison.OrdinalIgnoreCase))
        {
            (Window.GetWindow(this) as MainWindow)?.AbrirCartao(linha.Id);
            return;
        }
        var view = new ContaBancariaView();
        view.SelecionarConta(linha.Id);
        AbrirCadastro(view);
        CarregarCadastros();
        CarregarLancamentos();
    }

    private static int OrdemTipo(string tipo)
    {
        var t = (tipo ?? string.Empty).Trim();
        if (t.Equals("Dinheiro", StringComparison.OrdinalIgnoreCase)) return 0;
        if (t.Equals("Conta Bancária", StringComparison.OrdinalIgnoreCase) || t.Equals("Contas Bancárias", StringComparison.OrdinalIgnoreCase)) return 1;
        if (t.Equals("Cartão de Crédito", StringComparison.OrdinalIgnoreCase)) return 2;
        // Ordem fixa dos grupos no Resumo de Contas: DINHEIRO, CONTAS BANCÁRIAS,
        // CARTÕES DE CRÉDITO, OUTROS e APLICAÇÕES.
        if (t.Equals("Aplicações", StringComparison.OrdinalIgnoreCase) || t.Equals("Aplicação", StringComparison.OrdinalIgnoreCase) || t.Equals("Aplicacoes", StringComparison.OrdinalIgnoreCase)) return 4;
        return 3;
    }


    private string ArquivoLayoutGradeLancamentos => System.IO.Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
        "FinanceiroMasterPro", "GridLancamentosLayout.txt");

    private void CarregarLayoutGradeLancamentos()
    {
        try
        {
            if (!System.IO.File.Exists(ArquivoLayoutGradeLancamentos)) return;
            var linhas = System.IO.File.ReadAllLines(ArquivoLayoutGradeLancamentos);
            for (int i = 0; i < linhas.Length && i < GridLancamentos.Columns.Count; i++)
            {
                var p = linhas[i].Split('|');
                if (p.Length < 2) continue;
                if (double.TryParse(p[0], System.Globalization.NumberStyles.Any, System.Globalization.CultureInfo.InvariantCulture, out var w))
                    GridLancamentos.Columns[i].Width = new DataGridLength(Math.Max(35, w));
                if (int.TryParse(p[1], out var di) && di >= 0 && di < GridLancamentos.Columns.Count)
                    GridLancamentos.Columns[i].DisplayIndex = di;
            }
        }
        catch { }
    }

    private void SalvarLayoutGradeLancamentos()
    {
        try
        {
            if (GridLancamentos == null || GridLancamentos.Columns.Count == 0) return;
            System.IO.Directory.CreateDirectory(System.IO.Path.GetDirectoryName(ArquivoLayoutGradeLancamentos)!);
            var linhas = GridLancamentos.Columns.Select(c =>
                c.ActualWidth.ToString(System.Globalization.CultureInfo.InvariantCulture) + "|" +
                c.DisplayIndex.ToString(System.Globalization.CultureInfo.InvariantCulture));
            System.IO.File.WriteAllLines(ArquivoLayoutGradeLancamentos, linhas);
        }
        catch { }
    }

    private void LancamentosView_Unloaded(object sender, RoutedEventArgs e)
    {
        SalvarLayoutGradeLancamentos();
        SalvarLarguraPainelSaldos();
    }

    private void SalvarLarguraPainelSaldos() { }

    private string ChaveEmpresaLayout => string.IsNullOrWhiteSpace(EmpresaDatabaseManager.EmpresaAtual?.Id) ? "principal" : EmpresaDatabaseManager.EmpresaAtual!.Id;
    // 2026.182: as colunas internas do Resumo acompanham dinamicamente a largura do painel.
    // A largura do PAINEL continua sendo individual por empresa; não gravamos larguras absolutas
    // de Nome/Valor, pois elas faziam contas desaparecerem ao estreitar o painel.
    private void CarregarLargurasSaldos()
    {
        ColSaldoNome.Width = new DataGridLength(1, DataGridLengthUnitType.Star);
        ColSaldoValor.Width = DataGridLength.Auto;
    }

    private string ArquivoLarguraPainelSaldos => System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "FinanceiroMasterPro", $"PainelSaldosLargura_v181_{ChaveEmpresaLayout}.txt");
    private void CarregarLarguraPainelSaldos()
    {
        try { if(System.IO.File.Exists(ArquivoLarguraPainelSaldos) && double.TryParse(System.IO.File.ReadAllText(ArquivoLarguraPainelSaldos), System.Globalization.NumberStyles.Any, System.Globalization.CultureInfo.InvariantCulture, out var w)) ColunaPainelSaldos.Width=new GridLength(Math.Max(180,w)); } catch { }
    }
    private void PainelSaldos_DragCompleted(object sender, System.Windows.Controls.Primitives.DragCompletedEventArgs e)
    {
        try { System.IO.Directory.CreateDirectory(System.IO.Path.GetDirectoryName(ArquivoLarguraPainelSaldos)!); System.IO.File.WriteAllText(ArquivoLarguraPainelSaldos, ColunaPainelSaldos.ActualWidth.ToString(System.Globalization.CultureInfo.InvariantCulture)); } catch { }
    }

    private sealed class ContaSaldoLinha
    {
        private static readonly CultureInfo _culturaPtBr = new("pt-BR");
        public long Id { get; set; }
        public string Nome { get; set; } = "";
        public string TipoConta { get; set; } = "Conta Bancária";
        public string CategoriaTipo
        {
            get
            {
                var t = (TipoConta ?? string.Empty).Trim();
                if (t.Equals("Dinheiro", StringComparison.OrdinalIgnoreCase)) return "0-DINHEIRO";
                if (t.Equals("Conta Bancária", StringComparison.OrdinalIgnoreCase) || t.Equals("Contas Bancárias", StringComparison.OrdinalIgnoreCase)) return "1-CONTAS BANCÁRIAS";
                if (t.Equals("Cartão de Crédito", StringComparison.OrdinalIgnoreCase) || t.Equals("Cartao de Credito", StringComparison.OrdinalIgnoreCase)) return "2-CARTÃO DE CRÉDITO";
                if (t.Equals("Aplicações", StringComparison.OrdinalIgnoreCase) || t.Equals("Aplicação", StringComparison.OrdinalIgnoreCase) || t.Equals("Aplicacoes", StringComparison.OrdinalIgnoreCase)) return "4-APLICAÇÕES";
                return "3-OUTROS";
            }
        }
        public string TipoContaTitulo => CategoriaTipo.Length > 2 ? CategoriaTipo[2..] : "OUTROS";
        public string Bandeira { get; set; } = "";
        public string Banco { get; set; } = "";
        public string BandeiraIcone => InstitutionCatalog.Resolver(Bandeira, Banco)?.Icone ?? "";
        public decimal Saldo { get; set; }
        public decimal SaldoExibicao => Math.Abs(Saldo);
        public bool SaldoNegativo => Saldo < 0;
    }

    // =========================================================
    // BLOQUEIO DE EDIÇÃO
    // =========================================================
    private void DefinirEdicao(bool habilitar)
    {
        Tipo.IsEnabled = habilitar;
        Conta.IsEnabled = habilitar;
        DataPagto.IsEnabled = habilitar;
        DataEmissao.IsEnabled = habilitar;
        Cliente.IsEnabled = habilitar;
        Descricao.IsEnabled = habilitar;
        NumeroDocumento.IsEnabled = habilitar;
        PlanoContas.IsEnabled = habilitar;
        CentroCustos.IsEnabled = habilitar;
        GrupoContas.IsEnabled = habilitar;
        FluxoCaixa.IsEnabled = habilitar;
        Valor.IsEnabled = habilitar;
        Anotacoes.IsEnabled = habilitar;

        BtnSalvar.IsEnabled = habilitar;

        BtnAlterar.IsEnabled =
            _idAtual != 0 && !habilitar;

        BtnExcluir.IsEnabled =
            _idAtual != 0;

        BtnRatear.IsEnabled = habilitar || _idAtual != 0;
        BtnParcelar.IsEnabled = habilitar || _idAtual != 0;
    }

    // =========================================================
    // NOVO
    // =========================================================
    private void Novo()
    {
        _idAtual = 0;
        _modoAlteracao = false;

        Tipo.SelectedIndex = 0;
        Conta.SelectedItem = null;

        // Se o usuário está no painel de uma conta específica, NOVO deve manter
        // automaticamente essa mesma conta. Em TODAS AS CONTAS (_contaFiltroId nulo),
        // nenhuma conta específica é imposta por esta regra.
        if (_contaFiltroId.HasValue)
        {
            var contaAtual = (Conta.ItemsSource as IEnumerable<ContaBancaria>)?.FirstOrDefault(x => x.Id == _contaFiltroId.Value)
                             ?? _contaRepository.Listar().FirstOrDefault(x => x.Id == _contaFiltroId.Value && x.Ativo);
            if (contaAtual != null)
            {
                Conta.SelectedItem = contaAtual;
                Conta.Text = contaAtual.Nome;
            }
        }

        DataPagto.SelectedDate = DateTime.Today;
        DataEmissao.SelectedDate = DateTime.Today;

        Cliente.SelectedItem = null;
        Descricao.Clear();
        NumeroDocumento.Clear();

        PlanoContas.SelectedItem = null;
        CentroCustos.SelectedItem = null;
        GrupoContas.SelectedItem = null;
        FluxoCaixa.SelectedItem = null;

        Valor.Clear();
        Periodo.Clear();
        Anotacoes.Clear();

        GridLancamentos.SelectedItem = null;

        DefinirEdicao(true);

        BtnAlterar.IsEnabled = false;
        BtnExcluir.IsEnabled = false;
        BtnRatear.IsEnabled = true;
        BtnParcelar.IsEnabled = true;

        Tipo.Focus();
    }

    private void Novo_Click(
        object sender,
        RoutedEventArgs e)
    {
        Novo();
    }

    // =========================================================
    // ALTERAR
    // =========================================================
    private void Alterar_Click(
        object sender,
        RoutedEventArgs e)
    {
        if (_idAtual == 0)
        {
            MessageBox.Show(
                "Selecione um lançamento para alterar.",
                "Financeiro Master Pro",
                MessageBoxButton.OK,
                MessageBoxImage.Information);

            return;
        }

        _modoAlteracao = true;

        DefinirEdicao(true);

        BtnAlterar.IsEnabled = false;
        BtnParcelar.IsEnabled = false;

        Tipo.Focus();
    }

    // =========================================================
    // TIPO
    // =========================================================
    private string ObterTipo()
    {
        if (Tipo.SelectedItem is ComboBoxItem item)
            return item.Content?.ToString() ?? "";

        return "";
    }

    private void SelecionarTipo(string tipo)
    {
        foreach (var objeto in Tipo.Items)
        {
            if (objeto is ComboBoxItem item &&
                string.Equals(
                    item.Content?.ToString(),
                    tipo,
                    StringComparison.OrdinalIgnoreCase))
            {
                Tipo.SelectedItem = item;
                return;
            }
        }

        Tipo.SelectedIndex = 0;
    }

    // =========================================================
    // MONTA LANÇAMENTO
    // =========================================================
    private Lancamento MontarLancamento(
        decimal valor,
        long id = 0)
    {
        return new Lancamento
        {
            Id = id,
            Tipo = ObterTipo(),

            ContaBancariaId =
                (Conta.SelectedItem as ContaBancaria)?.Id,

            DataPagamento = DataPagto.SelectedDate,

            DataEmissao =
                DataEmissao.SelectedDate ?? DateTime.Today,

            ClienteFornecedorId =
                (Cliente.SelectedItem as ClienteFornecedor)?.Id,

            Descricao = Descricao.Text.Trim(),
            NumeroDocumento = NumeroDocumento.Text.Trim(),

            PlanoContasId =
                (PlanoContas.SelectedItem as PlanoContas)?.Id,

            CentroCustosId =
                (CentroCustos.SelectedItem as CentroCustos)?.Id,

            GrupoContasId =
                (GrupoContas.SelectedItem as GrupoContas)?.Id,

            FluxoCaixaId =
                (FluxoCaixa.SelectedItem as FluxoCaixa)?.Id,

            // Lançamento normal: o usuário informa sempre o módulo do valor.
            // Pagar é armazenado negativo; Receber positivo.
            // Transferência não é criada por este formulário: deve manter saída/entrada
            // em lançamentos próprios quando o módulo específico for usado.
            Valor = (ObterTipo().Equals("Pagar", StringComparison.OrdinalIgnoreCase) ||
                     ObterTipo().Equals("Pago", StringComparison.OrdinalIgnoreCase))
                ? -Math.Abs(valor)
                : (ObterTipo().Equals("Receber", StringComparison.OrdinalIgnoreCase) ||
                   ObterTipo().Equals("Recebido", StringComparison.OrdinalIgnoreCase))
                    ? Math.Abs(valor)
                    : valor,
            Periodo = Periodo.Text.Trim(),
            Anotacoes = Anotacoes.Text.Trim(),

            Baixado = false,
            DataBaixa = null,
            Ativo = true
        };
    }

    private bool ValidarDadosTela(
        out decimal valor)
    {
        valor = 0;

        if (string.IsNullOrWhiteSpace(ObterTipo()))
        {
            MessageBox.Show("Informe o Tipo do lançamento.");
            Tipo.Focus();
            return false;
        }

        if (string.IsNullOrWhiteSpace(Descricao.Text))
        {
            MessageBox.Show("Informe a Descrição do lançamento.");
            Descricao.Focus();
            return false;
        }

        if (!TentarLerValor(Valor.Text, out valor) ||
            valor == 0)
        {
            MessageBox.Show(
                "Informe um Valor válido diferente de zero.");

            Valor.Focus();
            return false;
        }

        if (DataEmissao.SelectedDate == null)
        {
            MessageBox.Show("Informe a Data de Emissão.");
            DataEmissao.Focus();
            return false;
        }

        return true;
    }

    private bool TentarLerValor(
        string texto,
        out decimal valor)
    {
        string limpo =
            texto.Trim()
                .Replace("R$", "")
                .Replace(" ", "");

        return decimal.TryParse(
            limpo,
            NumberStyles.Number |
            NumberStyles.AllowCurrencySymbol,
            _culturaBrasil,
            out valor);
    }

    // =========================================================
    // SALVAR
    // =========================================================
    private void Salvar_Click(
        object sender,
        RoutedEventArgs e)
    {
        try
        {
            if (_idAtual != 0 &&
                !_modoAlteracao)
            {
                MessageBox.Show(
                    "Para alterar este lançamento, clique primeiro em ALTERAR.");

                return;
            }

            if (!ValidarDadosTela(out decimal valor))
                return;

            // TRANSFERÊNCIA: cria automaticamente as duas pontas (origem e destino)
            // com Tipo=Transferência. Não passa pela janela Pagar/Receber/Pago/Recebido.
            if (_idAtual == 0 && ObterTipo().Equals("Transferência", StringComparison.OrdinalIgnoreCase))
            {
                if (Conta.SelectedItem is not ContaBancaria contaOrigem)
                {
                    MessageBox.Show("Informe a Conta Bancária de origem da transferência.");
                    Conta.Focus();
                    return;
                }

                var contasDestino = _contaRepository.Listar()
                    .Where(x => x.Ativo && x.Id != contaOrigem.Id)
                    .OrderBy(x => x.Nome)
                    .ToList();
                if (contasDestino.Count == 0)
                {
                    MessageBox.Show("Não existe outra conta ativa para receber a transferência.");
                    return;
                }

                var seletor = new Window
                {
                    Title = "Transferência - Conta de destino", Width = 470, Height = 190,
                    WindowStartupLocation = WindowStartupLocation.CenterOwner, ResizeMode = ResizeMode.NoResize,
                    Owner = Window.GetWindow(this)
                };
                var painel = new StackPanel { Margin = new Thickness(20) };
                painel.Children.Add(new TextBlock { Text = $"Origem: {contaOrigem.Nome}", FontWeight = FontWeights.SemiBold, Margin = new Thickness(0,0,0,10) });
                painel.Children.Add(new TextBlock { Text = "Conta de destino:" });
                var cbDestino = new ComboBox { ItemsSource = contasDestino, DisplayMemberPath = "Nome", Height = 30, Margin = new Thickness(0,5,0,12) };
                painel.Children.Add(cbDestino);
                var confirmar = new Button { Content = "CONFIRMAR TRANSFERÊNCIA", Height = 34, Width = 210, HorizontalAlignment = HorizontalAlignment.Right };
                confirmar.Click += (_, __) =>
                {
                    if (cbDestino.SelectedItem == null) { MessageBox.Show("Selecione a conta de destino."); return; }
                    seletor.DialogResult = true;
                };
                painel.Children.Add(confirmar);
                seletor.Content = painel;
                if (seletor.ShowDialog() != true || cbDestino.SelectedItem is not ContaBancaria contaDestino) return;

                var dataMovimento = DataPagto.SelectedDate ?? DataEmissao.SelectedDate ?? DateTime.Today;
                var periodoTransferencia = dataMovimento.ToString("MM/yyyy");
                var origem = MontarLancamento(Math.Abs(valor));
                origem.Tipo = "Transferência";
                origem.ContaBancariaId = contaOrigem.Id;
                origem.Valor = -Math.Abs(valor);
                origem.Baixado = true;
                origem.DataBaixa = dataMovimento;
                origem.DataPagamento = dataMovimento;
                origem.Periodo = periodoTransferencia;
                origem.Anotacoes = $"TRANSFERÊNCIA PARA: {contaDestino.Nome}" + (string.IsNullOrWhiteSpace(origem.Anotacoes) ? "" : " | " + origem.Anotacoes);

                var destino = MontarLancamento(Math.Abs(valor));
                destino.Tipo = "Transferência";
                destino.ContaBancariaId = contaDestino.Id;
                destino.Valor = Math.Abs(valor);
                destino.Baixado = true;
                destino.DataBaixa = dataMovimento;
                destino.DataPagamento = dataMovimento;
                destino.Periodo = periodoTransferencia;
                destino.Anotacoes = $"TRANSFERÊNCIA DE: {contaOrigem.Nome}" + (string.IsNullOrWhiteSpace(destino.Anotacoes) ? "" : " | " + destino.Anotacoes);

                _repository.Salvar(origem);
                _repository.Salvar(destino);
                MessageBox.Show("Transferência salva com sucesso nas duas contas.", "Financeiro Master Pro", MessageBoxButton.OK, MessageBoxImage.Information);
                CarregarLancamentos();
                Novo();
                return;
            }

            StatusLancamentoEscolha? statusEscolhido = null;
            if (_idAtual == 0)
            {
                var janelaStatus = new StatusLancamentoWindow
                {
                    Owner = Window.GetWindow(this)
                };
                if (janelaStatus.ShowDialog() != true)
                    return;
                statusEscolhido = janelaStatus.Escolha;

                // TRANSFERÊNCIA também faz parte da confirmação final do lançamento.
                // Reaproveita a rotina já existente de origem/destino e grava as duas pontas.
                if (statusEscolhido == StatusLancamentoEscolha.Transferencia)
                {
                    SelecionarTipo("Transferência");
                    Salvar_Click(sender, e);
                    return;
                }

                // Mantém na tela exatamente o status escolhido pelo usuário.
                // A persistência continua usando Pagar/Receber + Baixado, preservando
                // compatibilidade com relatórios, saldos, cartão, rateio e parcelamento.
                SelecionarTipo(statusEscolhido.Value.ToString());
            }

            var item =
                MontarLancamento(valor, _idAtual);

            // No banco, Pago/Recebido continuam representados por Pagar/Receber + Baixado.
            // Na tela, porém, o usuário sempre vê Pago/Recebido corretamente.
            if (statusEscolhido == StatusLancamentoEscolha.Pago)
                item.Tipo = "Pagar";
            else if (statusEscolhido == StatusLancamentoEscolha.Recebido)
                item.Tipo = "Receber";

            if (statusEscolhido == StatusLancamentoEscolha.Pago ||
                statusEscolhido == StatusLancamentoEscolha.Recebido)
            {
                var dataBaixa = item.DataPagamento ?? DateTime.Today;
                item.Baixado = true;
                item.DataBaixa = dataBaixa;
                item.Periodo = dataBaixa.ToString("MM/yyyy");
                Periodo.Text = item.Periodo;
            }
            else if (statusEscolhido.HasValue)
            {
                item.Baixado = false;
                item.DataBaixa = null;
                item.Periodo = string.Empty;
                Periodo.Text = string.Empty;
            }

            if (_idAtual != 0)
            {
                var existente =
                    _lancamentos.FirstOrDefault(
                        x => x.Id == _idAtual);

                if (existente != null)
                {
                    item.Baixado = existente.Baixado;
                    item.DataBaixa = existente.DataBaixa;
                    item.Periodo = existente.Periodo;
                    item.Ativo = existente.Ativo;
                }
            }

            bool novo = _idAtual == 0;

            _repository.Salvar(item);

            MessageBox.Show(
                novo
                    ? "Lançamento salvo com sucesso."
                    : "Lançamento alterado com sucesso.",
                "Financeiro Master Pro",
                MessageBoxButton.OK,
                MessageBoxImage.Information);

            // Quando o lançamento foi aberto a partir do Relatório, mantém a Grade
            // exclusivamente nesse lançamento após SALVAR, já recarregado do banco.
            // Assim o usuário confere imediatamente o valor corrigido e só sai desse
            // modo ao clicar em VOLTAR para o relatório.
            if (_lancamentoExclusivoId.HasValue)
            {
                var idExclusivo = _lancamentoExclusivoId.Value;
                AbrirSomenteLancamentoPorId(idExclusivo);
                return;
            }

            CarregarLancamentos();
            Novo();
        }
        catch (Exception ex)
        {
            MessageBox.Show(
                "Não foi possível salvar o lançamento.\n\n" +
                ex.Message);
        }
    }

    // =========================================================
    // EXCLUSÃO INDIVIDUAL
    // =========================================================
    private void Excluir_Click(
        object sender,
        RoutedEventArgs e)
    {
        if (_idAtual == 0)
        {
            MessageBox.Show(
                "Selecione um lançamento para excluir.");

            return;
        }

        var item =
            _lancamentos.FirstOrDefault(
                x => x.Id == _idAtual);

        if (item == null)
            return;

        var resposta =
            MessageBox.Show(
                "EXCLUIR ESTE LANÇAMENTO?\n\n" +
                $"Descrição: {item.Descricao}\n" +
                $"Valor: {item.Valor.ToString("N2", _culturaBrasil)}\n" +
                $"Data: {item.DataPagamento:dd/MM/yyyy}\n\n" +
                "Esta operação não poderá ser desfeita.",
                "Confirmar Exclusão",
                MessageBoxButton.YesNo,
                MessageBoxImage.Warning);

        if (resposta != MessageBoxResult.Yes)
            return;

        try
        {
            int excluidos =
                _repository.Excluir(item.Id);

            MessageBox.Show(
                excluidos > 0
                    ? "Lançamento excluído com sucesso."
                    : "Nenhum lançamento foi excluído.");

            CarregarLancamentos();
            Novo();
        }
        catch (Exception ex)
        {
            MessageBox.Show(
                "Não foi possível excluir.\n\n" +
                ex.Message);
        }
    }

    // =========================================================
    // APAGAR EM MASSA
    // =========================================================
    public void SolicitarApagarLancamentos()
    {
        ApagarLancamentos_Click(this, new RoutedEventArgs());
    }

    private void ApagarLancamentos_Click(
        object sender,
        RoutedEventArgs e)
    {
        string opcao =
            Perguntar(
                "APAGAR LANÇAMENTOS",
                "Digite somente o número:\n\n" +
                "1 - ANO\n" +
                "2 - MÊS\n" +
                "3 - PERÍODO\n" +
                "4 - TUDO\n" +
                "0 - CANCELAR");

        if (string.IsNullOrWhiteSpace(opcao) ||
            opcao == "0")
            return;

        try
        {
            switch (opcao.Trim())
            {
                case "1":
                    ApagarPorAno();
                    break;

                case "2":
                    ApagarPorMes();
                    break;

                case "3":
                    ApagarPorPeriodo();
                    break;

                case "4":
                    ApagarTudo();
                    break;

                default:
                    MessageBox.Show(
                        "Opção inválida.\n\n" +
                        "Digite 1, 2, 3, 4 ou 0.");
                    break;
            }
        }
        catch (Exception ex)
        {
            MessageBox.Show(
                "Não foi possível apagar os lançamentos.\n\n" +
                ex.Message,
                "Financeiro Master Pro",
                MessageBoxButton.OK,
                MessageBoxImage.Error);
        }
    }

    private void ApagarPorAno()
    {
        string texto =
            Perguntar(
                "1 - APAGAR POR ANO",
                "Digite o ano que deseja apagar.\n\n" +
                "Exemplo: 2026");

        if (!int.TryParse(texto, out int ano) ||
            ano < 1900 ||
            ano > 2200)
        {
            MessageBox.Show("Ano inválido.");
            return;
        }

        int quantidade =
            _repository.ContarPorAno(ano);

        if (!ConfirmarExclusao(
                quantidade,
                $"ANO {ano}"))
            return;

        int excluidos =
            _repository.ExcluirPorAno(ano);

        FinalizarExclusao(excluidos);
    }

    private void ApagarPorMes()
    {
        string texto =
            Perguntar(
                "2 - APAGAR POR MÊS",
                "Digite o mês no formato MM/AAAA.\n\n" +
                "Exemplo: 07/2026");

        if (!DateTime.TryParseExact(
                "01/" + texto.Trim(),
                "dd/MM/yyyy",
                _culturaBrasil,
                DateTimeStyles.None,
                out DateTime data))
        {
            MessageBox.Show(
                "Mês inválido.\n\n" +
                "Use o formato MM/AAAA.");

            return;
        }

        int quantidade =
            _repository.ContarPorMes(
                data.Year,
                data.Month);

        if (!ConfirmarExclusao(
                quantidade,
                data.ToString("MM/yyyy")))
            return;

        int excluidos =
            _repository.ExcluirPorMes(
                data.Year,
                data.Month);

        FinalizarExclusao(excluidos);
    }

    private void ApagarPorPeriodo()
    {
        string inicioTexto =
            Perguntar(
                "3 - APAGAR POR PERÍODO",
                "Digite a DATA INICIAL.\n\n" +
                "Exemplo: 01/01/2026");

        if (!DateTime.TryParseExact(
                inicioTexto.Trim(),
                "dd/MM/yyyy",
                _culturaBrasil,
                DateTimeStyles.None,
                out DateTime inicio))
        {
            MessageBox.Show("Data inicial inválida.");
            return;
        }

        string fimTexto =
            Perguntar(
                "3 - APAGAR POR PERÍODO",
                "Digite a DATA FINAL.\n\n" +
                "Exemplo: 31/12/2026");

        if (!DateTime.TryParseExact(
                fimTexto.Trim(),
                "dd/MM/yyyy",
                _culturaBrasil,
                DateTimeStyles.None,
                out DateTime fim))
        {
            MessageBox.Show("Data final inválida.");
            return;
        }

        if (fim.Date < inicio.Date)
        {
            MessageBox.Show(
                "A Data Final não pode ser menor que a Data Inicial.");

            return;
        }

        int quantidade =
            _repository.ContarPorPeriodo(
                inicio,
                fim);

        string descricao =
            $"{inicio:dd/MM/yyyy} até {fim:dd/MM/yyyy}";

        if (!ConfirmarExclusao(
                quantidade,
                descricao))
            return;

        int excluidos =
            _repository.ExcluirPorPeriodo(
                inicio,
                fim);

        FinalizarExclusao(excluidos);
    }

    private void ApagarTudo()
    {
        int quantidade =
            _repository.ContarTodos();

        if (quantidade == 0)
        {
            MessageBox.Show(
                "Não existem lançamentos para apagar.");

            return;
        }

        var primeiraConfirmacao =
            MessageBox.Show(
                "ATENÇÃO\n\n" +
                $"Serão apagados TODOS os {quantidade:N0} lançamentos.\n\n" +
                "Também serão removidos os Rateios e vínculos de " +
                "Parcelamentos desses lançamentos.\n\n" +
                "Deseja continuar?",
                "4 - APAGAR TUDO",
                MessageBoxButton.YesNo,
                MessageBoxImage.Warning);

        if (primeiraConfirmacao !=
            MessageBoxResult.Yes)
            return;

        string confirmacao =
            Perguntar(
                "CONFIRMAÇÃO FINAL",
                "Para realmente apagar TODOS os lançamentos,\n" +
                "digite o número 4 novamente.\n\n" +
                "Para cancelar, digite 0.");

        if (confirmacao.Trim() != "4")
            return;

        int excluidos =
            _repository.ExcluirTodos();

        FinalizarExclusao(excluidos);
    }

    private bool ConfirmarExclusao(
        int quantidade,
        string descricao)
    {
        if (quantidade <= 0)
        {
            MessageBox.Show(
                "Nenhum lançamento foi encontrado para:\n\n" +
                descricao);

            return false;
        }

        var resposta =
            MessageBox.Show(
                $"Foram encontrados {quantidade:N0} lançamentos.\n\n" +
                $"Filtro: {descricao}\n\n" +
                "Deseja APAGAR esses lançamentos?\n\n" +
                "Esta operação não poderá ser desfeita.",
                "Confirmar Exclusão",
                MessageBoxButton.YesNo,
                MessageBoxImage.Warning);

        return resposta == MessageBoxResult.Yes;
    }

    private void FinalizarExclusao(int quantidade)
    {
        MessageBox.Show(
            $"{quantidade:N0} lançamento(s) apagado(s) com sucesso.",
            "Financeiro Master Pro",
            MessageBoxButton.OK,
            MessageBoxImage.Information);

        CarregarLancamentos();
        Novo();
    }

    public void AplicarPesquisaDfc(string pesquisa, DateTime? inicio = null, DateTime? fim = null)
    {
        _dfcDataInicial = inicio;
        _dfcDataFinal = fim;
        TxtPesquisar.Text = pesquisa ?? string.Empty;
        AplicarFiltros();
        TxtPesquisar.Focus();
        TxtPesquisar.SelectAll();
    }

    // =========================================================
    // CAIXA DE ENTRADA
    // =========================================================
    private string Perguntar(
        string titulo,
        string mensagem)
    {
        var janela =
            new Window
            {
                Title = titulo,
                Width = 470,
                Height = 250,
                ResizeMode = ResizeMode.NoResize,
                WindowStartupLocation =
                    WindowStartupLocation.CenterOwner,
                Owner = Window.GetWindow(this)
            };

        var painel =
            new StackPanel
            {
                Margin = new Thickness(20)
            };

        painel.Children.Add(
            new TextBlock
            {
                Text = mensagem,
                TextWrapping = TextWrapping.Wrap,
                FontSize = 14,
                Margin = new Thickness(0, 0, 0, 15)
            });

        var caixa =
            new TextBox
            {
                Height = 32,
                FontSize = 14,
                Padding = new Thickness(6, 3, 6, 3)
            };

        painel.Children.Add(caixa);

        var botoes =
            new StackPanel
            {
                Orientation = Orientation.Horizontal,
                HorizontalAlignment = HorizontalAlignment.Right,
                Margin = new Thickness(0, 15, 0, 0)
            };

        var confirmar =
            new Button
            {
                Content = "OK",
                Width = 85,
                Height = 32,
                IsDefault = true,
                Margin = new Thickness(0, 0, 8, 0)
            };

        var cancelar =
            new Button
            {
                Content = "CANCELAR",
                Width = 95,
                Height = 32,
                IsCancel = true
            };

        confirmar.Click += (_, _) =>
        {
            janela.DialogResult = true;
        };

        botoes.Children.Add(confirmar);
        botoes.Children.Add(cancelar);

        painel.Children.Add(botoes);

        janela.Content = painel;

        janela.Loaded += (_, _) =>
        {
            caixa.Focus();
        };

        bool? resultado = janela.ShowDialog();

        return resultado == true
            ? caixa.Text.Trim()
            : "";
    }

    // =========================================================
    // BAIXA NA GRADE
    // =========================================================
    private void BaixaGrade_Click(
        object sender,
        RoutedEventArgs e)
    {
        if (_alterandoBaixaGrade)
            return;

        if (sender is not CheckBox checkBox ||
            checkBox.DataContext is not Lancamento item)
            return;

        try
        {
            _alterandoBaixaGrade = true;

            bool baixar =
                checkBox.IsChecked == true;

            DateTime? dataBaixa =
                baixar
                    ? item.DataPagamento ?? DateTime.Today
                    : null;

            _repository.AlterarBaixa(
                item.Id,
                baixar,
                dataBaixa);

            item.Baixado = baixar;
            item.DataBaixa = dataBaixa;

            item.Periodo =
                baixar && dataBaixa.HasValue
                    ? dataBaixa.Value.ToString("MM/yyyy")
                    : "";

            if (_idAtual == item.Id)
                Periodo.Text = item.Periodo;

            GridLancamentos.Items.Refresh();

            // O saldo das contas considera somente lançamentos baixados.
            // Recalcula imediatamente ao baixar ou desbaixar um lançamento.
            CarregarSaldosContas();
        }
        catch (Exception ex)
        {
            checkBox.IsChecked =
                !checkBox.IsChecked;

            MessageBox.Show(
                "Não foi possível alterar a baixa.\n\n" +
                ex.Message);
        }
        finally
        {
            _alterandoBaixaGrade = false;
        }
    }

    // =========================================================
    // SELEÇÃO DA GRADE
    // =========================================================
    private void GridLancamentos_SelectionChanged(
        object sender,
        SelectionChangedEventArgs e)
    {
        if (GridLancamentos.SelectedItem
            is not Lancamento item)
            return;

        _idAtual = item.Id;
        _modoAlteracao = false;

        SelecionarTipo(item.Baixado
            ? (item.Tipo.Equals("Pagar", StringComparison.OrdinalIgnoreCase) ? "Pago" :
               item.Tipo.Equals("Receber", StringComparison.OrdinalIgnoreCase) ? "Recebido" : item.Tipo)
            : item.Tipo);
        SelecionarPorId(Conta, item.ContaBancariaId);

        DataPagto.SelectedDate = item.DataPagamento;
        DataEmissao.SelectedDate = item.DataEmissao;

        SelecionarPorId(
            Cliente,
            item.ClienteFornecedorId);

        Descricao.Text = item.Descricao;
        NumeroDocumento.Text = item.NumeroDocumento;

        SelecionarPorId(
            PlanoContas,
            item.PlanoContasId);

        SelecionarPorId(
            CentroCustos,
            item.CentroCustosId);

        SelecionarPorId(
            GrupoContas,
            item.GrupoContasId);

        SelecionarPorId(
            FluxoCaixa,
            item.FluxoCaixaId);

        // No painel normal de lançamentos o usuário sempre vê/digita o valor sem sinal.
        // O sentido financeiro é determinado pelo TIPO; o valor assinado continua interno.
        Valor.Text =
            Math.Abs(item.Valor).ToString(
                "N2",
                _culturaBrasil);

        Periodo.Text = item.Periodo;
        Anotacoes.Text = item.Anotacoes;

        DefinirEdicao(false);

        BtnAlterar.IsEnabled = true;
        BtnExcluir.IsEnabled = true;
        BtnParcelar.IsEnabled = true;
        BtnRatear.IsEnabled = true;
    }

    private void GridLancamentos_MouseDoubleClick(object sender, MouseButtonEventArgs e)
    {
        if (GridLancamentos.SelectedItem is not Lancamento) return;
        Alterar_Click(sender, new RoutedEventArgs());
    }

    private static void SelecionarPorId(
        ComboBox combo,
        long? id)
    {
        if (!id.HasValue)
        {
            combo.SelectedItem = null;
            return;
        }

        foreach (var objeto in combo.Items)
        {
            long? idItem =
                objeto switch
                {
                    ContaBancaria x => x.Id,
                    ClienteFornecedor x => x.Id,
                    PlanoContas x => x.Id,
                    CentroCustos x => x.Id,
                    GrupoContas x => x.Id,
                    FluxoCaixa x => x.Id,
                    _ => null
                };

            if (idItem == id.Value)
            {
                combo.SelectedItem = objeto;
                return;
            }
        }

        combo.SelectedItem = null;
    }

    // =========================================================
    // PARCELAR
    // =========================================================

    private static DateTime PascoaFinanceiro(int ano){int a=ano%19,b=ano/100,c=ano%100,d=b/4,e=b%4,f=(b+8)/25,g=(b-f+1)/3,h=(19*a+b-d-g+15)%30,i=c/4,k=c%4,l=(32+2*e+2*i-h-k)%7,m=(a+11*h+22*l)/451;return new DateTime(ano,(h+l-7*m+114)/31,((h+l-7*m+114)%31)+1);}
    private static bool FeriadoFinanceiro(DateTime d){var fixos=new[]{(1,1),(4,21),(5,1),(9,7),(10,12),(11,2),(11,15),(11,20),(12,25)};if(fixos.Any(x=>x.Item1==d.Month&&x.Item2==d.Day))return true;var p=PascoaFinanceiro(d.Year);return d.Date==p.AddDays(-48).Date||d.Date==p.AddDays(-47).Date||d.Date==p.AddDays(-2).Date||d.Date==p.AddDays(60).Date;}
    private static DateTime ProximoDiaUtilFinanceiro(DateTime d){while(d.DayOfWeek==DayOfWeek.Saturday||d.DayOfWeek==DayOfWeek.Sunday||FeriadoFinanceiro(d))d=d.AddDays(1);return d;}

    private static DateTime CalcularPrimeiroVencimentoCartao(DateTime compra, ContaBancaria cartao)
    {
        int fechamento=Math.Clamp(cartao.DiaFechamento??compra.Day,1,31), vencimento=Math.Clamp(cartao.DiaVencimento??compra.Day,1,31);
        var mes=new DateTime(compra.Year,compra.Month,1);
        if(compra.Day>Math.Min(fechamento,DateTime.DaysInMonth(compra.Year,compra.Month))) mes=mes.AddMonths(1);
        return ProximoDiaUtilFinanceiro(new DateTime(mes.Year,mes.Month,Math.Min(vencimento,DateTime.DaysInMonth(mes.Year,mes.Month))));
    }

    private void Parcelar_Click(object sender,RoutedEventArgs e)
    {
        try{
            bool existente=_idAtual!=0; decimal valorTotal; Lancamento lancamentoBase;
            if(existente){var atual=_lancamentos.FirstOrDefault(x=>x.Id==_idAtual);if(atual==null){MessageBox.Show("Lançamento não localizado.");return;}valorTotal=atual.Valor;lancamentoBase=atual;}
            else{if(!ValidarDadosTela(out valorTotal))return;lancamentoBase=MontarLancamento(valorTotal);}
            DateTime dataBase=lancamentoBase.DataPagamento??DateTime.Today; DateTime? vencCartao=null; string? nomeCartao=null;
            var conta=_contaRepository.Listar().FirstOrDefault(x=>x.Id==lancamentoBase.ContaBancariaId);
            if(conta!=null&&conta.TipoConta.Contains("Cart",StringComparison.OrdinalIgnoreCase)&&conta.DiaFechamento.HasValue&&conta.DiaVencimento.HasValue){vencCartao=CalcularPrimeiroVencimentoCartao(dataBase,conta);nomeCartao=conta.Nome;}
            var janela=new ParcelamentoWindow(valorTotal,dataBase,vencCartao,nomeCartao){Owner=Window.GetWindow(this)};
            if(janela.ShowDialog()!=true)return;
            if(MessageBox.Show($"Gerar {janela.QuantidadeParcelas} parcelas totalizando {valorTotal.ToString("C2",_culturaBrasil)}?","Confirmar Parcelamento",MessageBoxButton.YesNo,MessageBoxImage.Question)!=MessageBoxResult.Yes)return;
            _parcelamentoRepository.Gerar(lancamentoBase,janela.QuantidadeParcelas,janela.PrimeiraData,janela.IntervaloDias);
            if(existente)_repository.Excluir(_idAtual);
            MessageBox.Show("Parcelamento gerado com sucesso.");CarregarLancamentos();Novo();
        }catch(Exception ex){MessageBox.Show("Não foi possível gerar o parcelamento.\n\n"+ex.Message);}
    }

    // =========================================================
    // RATEAR
    // =========================================================
    private void Ratear_Click(
        object sender,
        RoutedEventArgs e)
    {
        try
        {
            Lancamento? lancamento;

            // NOVO LANÇAMENTO: salva automaticamente antes de abrir o rateio.
            if (_idAtual == 0)
            {
                if (!ValidarDadosTela(out decimal valorNovo))
                    return;

                var novo = MontarLancamento(valorNovo);
                _repository.Salvar(novo);

                _lancamentos = _repository.Listar();
                lancamento = _lancamentos
                    .OrderByDescending(x => x.Id)
                    .FirstOrDefault();

                if (lancamento == null)
                    throw new InvalidOperationException(
                        "O lançamento foi salvo, mas não pôde ser localizado para o rateio.");

                _idAtual = lancamento.Id;
            }
            else
            {
                lancamento = _lancamentos.FirstOrDefault(x => x.Id == _idAtual);
            }

            if (lancamento == null)
                return;

            var centros = _centroRepository.Listar().Where(x => x.Ativo).ToList();
            var planos = _planoRepository.Listar().Where(x => x.Ativo).ToList();
            if (planos.Count < 2)
            {
                MessageBox.Show("Cadastre pelo menos 2 Planos de Contas ativos.","Financeiro Master Pro",MessageBoxButton.OK,MessageBoxImage.Information);
                return;
            }

            var existentes = _rateioRepository.ListarPorLancamento(lancamento.Id);

            var janela = new RateioWindow(
                lancamento.Valor,
                planos,
                centros,
                lancamento.CentroCustosId,
                lancamento.CentroCustosNome,
                existentes)
            {
                Owner = Window.GetWindow(this)
            };

            if (janela.ShowDialog() != true)
            {
                CarregarLancamentos();
                return;
            }

            _rateioRepository.Salvar(
                lancamento.Id,
                lancamento.Valor,
                janela.Itens);

            MessageBox.Show(
                "Rateio salvo com sucesso. Diferença final: 0,00.\n\nO lançamento original permanece na grade identificado como RATEADO. Para consultar ou alterar o rateio, selecione esse lançamento e clique em RATEAR.",
                "Financeiro Master Pro",
                MessageBoxButton.OK,
                MessageBoxImage.Information);

            CarregarLancamentos();
            Novo();
        }
        catch (Exception ex)
        {
            MessageBox.Show(
                "Não foi possível salvar o rateio.\n\n" + ex.Message,
                "Financeiro Master Pro",
                MessageBoxButton.OK,
                MessageBoxImage.Error);
        }
    }

    // =========================================================
    // FILTROS
    // =========================================================
    private void Pesquisar_TextChanged(
        object sender,
        TextChangedEventArgs e)
    {
        AplicarFiltros();
    }

    private void LimparPesquisa_Click(object sender, RoutedEventArgs e)
    {
        if (TxtPesquisar == null)
            return;

        TxtPesquisar.Clear();
        TxtPesquisar.Focus();
        AplicarFiltros();
    }

    private void Filtros_Changed(
        object sender,
        SelectionChangedEventArgs e)
    {
        AplicarFiltros();
    }

    private sealed class PreferenciasFiltrosLancamentos
    {
        public string[] Tipos { get; set; } = Array.Empty<string>();
        public string[] Status { get; set; } = Array.Empty<string>();
    }

    private void CarregarStatusPreferido()
    {
        try
        {
            if (File.Exists(ArquivoPreferenciaStatus))
            {
                var pref = System.Text.Json.JsonSerializer.Deserialize<PreferenciasFiltrosLancamentos>(File.ReadAllText(ArquivoPreferenciaStatus));
                if (pref != null)
                {
                    _tiposFiltroSelecionados.Clear();
                    foreach (var x in pref.Tipos ?? Array.Empty<string>()) _tiposFiltroSelecionados.Add(x);
                    _statusFiltroSelecionados.Clear();
                    foreach (var x in pref.Status ?? Array.Empty<string>()) _statusFiltroSelecionados.Add(x);
                }
            }
        }
        catch { }
        finally
        {
            _carregandoPreferenciaStatus = false;
            AtualizarTextoFiltrosMultiplos();
        }
    }

    private void SalvarStatusPreferido()
    {
        if (_carregandoPreferenciaStatus) return;
        try
        {
            Directory.CreateDirectory(Path.GetDirectoryName(ArquivoPreferenciaStatus)!);
            var pref = new PreferenciasFiltrosLancamentos
            {
                Tipos = _tiposFiltroSelecionados.OrderBy(x => x).ToArray(),
                Status = _statusFiltroSelecionados.OrderBy(x => x).ToArray()
            };
            File.WriteAllText(ArquivoPreferenciaStatus, System.Text.Json.JsonSerializer.Serialize(pref));
        }
        catch { }
    }

    private void AtualizarTextoFiltrosMultiplos()
    {
        if (FiltroTipo != null) FiltroTipo.Content = _tiposFiltroSelecionados.Count == 5 ? "Todos ▼" : (_tiposFiltroSelecionados.Count == 0 ? "Nenhum ▼" : $"{_tiposFiltroSelecionados.Count} selecionado(s) ▼");
        if (FiltroStatus != null) FiltroStatus.Content = _statusFiltroSelecionados.Count == 2 ? "Todos ▼" : (_statusFiltroSelecionados.Count == 0 ? "Nenhum ▼" : $"{_statusFiltroSelecionados.Count} selecionado(s) ▼");
    }

    private void FiltroTipo_Click(object sender, RoutedEventArgs e)
        => AbrirSeletorMultiplo("Selecionar Tipo", new[] { "Pagar", "Receber", "Pago", "Recebido", "Transferência" }, _tiposFiltroSelecionados);

    private void FiltroStatus_Click(object sender, RoutedEventArgs e)
        => AbrirSeletorMultiplo("Selecionar Status", new[] { "Aberto", "Fechado" }, _statusFiltroSelecionados);

    private void AbrirSeletorMultiplo(string titulo, string[] opcoes, HashSet<string> selecionados)
    {
        var win = new Window { Title = titulo, Width = 390, Height = Math.Max(260, 190 + opcoes.Length * 40), WindowStartupLocation = WindowStartupLocation.CenterOwner, Owner = Window.GetWindow(this), ResizeMode = ResizeMode.NoResize };
        var root = new DockPanel { Margin = new Thickness(18) };
        var rodape = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right, Margin = new Thickness(0, 12, 0, 0) };
        DockPanel.SetDock(rodape, Dock.Bottom);
        var ok = new Button { Content = "OK", Width = 70, Height = 38 };
        var cancelar = new Button { Content = "CANCELAR", Width = 108, Height = 38, Margin = new Thickness(14, 0, 0, 0) };
        rodape.Children.Add(ok); rodape.Children.Add(cancelar); root.Children.Add(rodape);
        var corpo = new StackPanel(); root.Children.Add(corpo);
        var todos = new CheckBox { Content = "Todos", FontWeight = FontWeights.SemiBold, VerticalContentAlignment = VerticalAlignment.Center, Margin = new Thickness(2, 2, 2, 10) };
        corpo.Children.Add(todos);
        var checks = new List<(string Nome, CheckBox Cb)>();
        foreach (var nome in opcoes)
        {
            var cb = new CheckBox { Content = nome, IsChecked = selecionados.Contains(nome), VerticalContentAlignment = VerticalAlignment.Center, Height = 32, Margin = new Thickness(2, 0, 2, 0) };
            checks.Add((nome, cb)); corpo.Children.Add(cb);
        }
        bool ajustando = false;
        void Sync() { if (ajustando) return; ajustando = true; todos.IsChecked = checks.All(x => x.Cb.IsChecked == true); ajustando = false; }
        foreach (var x in checks) { x.Cb.Checked += (_, __) => Sync(); x.Cb.Unchecked += (_, __) => Sync(); }
        todos.Checked += (_, __) => { if (ajustando) return; ajustando = true; foreach (var x in checks) x.Cb.IsChecked = true; ajustando = false; };
        todos.Unchecked += (_, __) => { if (ajustando) return; ajustando = true; foreach (var x in checks) x.Cb.IsChecked = false; ajustando = false; };
        Sync();
        ok.Click += (_, __) => { selecionados.Clear(); foreach (var x in checks.Where(x => x.Cb.IsChecked == true)) selecionados.Add(x.Nome); AtualizarTextoFiltrosMultiplos(); SalvarStatusPreferido(); win.DialogResult = true; };
        cancelar.Click += (_, __) => win.DialogResult = false;
        win.Content = root;
        if (win.ShowDialog() == true) AplicarFiltros();
    }

    private void AplicarFiltros()
    {
        if (GridLancamentos == null ||
            TxtPesquisar == null ||
            FiltroTipo == null ||
            FiltroStatus == null)
            return;

        IEnumerable<Lancamento> resultado =
            _lancamentos;

        if (_contaFiltroId.HasValue)
        {
            // A conta selecionada deve mostrar TODOS os seus lançamentos,
            // inclusive os já pagos/recebidos. O status é controlado pelos filtros
            // TIPO/STATUS, e não pelo filtro da conta.
            resultado = resultado.Where(x => x.ContaBancariaId == _contaFiltroId.Value);
        }

        if (_dfcDataInicial.HasValue)
            resultado = resultado.Where(x => x.DataPagamento.HasValue && x.DataPagamento.Value.Date >= _dfcDataInicial.Value.Date);

        if (_dfcDataFinal.HasValue)
            resultado = resultado.Where(x => x.DataPagamento.HasValue && x.DataPagamento.Value.Date <= _dfcDataFinal.Value.Date);

        string pesquisa =
            TxtPesquisar.Text?.Trim() ?? "";

        if (!string.IsNullOrWhiteSpace(pesquisa))
        {
            resultado =
                resultado.Where(x =>
                    Contem(x.Descricao, pesquisa) ||
                    Contem(x.NumeroDocumento, pesquisa) ||
                    Contem(x.ClienteFornecedorNome, pesquisa) ||
                    Contem(x.ContaBancariaNome, pesquisa) ||
                    Contem(x.PlanoContasNome, pesquisa) ||
                    Contem(x.CentroCustosNome, pesquisa) ||
                    Contem(x.GrupoContasNome, pesquisa) ||
                    Contem(x.FluxoCaixaNome, pesquisa) ||
                    Contem(x.Periodo, pesquisa) ||
                    Contem(x.Anotacoes, pesquisa) ||
                    Contem(x.Tipo, pesquisa) ||
                    Contem(x.Id.ToString(), pesquisa) ||
                    PesquisaAvancada.Valor(x.Valor, pesquisa) ||
                    PesquisaAvancada.Valor(x.Tipo.Equals("Pagar", StringComparison.OrdinalIgnoreCase) ? -Math.Abs(x.Valor) : Math.Abs(x.Valor), pesquisa) ||
                    Contem(x.DataPagamento?.ToString("dd/MM/yyyy"), pesquisa) ||
                    Contem(x.DataEmissao.ToString("dd/MM/yyyy"), pesquisa) ||
                    Contem(x.Baixado ? "Baixado" : "Aberto", pesquisa));
        }

        if (_tiposFiltroSelecionados.Count < 5)
        {
            resultado = resultado.Where(x =>
                (_tiposFiltroSelecionados.Contains("Pagar") && x.Tipo.Equals("Pagar", StringComparison.OrdinalIgnoreCase) && !x.Baixado) ||
                (_tiposFiltroSelecionados.Contains("Receber") && x.Tipo.Equals("Receber", StringComparison.OrdinalIgnoreCase) && !x.Baixado) ||
                (_tiposFiltroSelecionados.Contains("Pago") && x.Tipo.Equals("Pagar", StringComparison.OrdinalIgnoreCase) && x.Baixado) ||
                (_tiposFiltroSelecionados.Contains("Recebido") && x.Tipo.Equals("Receber", StringComparison.OrdinalIgnoreCase) && x.Baixado) ||
                (_tiposFiltroSelecionados.Contains("Transferência") && (x.Tipo.Equals("Transferência", StringComparison.OrdinalIgnoreCase) || x.Tipo.Equals("Transferencia", StringComparison.OrdinalIgnoreCase))));
        }

        if (_statusFiltroSelecionados.Count < 2)
        {
            resultado = resultado.Where(x =>
                (_statusFiltroSelecionados.Contains("Aberto") && !x.Baixado) ||
                (_statusFiltroSelecionados.Contains("Fechado") && x.Baixado));
        }

        var listaFiltrada = resultado.ToList();
        GridLancamentos.ItemsSource = listaFiltrada;
        AtualizarResumoGrade(listaFiltrada);
        CarregarOrdenacaoGrade();
    }

    private void AtualizarResumoGrade(IEnumerable<Lancamento> lancamentos)
    {
        var lista = lancamentos.Where(x => x.Ativo).ToList();
        decimal aPagar = lista.Where(x => x.Tipo.Equals("Pagar", StringComparison.OrdinalIgnoreCase) && !x.Baixado).Sum(x => Math.Abs(x.Valor));
        decimal aReceber = lista.Where(x => x.Tipo.Equals("Receber", StringComparison.OrdinalIgnoreCase) && !x.Baixado).Sum(x => Math.Abs(x.Valor));
        decimal pago = lista.Where(x => x.Tipo.Equals("Pagar", StringComparison.OrdinalIgnoreCase) && x.Baixado).Sum(x => Math.Abs(x.Valor));
        decimal recebido = lista.Where(x => x.Tipo.Equals("Receber", StringComparison.OrdinalIgnoreCase) && x.Baixado).Sum(x => Math.Abs(x.Valor));

        if (ResumoAPagar != null) ResumoAPagar.Text = aPagar.ToString("N2", _culturaBrasil);
        if (ResumoAReceber != null) ResumoAReceber.Text = aReceber.ToString("N2", _culturaBrasil);
        if (ResumoPago != null) ResumoPago.Text = pago.ToString("N2", _culturaBrasil);
        if (ResumoRecebido != null) ResumoRecebido.Text = recebido.ToString("N2", _culturaBrasil);
    }

    private static bool Contem(
        string? texto,
        string pesquisa)
    {
        return
            !string.IsNullOrWhiteSpace(texto) &&
            texto.Contains(
                pesquisa,
                StringComparison.CurrentCultureIgnoreCase);
    }

    private static string ObterConteudoCombo(
        ComboBox combo)
    {
        return combo.SelectedItem is ComboBoxItem item
            ? item.Content?.ToString() ?? ""
            : "";
    }

    // =========================================================
    // LUPAS
    // =========================================================
    private void ContaBancariaLupa_Click(
        object sender,
        RoutedEventArgs e)
    {
        AbrirCadastro(new ContaBancariaView());
        CarregarCadastros();
        CarregarLancamentos();
    }

    private void ClienteFornecedorLupa_Click(
        object sender,
        RoutedEventArgs e)
    {
        AbrirCadastro(new ClienteFornecedorView());
        CarregarCadastros();
        CarregarLancamentos();
    }

    private void PlanoContasLupa_Click(
        object sender,
        RoutedEventArgs e)
    {
        AbrirCadastro(new PlanoContasView());
        CarregarCadastros();
        CarregarLancamentos();
    }

    private void CentroCustosLupa_Click(
        object sender,
        RoutedEventArgs e)
    {
        AbrirCadastro(new CentroCustosView());
        CarregarCadastros();
        CarregarLancamentos();
    }

    private void GrupoContasLupa_Click(
        object sender,
        RoutedEventArgs e)
    {
        AbrirCadastro(new GrupoContasView());
        CarregarCadastros();
        CarregarLancamentos();
    }

    private void FluxoCaixaLupa_Click(
        object sender,
        RoutedEventArgs e)
    {
        AbrirCadastro(new FluxoCaixaView());
        CarregarCadastros();
        CarregarLancamentos();
    }


    private void ContaBancariaAlterar_Click(object sender, RoutedEventArgs e)
    {
        AbrirCadastro(new ContaBancariaView());
        CarregarCadastros();
        CarregarLancamentos();
        CarregarLancamentos();
    }

    private void ClienteFornecedorAlterar_Click(object sender, RoutedEventArgs e)
    {
        AbrirCadastro(new ClienteFornecedorView());
        CarregarCadastros();
        CarregarLancamentos();
        CarregarLancamentos();
    }

    private void PlanoContasAlterar_Click(object sender, RoutedEventArgs e)
    {
        AbrirCadastro(new PlanoContasView());
        CarregarCadastros();
        CarregarLancamentos();
        CarregarLancamentos();
    }

    private void CentroCustosAlterar_Click(object sender, RoutedEventArgs e)
    {
        AbrirCadastro(new CentroCustosView());
        CarregarCadastros();
        CarregarLancamentos();
        CarregarLancamentos();
    }

    private void GrupoContasAlterar_Click(object sender, RoutedEventArgs e)
    {
        AbrirCadastro(new GrupoContasView());
        CarregarCadastros();
        CarregarLancamentos();
        CarregarLancamentos();
    }

    private void FluxoCaixaAlterar_Click(object sender, RoutedEventArgs e)
    {
        AbrirCadastro(new FluxoCaixaView());
        CarregarCadastros();
        CarregarLancamentos();
        CarregarLancamentos();
    }

    private bool ConfirmarExclusaoCadastro(string nome)
    {
        return MessageBox.Show(
            $"Deseja excluir/inativar o cadastro \"{nome}\"?\n\nOs lançamentos existentes serão preservados.",
            "Financeiro Master Pro",
            MessageBoxButton.YesNo,
            MessageBoxImage.Question) == MessageBoxResult.Yes;
    }

    private void ContaBancariaExcluir_Click(object sender, RoutedEventArgs e)
    {
        if (Conta.SelectedItem is not FinanceiroMasterPro.Infrastructure.Data.ContaBancaria item) return;
        if (!ConfirmarExclusaoCadastro(item.Nome)) return;
        _contaRepository.AlterarStatus(item.Id, false);
        CarregarCadastros(); CarregarLancamentos();
    }

    private void ClienteFornecedorExcluir_Click(object sender, RoutedEventArgs e)
    {
        if (Cliente.SelectedItem is not FinanceiroMasterPro.Infrastructure.Data.ClienteFornecedor item) return;
        if (!ConfirmarExclusaoCadastro(item.Nome)) return;
        _clienteRepository.AlterarStatus(item.Id, false);
        CarregarCadastros(); CarregarLancamentos();
    }

    private void PlanoContasExcluir_Click(object sender, RoutedEventArgs e)
    {
        if (PlanoContas.SelectedItem is not FinanceiroMasterPro.Infrastructure.Data.PlanoContas item) return;
        if (!ConfirmarExclusaoCadastro(item.Nome)) return;
        _planoRepository.AlterarStatus(item.Id, false);
        CarregarCadastros(); CarregarLancamentos();
    }

    private void CentroCustosExcluir_Click(object sender, RoutedEventArgs e)
    {
        if (CentroCustos.SelectedItem is not FinanceiroMasterPro.Infrastructure.Data.CentroCustos item) return;
        if (!ConfirmarExclusaoCadastro(item.Nome)) return;
        _centroRepository.AlterarStatus(item.Id, false);
        CarregarCadastros(); CarregarLancamentos();
    }

    private void GrupoContasExcluir_Click(object sender, RoutedEventArgs e)
    {
        if (GrupoContas.SelectedItem is not FinanceiroMasterPro.Infrastructure.Data.GrupoContas item) return;
        if (!ConfirmarExclusaoCadastro(item.Nome)) return;
        _grupoRepository.AlterarStatus(item.Id, false);
        CarregarCadastros(); CarregarLancamentos();
    }

    private void FluxoCaixaExcluir_Click(object sender, RoutedEventArgs e)
    {
        if (FluxoCaixa.SelectedItem is not FinanceiroMasterPro.Infrastructure.Data.FluxoCaixa item) return;
        if (!ConfirmarExclusaoCadastro(item.Nome)) return;
        _fluxoRepository.AlterarStatus(item.Id, false);
        CarregarCadastros(); CarregarLancamentos();
    }

    private void AbrirCadastro(UserControl controle)
    {
        var janela =
            new Window
            {
                Title = "Financeiro Master Pro",
                Width = 1000,
                Height = 650,
                MinWidth = 850,
                MinHeight = 550,
                WindowStartupLocation =
                    WindowStartupLocation.CenterOwner,
                Owner = Window.GetWindow(this),
                Content = controle
            };

        janela.ShowDialog();
    }

    // =========================================================
    // CALCULADORA
    // =========================================================
    private void Calculadora_Click(
        object sender,
        RoutedEventArgs e)
    {
        decimal inicial = 0m;
        TentarLerValor(Valor.Text, out inicial);

        var janela = new CalculadoraWindow(inicial)
        {
            Owner = Window.GetWindow(this)
        };

        if (janela.ShowDialog() == true)
        {
            Valor.Text = janela.ValorResultado.ToString("N2", _culturaBrasil);
            Valor.Focus();
            Valor.SelectAll();
        }
    }
    public List<Lancamento> ObterLancamentosVisiveis()
    {
        return GridLancamentos?.ItemsSource?.Cast<Lancamento>().ToList() ?? new List<Lancamento>();
    }

    private void RelatorioLancamentos_Click(object sender, RoutedEventArgs e)
    {
        // O relatório é sempre uma cópia da visualização NORMAL da Grade.
        // Se a Grade estiver temporariamente isolada em um único lançamento,
        // remove somente esse isolamento antes de montar o relatório, preservando
        // STATUS, TIPO, período, conta, pesquisa e demais filtros escolhidos.
        if (_lancamentoExclusivoId.HasValue)
            AtualizarGradePreservandoFiltros();

        var itens = ObterLancamentosVisiveis();
        if (Window.GetWindow(this) is MainWindow main)
            main.PrepararRelatorioLancamentos(this, itens.Select(x => x.Id).ToList());
        var win = new RelatorioLancamentosWindow(itens) { Owner = Window.GetWindow(this) };
        win.ShowDialog();
    }

}
