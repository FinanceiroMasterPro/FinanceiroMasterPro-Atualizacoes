using FinanceiroMasterPro.Infrastructure.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Controls;

namespace FinanceiroMasterPro.Desktop.Views;

public partial class MovimentacoesView : UserControl
{
    private readonly LancamentoRepository _repository = new();
    private List<Lancamento> _lancamentos = new();

    public MovimentacoesView()
    {
        InitializeComponent();

        TxtPesquisar.TextChanged += Filtros_Changed;
        FiltroTipo.SelectionChanged += Filtros_Changed;
        FiltroStatus.SelectionChanged += Filtros_Changed;

        CarregarLancamentos();
    }

    private void CarregarLancamentos()
    {
        _lancamentos = _repository.Listar();
        AplicarFiltros();
    }

    private void Filtros_Changed(
        object sender,
        EventArgs e)
    {
        AplicarFiltros();
    }

    private void AplicarFiltros()
    {
        if (GridMovimentacoes == null)
            return;

        IEnumerable<Lancamento> resultado =
            _lancamentos;

        string pesquisa =
            TxtPesquisar?.Text?.Trim() ?? "";

        if (!string.IsNullOrWhiteSpace(pesquisa))
        {
            resultado = resultado.Where(x =>
                Contem(x.Descricao, pesquisa) ||
                Contem(x.ClienteFornecedorNome, pesquisa) ||
                Contem(x.ContaBancariaNome, pesquisa) ||
                Contem(x.PlanoContasNome, pesquisa) ||
                Contem(x.CentroCustosNome, pesquisa) ||
                Contem(x.GrupoContasNome, pesquisa) ||
                Contem(x.FluxoCaixaNome, pesquisa) ||
                Contem(x.Periodo, pesquisa) ||
                Contem(x.Anotacoes, pesquisa) ||
                PesquisaAvancada.Valor(x.Valor,pesquisa) ||
                PesquisaAvancada.Data(x.DataPagamento,pesquisa) ||
                PesquisaAvancada.Data(x.DataEmissao,pesquisa));
        }

        string tipo =
            ObterCombo(FiltroTipo);

        if (!string.IsNullOrWhiteSpace(tipo) &&
            tipo != "Todos")
        {
            resultado = resultado.Where(x =>
                string.Equals(
                    x.Tipo,
                    tipo,
                    StringComparison.OrdinalIgnoreCase));
        }

        string status =
            ObterCombo(FiltroStatus);

        if (status == "Aberto")
            resultado = resultado.Where(x => !x.Baixado);

        if (status == "Baixado")
            resultado = resultado.Where(x => x.Baixado);

        GridMovimentacoes.ItemsSource =
            resultado.ToList();
    }

    private static bool Contem(
        string? texto,
        string pesquisa)
    {
        return
            !string.IsNullOrWhiteSpace(texto) &&
            texto.Contains(
                pesquisa,
                StringComparison.CurrentCultureIgnoreCase);
    }

    private static string ObterCombo(
        ComboBox combo)
    {
        if (combo.SelectedItem is ComboBoxItem item)
            return item.Content?.ToString() ?? "";

        return "";
    }
}