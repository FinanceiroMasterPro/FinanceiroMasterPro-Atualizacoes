using System.Windows;
using System.Windows.Controls;

namespace FinanceiroMasterPro.Desktop.Views;

public sealed class EdicaoLoteWindow : Window
{
    private readonly TextBox _localizar = new() { MinWidth = 360, Margin = new Thickness(0,4,0,12) };
    private readonly TextBox _substituir = new() { MinWidth = 360, Margin = new Thickness(0,4,0,16) };
    public string Localizar => _localizar.Text;
    public string Substituir => _substituir.Text;

    public EdicaoLoteWindow(int quantidade)
    {
        Title = "Alterar em lote"; Width = 440; Height = 260; ResizeMode = ResizeMode.NoResize;
        WindowStartupLocation = WindowStartupLocation.CenterOwner;
        var p = new StackPanel { Margin = new Thickness(22) };
        p.Children.Add(new TextBlock { Text = $"{quantidade} cadastro(s) selecionado(s)", FontWeight = FontWeights.SemiBold, Margin = new Thickness(0,0,0,12) });
        p.Children.Add(new TextBlock { Text = "Localizar no nome:" }); p.Children.Add(_localizar);
        p.Children.Add(new TextBlock { Text = "Substituir por (pode ficar vazio):" }); p.Children.Add(_substituir);
        var b = new Button { Content = "APLICAR EM LOTE", Width = 150, Height = 34, HorizontalAlignment = HorizontalAlignment.Right };
        b.Click += (_,__) => { if (string.IsNullOrEmpty(Localizar)) { MessageBox.Show("Informe o texto que deseja localizar."); return; } DialogResult = true; };
        p.Children.Add(b); Content = p;
    }
}
