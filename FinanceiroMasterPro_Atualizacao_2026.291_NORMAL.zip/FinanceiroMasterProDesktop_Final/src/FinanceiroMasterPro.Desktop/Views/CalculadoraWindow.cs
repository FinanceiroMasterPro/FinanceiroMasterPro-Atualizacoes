using System;
using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace FinanceiroMasterPro.Desktop.Views;

public sealed class CalculadoraWindow : Window
{
    private readonly CultureInfo _pt = new("pt-BR");
    private readonly TextBox _visor;
    private decimal _acumulado;
    private string _operacao = "";
    private bool _novoNumero = true;

    public decimal ValorResultado { get; private set; }

    public CalculadoraWindow(decimal valorInicial = 0m)
    {
        Title = "Calculadora - Financeiro Master Pro";
        Width = 360;
        Height = 520;
        ResizeMode = ResizeMode.NoResize;
        WindowStartupLocation = WindowStartupLocation.CenterOwner;

        var raiz = new Grid { Margin = new Thickness(14) };
        for (int i = 0; i < 7; i++) raiz.RowDefinitions.Add(new RowDefinition { Height = i == 0 ? new GridLength(76) : new GridLength(1, GridUnitType.Star) });
        for (int i = 0; i < 4; i++) raiz.ColumnDefinitions.Add(new ColumnDefinition());

        _visor = new TextBox
        {
            Text = valorInicial.ToString("N2", _pt),
            FontSize = 28,
            FontWeight = FontWeights.SemiBold,
            HorizontalContentAlignment = HorizontalAlignment.Right,
            VerticalContentAlignment = VerticalAlignment.Center,
            IsReadOnly = true,
            Padding = new Thickness(8)
        };
        Grid.SetColumnSpan(_visor, 4);
        raiz.Children.Add(_visor);

        Add(raiz, "C", 1, 0, (_, _) => Limpar());
        Add(raiz, "⌫", 1, 1, (_, _) => Apagar());
        Add(raiz, "+/-", 1, 2, (_, _) => TrocarSinal());
        Add(raiz, "÷", 1, 3, (_, _) => Operar("÷"));
        Add(raiz, "7", 2, 0, Numero); Add(raiz, "8", 2, 1, Numero); Add(raiz, "9", 2, 2, Numero); Add(raiz, "×", 2, 3, (_, _) => Operar("×"));
        Add(raiz, "4", 3, 0, Numero); Add(raiz, "5", 3, 1, Numero); Add(raiz, "6", 3, 2, Numero); Add(raiz, "-", 3, 3, (_, _) => Operar("-"));
        Add(raiz, "1", 4, 0, Numero); Add(raiz, "2", 4, 1, Numero); Add(raiz, "3", 4, 2, Numero); Add(raiz, "+", 4, 3, (_, _) => Operar("+"));
        Add(raiz, "0", 5, 0, Numero); Add(raiz, ",", 5, 1, Numero); Add(raiz, "=", 5, 2, (_, _) => Igual(), 2);

        var usar = new Button { Content = "USAR VALOR", FontSize = 16, FontWeight = FontWeights.Bold, Margin = new Thickness(3), IsDefault = true };
        usar.Click += (_, _) => UsarValor();
        Grid.SetRow(usar, 6); Grid.SetColumnSpan(usar, 4); raiz.Children.Add(usar);

        Content = raiz;
        PreviewKeyDown += Tecla;
    }

    private static void Add(Grid g, string texto, int linha, int coluna, RoutedEventHandler click, int span = 1)
    {
        var b = new Button { Content = texto, FontSize = 19, FontWeight = FontWeights.SemiBold, Margin = new Thickness(3) };
        b.Click += click; Grid.SetRow(b, linha); Grid.SetColumn(b, coluna); Grid.SetColumnSpan(b, span); g.Children.Add(b);
    }

    private decimal Atual()
    {
        decimal.TryParse(_visor.Text, NumberStyles.Number, _pt, out var v);
        return v;
    }

    private void Numero(object sender, RoutedEventArgs e)
    {
        string t = ((Button)sender).Content?.ToString() ?? "";
        if (_novoNumero) { _visor.Text = t == "," ? "0," : t; _novoNumero = false; return; }
        if (t == "," && _visor.Text.Contains(',')) return;
        if (_visor.Text == "0" && t != ",") _visor.Text = t; else _visor.Text += t;
    }

    private void Operar(string op)
    {
        if (!_novoNumero && !string.IsNullOrEmpty(_operacao)) Calcular(); else _acumulado = Atual();
        _operacao = op; _novoNumero = true;
    }

    private void Igual() { if (!string.IsNullOrEmpty(_operacao)) Calcular(); _operacao = ""; _novoNumero = true; }

    private void Calcular()
    {
        decimal b = Atual();
        _acumulado = _operacao switch
        {
            "+" => _acumulado + b,
            "-" => _acumulado - b,
            "×" => _acumulado * b,
            "÷" when b != 0 => _acumulado / b,
            "÷" => throw new DivideByZeroException("Não é possível dividir por zero."),
            _ => b
        };
        _visor.Text = _acumulado.ToString("0.############################", _pt);
        _novoNumero = true;
    }

    private void Limpar() { _visor.Text = "0"; _acumulado = 0; _operacao = ""; _novoNumero = true; }
    private void TrocarSinal() { _visor.Text = (-Atual()).ToString("0.############################", _pt); }
    private void Apagar() { if (_novoNumero) return; var s = _visor.Text; _visor.Text = s.Length <= 1 ? "0" : s[..^1]; }

    private void UsarValor()
    {
        try { if (!string.IsNullOrEmpty(_operacao) && !_novoNumero) Igual(); ValorResultado = decimal.Round(Atual(), 2, MidpointRounding.AwayFromZero); Clipboard.SetText(ValorResultado.ToString("N2", _pt)); DialogResult = true; }
        catch (Exception ex) { MessageBox.Show(ex.Message, "Calculadora", MessageBoxButton.OK, MessageBoxImage.Warning); }
    }

    private void Tecla(object sender, KeyEventArgs e)
    {
        if (e.Key == Key.Escape) { DialogResult = false; return; }
        if (e.Key == Key.Enter) { UsarValor(); e.Handled = true; }
    }
}
