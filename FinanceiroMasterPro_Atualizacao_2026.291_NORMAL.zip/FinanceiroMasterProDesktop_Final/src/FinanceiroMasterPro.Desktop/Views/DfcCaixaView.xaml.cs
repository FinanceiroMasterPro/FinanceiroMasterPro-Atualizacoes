using FinanceiroMasterPro.Infrastructure.Data;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Windows.Input;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Media;

namespace FinanceiroMasterPro.Desktop.Views;

public partial class DfcCaixaView : UserControl
{
    private readonly LancamentoRepository _repo = new();
    private List<Lancamento> _lancamentos = new();
    // Cache do histórico: evita reler mais de 10.000 lançamentos várias vezes ao abrir/expandir o DFC.
    private List<Lancamento> _historico = new();
    // Classificação calculada uma vez por lançamento; evita normalizar textos dezenas de vezes na montagem do DFC.
    private readonly Dictionary<long, string> _classeEstrutura = new();
    private readonly HashSet<string> _gruposAbertos = new(StringComparer.OrdinalIgnoreCase);
    private readonly HashSet<int> _anosAbertos = new();
    private List<DfcLinha> _linhasBase = new();
    private int _anoInicial, _anoFinal;
    private DateTime _periodoInicio, _periodoFim;
    private readonly Dictionary<string, int> _ordemManual = new(StringComparer.OrdinalIgnoreCase);
    private readonly string _arquivoOrdem = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "FinanceiroMasterPro", "DfcOrdem.txt");
    private readonly string _arquivoPeriodo = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "FinanceiroMasterPro", "DfcPeriodo.txt");
    private Point _dragStart;
    private DfcLinha? _linhaArrastada;

    public DfcCaixaView()
    {
        InitializeComponent();
        var meses = new List<MesOpcao> { new(0, "TUDO") };
        meses.AddRange(Enumerable.Range(1, 12).Select(m => new MesOpcao(m, CultureInfo.GetCultureInfo("pt-BR").DateTimeFormat.GetMonthName(m))));
        CmbMesInicial.ItemsSource = meses; CmbMesInicial.DisplayMemberPath = "Nome"; CmbMesInicial.SelectedValuePath = "Numero";
        CmbMesFinal.ItemsSource = meses; CmbMesFinal.DisplayMemberPath = "Nome"; CmbMesFinal.SelectedValuePath = "Numero";
        CmbMesInicial.SelectedValue = 0; CmbMesFinal.SelectedValue = 0;
        CarregarOrdem();
        _historico = _repo.ListarDfc();
        foreach (var x in _historico) _classeEstrutura[x.Id] = CalcularClassificacaoEstrutura(x);
        CarregarAnosDisponiveis();
        CarregarPeriodoSalvo();
        Atualizar();
    }

    private void CarregarAnosDisponiveis()
    {
        var anos = _historico
            .Select(x => x.DataPagamento!.Value.Year)
            .Distinct()
            .OrderByDescending(x => x)
            .ToList();

        CmbAnoInicial.ItemsSource = anos;
        CmbAnoFinal.ItemsSource = anos;

        if (anos.Count > 0)
        {
            CmbAnoInicial.SelectedItem = anos.First();
            CmbAnoFinal.SelectedItem = anos.Last();
        }
        else
        {
            CmbAnoInicial.SelectedIndex = -1;
            CmbAnoFinal.SelectedIndex = -1;
        }
    }


    private void CarregarPeriodoSalvo()
    {
        try
        {
            if (!File.Exists(_arquivoPeriodo)) return;
            var p = File.ReadAllText(_arquivoPeriodo).Split('|');
            if (p.Length != 4) return;
            if (int.TryParse(p[0], out var ai) && CmbAnoInicial.Items.Contains(ai)) CmbAnoInicial.SelectedItem = ai;
            if (int.TryParse(p[1], out var mi) && mi >= 0 && mi <= 12) CmbMesInicial.SelectedValue = mi;
            if (int.TryParse(p[2], out var af) && CmbAnoFinal.Items.Contains(af)) CmbAnoFinal.SelectedItem = af;
            if (int.TryParse(p[3], out var mf) && mf >= 0 && mf <= 12) CmbMesFinal.SelectedValue = mf;
        }
        catch { }
    }

    private void SalvarPeriodoAtual()
    {
        try
        {
            if (CmbAnoInicial.SelectedItem is not int ai || CmbAnoFinal.SelectedItem is not int af) return;
            int mi = CmbMesInicial.SelectedValue is int m1 ? m1 : 0;
            int mf = CmbMesFinal.SelectedValue is int m2 ? m2 : 0;
            Directory.CreateDirectory(Path.GetDirectoryName(_arquivoPeriodo)!);
            File.WriteAllText(_arquivoPeriodo, $"{ai}|{mi}|{af}|{mf}");
        }
        catch { }
    }

    private void Atualizar_Click(object sender, RoutedEventArgs e) => Atualizar();

    private void AnaliseGerencial_Click(object sender, RoutedEventArgs e)
    {
        var todos = _historico;
        if (todos.Count == 0)
        {
            MessageBox.Show("Não há lançamentos baixados para analisar.", "Análise Gerencial", MessageBoxButton.OK, MessageBoxImage.Information);
            return;
        }

        int inicio = _periodoInicio.Year;
        int fim = _periodoFim.Year;
        var baseAnalise = todos.Where(x => x.DataPagamento!.Value.Date >= _periodoInicio.Date && x.DataPagamento.Value.Date <= _periodoFim.Date).ToList();
        if (baseAnalise.Count == 0) { MessageBox.Show("Não há dados no período selecionado.", "Análise Gerencial"); return; }

        var pt = CultureInfo.GetCultureInfo("pt-BR");
        string Din(decimal v) => v.ToString("C2", pt);
        string Pct(decimal v) => v.ToString("N2", pt) + "%";
        decimal VP(decimal a, decimal b) => b == 0 ? 0 : (a-b)/Math.Abs(b)*100m;
        decimal Soma(string classe, int ano) => baseAnalise.Where(x => x.DataPagamento!.Value.Year == ano && ClassificarFluxo(x.FluxoCaixaNome) == classe).Sum(Assinado);

        var anos = Enumerable.Range(inicio, fim-inicio+1).OrderBy(x=>x).ToList();
        var dados = anos.Select(a => new {
            Ano=a, Fat=Soma("RECEB",a), Desp=Soma("DESP",a), Invest=Soma("INVEST",a), Transf=Soma("TRANSF",a)
        }).Select(x => new { x.Ano,x.Fat,x.Desp,x.Invest,x.Transf, Resultado=x.Fat+x.Desp+x.Invest+x.Transf,
            Margem=x.Fat==0?0:(x.Fat+x.Desp+x.Invest+x.Transf)/x.Fat*100m }).ToList();

        var atual=dados.Last(); var anterior=dados.Count>1?dados[^2]:dados.Last();
        var grupos = baseAnalise.Where(x=>ClassificarFluxo(x.FluxoCaixaNome)=="DESP")
            .GroupBy(x=>string.IsNullOrWhiteSpace(x.GrupoContasNome)?"SEM GRUPO":x.GrupoContasNome.Trim())
            .Select(g=>new { Nome=g.Key,
                Atual=g.Where(x=>x.DataPagamento!.Value.Year==atual.Ano).Sum(x=>Math.Abs(Assinado(x))),
                Anterior=g.Where(x=>x.DataPagamento!.Value.Year==anterior.Ano).Sum(x=>Math.Abs(Assinado(x))) })
            .Select(g=>new {g.Nome,g.Atual,g.Anterior,Impacto=g.Atual-g.Anterior,
                PAtual=atual.Fat==0?0:g.Atual/Math.Abs(atual.Fat)*100m,
                PAnterior=anterior.Fat==0?0:g.Anterior/Math.Abs(anterior.Fat)*100m})
            .OrderByDescending(g=>g.Impacto).ToList();

        var sb=new System.Text.StringBuilder();
        sb.AppendLine("ANÁLISE GERENCIAL DO DFC CAIXA");
        sb.AppendLine($"Período analisado: {_periodoInicio:MM/yyyy} a {_periodoFim:MM/yyyy}");
        sb.AppendLine(new string('═',78)); sb.AppendLine();
        sb.AppendLine("1. EVOLUÇÃO ANUAL");
        foreach(var d in dados)
            sb.AppendLine($"{d.Ano}  | Faturamento {Din(d.Fat)} | Despesas {Din(Math.Abs(d.Desp))} | Resultado {Din(d.Resultado)} | Margem {Pct(d.Margem)}");

        sb.AppendLine(); sb.AppendLine("2. DIAGNÓSTICO EXECUTIVO");
        if(dados.Count>1) {
            var vf=VP(atual.Fat,anterior.Fat); var vd=VP(Math.Abs(atual.Desp),Math.Abs(anterior.Desp)); var vr=atual.Resultado-anterior.Resultado;
            sb.AppendLine($"• Faturamento: {Din(anterior.Fat)} → {Din(atual.Fat)} ({Pct(vf)}).");
            sb.AppendLine($"• Despesas: {Din(Math.Abs(anterior.Desp))} → {Din(Math.Abs(atual.Desp))} ({Pct(vd)}).");
            sb.AppendLine($"• Resultado: {Din(anterior.Resultado)} → {Din(atual.Resultado)}; impacto de {Din(vr)}.");
            sb.AppendLine($"• Margem: {Pct(anterior.Margem)} → {Pct(atual.Margem)} ({(atual.Margem-anterior.Margem).ToString("N2",pt)} p.p.).");
            if(atual.Resultado<anterior.Resultado) sb.AppendLine("🔴 O resultado deteriorou no último período. A prioridade é proteger margem e caixa antes de buscar crescimento sem rentabilidade.");
            else sb.AppendLine("🟢 O resultado melhorou no último período. É importante identificar quais ganhos são recorrentes para preservá-los.");
        } else sb.AppendLine("• Há somente um ano selecionado; a análise mostra composição e participação sobre o faturamento.");

        sb.AppendLine(); sb.AppendLine("3. MAIORES IMPACTOS / % DO FATURAMENTO");
        foreach(var g in grupos.Take(8))
            sb.AppendLine($"• {g.Nome}: {Din(g.Anterior)} → {Din(g.Atual)} | impacto {Din(g.Impacto)} | {Pct(g.PAnterior)} → {Pct(g.PAtual)} do faturamento");

        sb.AppendLine(); sb.AppendLine("4. ALERTAS E PONTOS POSITIVOS");
        foreach(var g in grupos.Where(x=>x.Impacto>0).Take(4)) sb.AppendLine($"🔴 {g.Nome}: aumentou {Din(g.Impacto)} e hoje consome {Pct(g.PAtual)} do faturamento.");
        foreach(var g in grupos.Where(x=>x.Impacto<0).OrderBy(x=>x.Impacto).Take(3)) sb.AppendLine($"🟢 {g.Nome}: redução de {Din(Math.Abs(g.Impacto))} no período comparado.");

        var compras=grupos.FirstOrDefault(g=>Normal(g.Nome).Contains("COMPRA") || Normal(g.Nome).Contains("MERCADOR") || Normal(g.Nome).Contains("CUSTO"));
        var pessoal=grupos.FirstOrDefault(g=>Normal(g.Nome).Contains("COLAB") || Normal(g.Nome).Contains("PESSOAL") || Normal(g.Nome).Contains("FOLHA"));
        var socios=grupos.FirstOrDefault(g=>Normal(g.Nome).Contains("SOCIO") || Normal(g.Nome).Contains("PRO-LABORE") || Normal(g.Nome).Contains("PRO LABORE"));

        sb.AppendLine(); sb.AppendLine("5. PRECIFICAÇÃO E MARGEM");
        if(compras!=null) {
            sb.AppendLine($"• Compras/custos identificados: {Pct(compras.PAtual)} do faturamento no último ano analisado.");
            if(compras.PAtual>70) sb.AppendLine("🔴 Pressão elevada sobre a margem. Revisar custo, preço, mix e giro de estoque com prioridade.");
            else if(compras.PAtual>55) sb.AppendLine("🟡 Atenção à margem: validar se o preço cobre custo, taxas, impostos, fretes, devoluções e margem desejada.");
            else sb.AppendLine("🟢 Relação compras/custos x faturamento não indica, isoladamente, pressão extrema; acompanhar por produto/canal.");
            sb.AppendLine("⚠ DFC é fluxo de caixa: compra de mercadoria pode formar estoque. Antes de recomendar reajuste de preço, conferir estoque e CMV do período.");
        } else sb.AppendLine("• Não foi identificado um grupo de compras/custos pelo nome. Para concluir sobre preço, conferir CMV, estoque e margem por produto/canal.");
        sb.AppendLine("• Fórmula gerencial: Preço de venda − custo − impostos − taxas/comissões − frete − devoluções/ADS = margem de contribuição.");

        sb.AppendLine(); sb.AppendLine("6. PRIORIDADES RECOMENDADAS PARA A REUNIÃO");
        int n=1;
        foreach(var g in grupos.Where(x=>x.Impacto>0).Take(3)) sb.AppendLine($"{n++}. Revisar {g.Nome}: crescimento de {Din(g.Impacto)} e participação de {Pct(g.PAtual)} do faturamento.");
        if(pessoal!=null && pessoal.Impacto>0) sb.AppendLine($"{n++}. Pessoal/colaboradores cresceu {Din(pessoal.Impacto)}; comparar produtividade e crescimento do faturamento.");
        if(socios!=null && socios.Impacto>0) sb.AppendLine($"{n++}. Retiradas/pró-labore cresceram {Din(socios.Impacto)}; validar compatibilidade com a geração operacional de caixa.");
        sb.AppendLine($"{n++}. Validar margem por produto e canal antes de qualquer reajuste geral de preços.");
        sb.AppendLine($"{n++}. Separar efeito de estoque do custo efetivamente vendido para não confundir pressão de caixa com prejuízo econômico.");

        sb.AppendLine(); sb.AppendLine("7. FALA SUGERIDA AO CLIENTE");
        if(dados.Count>1) sb.AppendLine($"“No comparativo {anterior.Ano} x {atual.Ano}, o faturamento variou {Pct(VP(atual.Fat,anterior.Fat))} e o resultado mudou em {Din(atual.Resultado-anterior.Resultado)}. Os maiores impactos estão destacados acima. Nossa prioridade é atuar nos itens que cresceram acima da receita, proteger a margem e validar a precificação por produto e canal antes de buscar crescimento sem rentabilidade.”");
        else sb.AppendLine("“Este DFC mostra onde o caixa está sendo consumido. Vamos concentrar a gestão nos grupos de maior participação sobre o faturamento e validar margem, estoque e precificação antes das decisões.”");

        sb.AppendLine(); sb.AppendLine("Observação: análise automática baseada nos lançamentos baixados do DFC Caixa. Ela é gerencial e indicativa; decisões de preço exigem também estoque/CMV, custo unitário, taxas, impostos e dados comerciais.");

        var texto=new TextBox { Text=sb.ToString(),IsReadOnly=true,TextWrapping=TextWrapping.Wrap,VerticalScrollBarVisibility=ScrollBarVisibility.Auto,
            HorizontalScrollBarVisibility=ScrollBarVisibility.Disabled,FontFamily=new FontFamily("Segoe UI"),FontSize=15,Padding=new Thickness(22),
            Background=Brushes.White,Foreground=new SolidColorBrush(Color.FromRgb(11,45,79)),BorderThickness=new Thickness(0)};
        var janela=new Window { Title=$"Análise Gerencial do DFC Caixa — {_periodoInicio:MM/yyyy} a {_periodoFim:MM/yyyy}",Width=1100,Height=800,MinWidth=800,MinHeight=560,
            WindowStartupLocation=WindowStartupLocation.CenterOwner,Owner=Window.GetWindow(this),Content=texto,Background=Brushes.White};
        janela.ShowDialog();
    }

    private void Atualizar()
    {
        if (CmbAnoInicial.SelectedItem is not int ai || CmbAnoFinal.SelectedItem is not int af)
        {
            _lancamentos.Clear();
            _linhasBase.Clear();
            PrepararReferenciasFaturamento();
            GridDfc.Columns.Clear();
            var descVazia = new DataGridTextColumn
            {
                Header = "Descrição",
                Width = new DataGridLength(310),
                Binding = new Binding("DescricaoExibicao")
            };
            GridDfc.Columns.Add(descVazia);
            GridDfc.ItemsSource = null;
            return;
        }

        int miEscolhido = CmbMesInicial.SelectedValue is int m1 ? m1 : 0;
        int mfEscolhido = CmbMesFinal.SelectedValue is int m2 ? m2 : 0;

        // O DFC exibe os anos do mais recente para o mais antigo.
        // TUDO precisa significar o ano completo, inclusive nas pontas do intervalo.
        if (ai == af)
        {
            int mes1 = miEscolhido == 0 ? 1 : miEscolhido;
            int mes2 = mfEscolhido == 0 ? 12 : mfEscolhido;
            int primeiroMes = Math.Min(mes1, mes2);
            int ultimoMes = Math.Max(mes1, mes2);
            _periodoInicio = new DateTime(ai, primeiroMes, 1);
            _periodoFim = new DateTime(ai, ultimoMes, DateTime.DaysInMonth(ai, ultimoMes));
        }
        else if (ai > af)
        {
            // Inicio = ano mais recente; Final = ano mais antigo.
            // No ano recente, TUDO termina em dezembro; no ano antigo, TUDO começa em janeiro.
            int mesAnoRecente = miEscolhido == 0 ? 12 : miEscolhido;
            int mesAnoAntigo = mfEscolhido == 0 ? 1 : mfEscolhido;
            _periodoInicio = new DateTime(af, mesAnoAntigo, 1);
            _periodoFim = new DateTime(ai, mesAnoRecente, DateTime.DaysInMonth(ai, mesAnoRecente));
        }
        else
        {
            // Compatibilidade caso os anos sejam escolhidos em ordem crescente.
            int mesAnoAntigo = miEscolhido == 0 ? 1 : miEscolhido;
            int mesAnoRecente = mfEscolhido == 0 ? 12 : mfEscolhido;
            _periodoInicio = new DateTime(ai, mesAnoAntigo, 1);
            _periodoFim = new DateTime(af, mesAnoRecente, DateTime.DaysInMonth(af, mesAnoRecente));
        }
        _anoInicial = _periodoFim.Year;
        _anoFinal = _periodoInicio.Year;
        _lancamentos = _historico.Where(x => x.DataPagamento!.Value.Date >= _periodoInicio.Date && x.DataPagamento.Value.Date <= _periodoFim.Date).ToList();
        SalvarPeriodoAtual();
        MontarLinhas(); PrepararReferenciasFaturamento(); MontarColunas(); AplicarLinhas();
    }

    private sealed record MesOpcao(int Numero, string Nome);

    private decimal Assinado(Lancamento x)
    {
        if (x.Tipo.Equals("Pagar", StringComparison.OrdinalIgnoreCase)) return -Math.Abs(x.Valor);
        if (x.Tipo.Equals("Receber", StringComparison.OrdinalIgnoreCase)) return Math.Abs(x.Valor);
        return x.Valor;
    }

    private void MontarLinhas()
    {
        _linhasBase.Clear();

        // Estrutura gerencial fixa do DFC. As linhas de movimento só aparecem quando
        // existem no período selecionado ou já existiram no histórico da empresa.
        var historico = _historico;

        var buckets = new[]
        {
            new { Chave="RECEB", Titulo="RECEBIMENTO OPERACIONAL" },
            new { Chave="DEDUC", Titulo="DEDUÇÕES" },
            new { Chave="CUSTOS", Titulo="CUSTOS" },
            new { Chave="DESP", Titulo="DESP. OPERACIONAIS" },
            new { Chave="SOCIOS", Titulo="DESP. C/ SÓCIOS" },
            new { Chave="INVEST_ENT", Titulo="INVESTIMENTO ENTRADA" },
            new { Chave="INVEST_SAI", Titulo="INVESTIMENTO SAÍDA" },
            new { Chave="FIN_ENT", Titulo="FINANCIAMENTO ENTRADA" },
            new { Chave="FIN_SAI", Titulo="FINANCIAMENTO SAÍDA" },
            new { Chave="TRANSF", Titulo="TRANSFERÊNCIAS" }
        };

        List<Lancamento> Itens(string chave, IEnumerable<Lancamento> fonte) =>
            fonte.Where(x => ClassificarEstrutura(x) == chave).ToList();

        void AddMovimento(string chave, string titulo)
        {
            var atual = Itens(chave, _lancamentos);
            var hist = Itens(chave, historico);
            if (atual.Count == 0 && hist.Count == 0) return;

            var chaveCab = "G|" + chave;
            var cab = new DfcLinha { Chave=chaveCab, Descricao=titulo, Nivel=0, Grupo=true };
            Preencher(cab, atual);
            _linhasBase.Add(cab);

            // Grupo de contas = segundo nível. Se não houver grupo, usa o próprio Fluxo de Caixa.
            foreach (var sub in atual
                .GroupBy(x => string.IsNullOrWhiteSpace(x.GrupoContasNome)
                    ? (string.IsNullOrWhiteSpace(x.FluxoCaixaNome) ? "SEM GRUPO" : x.FluxoCaixaNome.Trim())
                    : x.GrupoContasNome.Trim())
                .OrderBy(x => OrdemDe($"S|{chave}|{Normal(x.Key)}"))
                .ThenBy(x => x.Key, StringComparer.CurrentCultureIgnoreCase))
            {
                var chaveSub = $"S|{chave}|{Normal(sub.Key)}";
                var linhaSub = new DfcLinha { Chave=chaveSub, ChavePai=chaveCab, Descricao=sub.Key.ToUpperInvariant(), Nivel=1, Grupo=true };
                Preencher(linhaSub, sub);
                _linhasBase.Add(linhaSub);

                foreach (var plano in sub
                    .GroupBy(x => string.IsNullOrWhiteSpace(x.PlanoContasNome) ? "SEM PLANO DE CONTAS" : x.PlanoContasNome.Trim())
                    .OrderBy(x => OrdemDe($"D|{chave}|{Normal(sub.Key)}|{Normal(x.Key)}"))
                    .ThenBy(x => x.Key, StringComparer.CurrentCultureIgnoreCase))
                {
                    var detalhe = new DfcLinha
                    {
                        Chave=$"D|{chave}|{Normal(sub.Key)}|{Normal(plano.Key)}",
                        ChavePai=chaveSub, ChaveAvo=chaveCab,
                        Descricao=plano.Key.ToUpperInvariant(), Nivel=2
                    };
                    Preencher(detalhe, plano);
                    _linhasBase.Add(detalhe);
                }
            }
        }

        void AddCalculada(string chave, string titulo, Func<Lancamento,bool> filtro, bool margem=false)
        {
            var itens = _lancamentos.Where(filtro).ToList();
            var hist = historico.Where(filtro).ToList();
            if (itens.Count == 0 && hist.Count == 0 && !margem) return;
            var l = new DfcLinha { Chave="C|"+chave, Descricao=titulo, Nivel=0, Margem=margem, Resultado=true };
            Preencher(l, itens);
            _linhasBase.Add(l);
        }

        // 1) Operação e deduções
        AddMovimento("RECEB", "RECEBIMENTO OPERACIONAL");
        AddMovimento("DEDUC", "DEDUÇÕES");

        // Recebimento líquido = recebimentos + deduções.
        AddCalculada("REC_LIQ", "RECEBIMENTO LÍQUIDO",
            x => ClassificarEstrutura(x) is "RECEB" or "DEDUC");

        AddMovimento("CUSTOS", "CUSTOS");

        // Margem = recebimento líquido + custos.
        AddCalculada("MARGEM", "MARGEM DE CONTRIBUIÇÃO",
            x => ClassificarEstrutura(x) is "RECEB" or "DEDUC" or "CUSTOS", true);

        // 2) Estrutura operacional
        AddMovimento("DESP", "DESP. OPERACIONAIS");
        AddCalculada("CX_ANTES_SOCIOS", "GERAÇÃO DE CAIXA OP. ANTES DOS SÓCIOS",
            x => ClassificarEstrutura(x) is "RECEB" or "DEDUC" or "CUSTOS" or "DESP");

        AddMovimento("SOCIOS", "DESP. C/ SÓCIOS");
        AddCalculada("CX_OPER", "GERAÇÃO DE CAIXA OPERACIONAL",
            x => ClassificarEstrutura(x) is "RECEB" or "DEDUC" or "CUSTOS" or "DESP" or "SOCIOS");

        // 3) Investimentos
        AddMovimento("INVEST_ENT", "INVESTIMENTO ENTRADA");
        AddMovimento("INVEST_SAI", "INVESTIMENTO SAÍDA");
        AddCalculada("CX_APOS_INV", "GERAÇÃO DE CAIXA APÓS INVESTIMENTOS",
            x => ClassificarEstrutura(x) is "RECEB" or "DEDUC" or "CUSTOS" or "DESP" or "SOCIOS" or "INVEST_ENT" or "INVEST_SAI");

        // 4) Financiamentos
        AddMovimento("FIN_ENT", "FINANCIAMENTO ENTRADA");
        AddMovimento("FIN_SAI", "FINANCIAMENTO SAÍDA");
        AddCalculada("CX_LIQ", "GERAÇÃO DE CAIXA LÍQUIDA",
            x => ClassificarEstrutura(x) is "RECEB" or "DEDUC" or "CUSTOS" or "DESP" or "SOCIOS" or "INVEST_ENT" or "INVEST_SAI" or "FIN_ENT" or "FIN_SAI");

        // 5) Transferências
        AddMovimento("TRANSF", "TRANSFERÊNCIAS");

        ReordenarEstruturaCompleta();

        var total = new DfcLinha { Chave="TOTAL", Descricao="TOTAL GERAL", Nivel=0, Total=true };
        Preencher(total, _lancamentos);
        _linhasBase.Add(total);
    }

    private string ClassificarEstrutura(Lancamento x)
    {
        if (_classeEstrutura.TryGetValue(x.Id, out var classe)) return classe;
        classe = CalcularClassificacaoEstrutura(x);
        _classeEstrutura[x.Id] = classe;
        return classe;
    }

    private string CalcularClassificacaoEstrutura(Lancamento x)
    {
        var texto = Normal($"{x.FluxoCaixaNome} {x.GrupoContasNome} {x.PlanoContasNome}");
        if (texto.Contains("TRANSF")) return "TRANSF";
        if (texto.Contains("DEDUC") || texto.Contains("DEVOLU") || texto.Contains("TAXA DE VENDA") ||
            texto.Contains("FRETE DE VENDA") || texto.Contains("FRETE DE DEVOLU") || texto.Contains("ICMS") ||
            texto.Contains("SIMPLES NACIONAL")) return "DEDUC";
        if (texto.Contains("CUSTO") || texto.Contains("COMPRA DE MERCADORIA") || texto.Contains("CMV")) return "CUSTOS";
        if (texto.Contains("SOCIO") || texto.Contains("PRO-LABORE") || texto.Contains("PRO LABORE")) return "SOCIOS";
        if (texto.Contains("FINANCI") || texto.Contains("EMPREST") || texto.Contains("AMORTIZA"))
            return Assinado(x) >= 0 ? "FIN_ENT" : "FIN_SAI";
        if (texto.Contains("INVEST") || texto.Contains("CONSORCIO") || texto.Contains("COMPRA DE IMOV") ||
            texto.Contains("COMPRA DE MAQU") || texto.Contains("COMPRA DE TERRE") || texto.Contains("OBRA"))
            return Assinado(x) >= 0 ? "INVEST_ENT" : "INVEST_SAI";
        if (texto.Contains("RECEB") || texto.Contains("RECEITA") || x.Tipo.Equals("Receber", StringComparison.OrdinalIgnoreCase))
            return "RECEB";
        return "DESP";
    }

    private void ReordenarEstruturaCompleta()
    {
        string[] ordem =
        {
            "G|RECEB","G|DEDUC","C|REC_LIQ","G|CUSTOS","C|MARGEM",
            "G|DESP","C|CX_ANTES_SOCIOS","G|SOCIOS","C|CX_OPER",
            "G|INVEST_ENT","G|INVEST_SAI","C|CX_APOS_INV",
            "G|FIN_ENT","G|FIN_SAI","C|CX_LIQ","G|TRANSF"
        };
        var pos = ordem.Select((k,i)=>(k,i)).ToDictionary(x=>x.k,x=>x.i,StringComparer.OrdinalIgnoreCase);
        var blocos = new List<List<DfcLinha>>();
        foreach (var linha in _linhasBase.Where(x=>x.Nivel==0))
        {
            var bloco = new List<DfcLinha>{linha};
            if (linha.Grupo)
                bloco.AddRange(_linhasBase.Where(x => x.ChavePai == linha.Chave || x.ChaveAvo == linha.Chave));
            blocos.Add(bloco);
        }
        _linhasBase = blocos
            .OrderBy(b => _ordemManual.TryGetValue(b[0].Chave, out var om) ? om : (pos.TryGetValue(b[0].Chave,out var p) ? 1000+p : 9999))
            .SelectMany(b=>b).ToList();
    }

    private void ReordenarBlocosCabeca()
    {
        var cabecas = _linhasBase.Where(x => x.Nivel == 0 && x.Grupo).ToList();
        if (cabecas.Count == 0) return;

        var blocos = new List<List<DfcLinha>>();
        foreach (var cabeca in cabecas)
        {
            var bloco = new List<DfcLinha> { cabeca };
            bloco.AddRange(_linhasBase.Where(x =>
                (x.Nivel == 1 && string.Equals(x.ChavePai, cabeca.Chave, StringComparison.OrdinalIgnoreCase)) ||
                (x.Nivel == 2 && string.Equals(x.ChaveAvo, cabeca.Chave, StringComparison.OrdinalIgnoreCase))));
            var margem = _linhasBase.FirstOrDefault(x => x.Margem);
            if (cabeca.Descricao == "(-) DESP. OPERACIONAIS" && margem != null) bloco.Add(margem);
            blocos.Add(bloco);
        }

        var ordenados = blocos
            .OrderBy(b => OrdemDe(b[0].Chave))
            .ThenBy(b => b[0].Chave == "G|RECEB" ? 0 : b[0].Chave == "G|DESP" ? 1 : b[0].Chave == "G|INVEST" ? 2 : 3)
            .SelectMany(b => b).ToList();

        _linhasBase = ordenados;
    }

    private void InserirMargemContribuicao()
    {
        if (_linhasBase.Any(x => x.Margem)) return;

        var receita = _lancamentos.Where(x => ClassificarFluxo(x.FluxoCaixaNome) == "RECEB");
        var despesa = _lancamentos.Where(x => ClassificarFluxo(x.FluxoCaixaNome) == "DESP");
        var m = new DfcLinha { Descricao = "= MARGEM DE CONTRIBUIÇÃO", Nivel = 0, Margem = true };

        foreach (var ano in Enumerable.Range(_anoFinal, _anoInicial - _anoFinal + 1))
        {
            m.Anos[ano] = receita.Where(x => x.DataPagamento!.Value.Year == ano).Sum(Assinado)
                        + despesa.Where(x => x.DataPagamento!.Value.Year == ano).Sum(Assinado);
            for (int mes = 1; mes <= 12; mes++)
                m.Meses[(ano, mes)] = receita.Where(x => x.DataPagamento!.Value.Year == ano && x.DataPagamento.Value.Month == mes).Sum(Assinado)
                                     + despesa.Where(x => x.DataPagamento!.Value.Year == ano && x.DataPagamento.Value.Month == mes).Sum(Assinado);
        }
        m.TotalGeral = m.Anos.Values.Sum();
        _linhasBase.Add(m);
    }

    private static string ClassificarFluxo(string? fluxo)
    {
        var n = Normal(fluxo);
        if (n.Contains("TRANSF")) return "TRANSF";
        if (n.Contains("INVEST") || n.Contains("C / D") || n.Contains("C/D")) return "INVEST";
        if (n.Contains("DESP")) return "DESP";
        if (n.Contains("RECEB") || n.Contains("RECEITA")) return "RECEB";
        return "OUTROS";
    }

    private void Preencher(DfcLinha linha, IEnumerable<Lancamento> itens)
    {
        // Uma única passagem pelos lançamentos do grupo. Antes eram feitas até 13 varreduras por ano.
        foreach (var ano in Enumerable.Range(_anoFinal, _anoInicial - _anoFinal + 1))
        {
            linha.Anos[ano] = 0m;
            for (int mes = 1; mes <= 12; mes++) linha.Meses[(ano, mes)] = 0m;
        }
        decimal total = 0m;
        foreach (var x in itens)
        {
            if (!x.DataPagamento.HasValue) continue;
            var d = x.DataPagamento.Value;
            if (d.Year < _anoFinal || d.Year > _anoInicial) continue;
            var v = Assinado(x);
            linha.Anos[d.Year] = linha.Anos.TryGetValue(d.Year, out var ya) ? ya + v : v;
            var k = (d.Year, d.Month);
            linha.Meses[k] = linha.Meses.TryGetValue(k, out var ma) ? ma + v : v;
            total += v;
        }
        linha.TotalGeral = total;
    }


    private void PrepararReferenciasFaturamento()
    {
        // Consolida o faturamento uma única vez por ano/mês e reaproveita em todas as linhas.
        var faturamentoAnos = new Dictionary<int, decimal>();
        var faturamentoMeses = new Dictionary<(int Ano, int Mes), decimal>();
        decimal faturamentoTotal = 0m;

        foreach (var x in _lancamentos)
        {
            if (!x.DataPagamento.HasValue || ClassificarEstrutura(x) != "RECEB") continue;
            var d = x.DataPagamento.Value;
            var v = Assinado(x);
            faturamentoTotal += v;
            faturamentoAnos[d.Year] = faturamentoAnos.TryGetValue(d.Year, out var ya) ? ya + v : v;
            var k = (d.Year, d.Month);
            faturamentoMeses[k] = faturamentoMeses.TryGetValue(k, out var ma) ? ma + v : v;
        }

        foreach (var linha in _linhasBase)
        {
            linha.FaturamentoTotal = faturamentoTotal;
            foreach (var ano in Enumerable.Range(_anoFinal, _anoInicial - _anoFinal + 1))
            {
                linha.FaturamentoAnos[ano] = faturamentoAnos.TryGetValue(ano, out var ya) ? ya : 0m;
                for (int mes = 1; mes <= 12; mes++)
                    linha.FaturamentoMeses[(ano, mes)] = faturamentoMeses.TryGetValue((ano, mes), out var ma) ? ma : 0m;
            }
        }
    }

    private void AplicarLinhas()
    {
        // O estado visual pertence à própria linha. Assim, ao agrupar/desagrupar,
        // nenhuma linha reciclada herda cor ou símbolo de outra linha.
        foreach (var linha in _linhasBase)
            linha.Aberto = linha.Grupo && _gruposAbertos.Contains(linha.Chave);

        GridDfc.ItemsSource = _linhasBase.Where(x =>
            x.Nivel == 0 ||
            (x.Nivel == 1 && _gruposAbertos.Contains(x.ChavePai)) ||
            (x.Nivel == 2 && _gruposAbertos.Contains(x.ChaveAvo) && _gruposAbertos.Contains(x.ChavePai)))
            .ToList();
    }

    private void MontarColunas()
    {
        GridDfc.Columns.Clear();
        var desc = new DataGridTemplateColumn { Header = "Descrição", Width = new DataGridLength(310) };
        var f = new FrameworkElementFactory(typeof(TextBlock));
        f.SetBinding(TextBlock.TextProperty, new Binding("DescricaoExibicao"));
        f.SetValue(TextBlock.VerticalAlignmentProperty, VerticalAlignment.Center);
        f.SetBinding(TextBlock.FontWeightProperty,
            new Binding(".") { Converter = new DfcValorFontWeightConverter() });
        f.SetValue(TextBlock.PaddingProperty, new Thickness(8,0,4,0));
        f.SetValue(ToolTipService.InitialShowDelayProperty, 0);
        f.SetValue(ToolTipService.BetweenShowDelayProperty, 0);
        f.SetValue(ToolTipService.ShowDurationProperty, 60000);
        f.SetBinding(TextBlock.ForegroundProperty, new Binding("Foreground") { RelativeSource = new RelativeSource(RelativeSourceMode.FindAncestor, typeof(DataGridRow), 1) });
        // Tooltip somente quando a regra do SUB-GRUPO permitir.
        f.SetBinding(FrameworkElement.ToolTipProperty, new Binding(".") { Converter = new DfcTooltipConverter(), ConverterParameter = "TOTAL" });
        f.AddHandler(TextBlock.MouseLeftButtonDownEvent, new MouseButtonEventHandler(Descricao_MouseLeftButtonDown));
        desc.CellTemplate = new DataTemplate { VisualTree = f }; GridDfc.Columns.Add(desc);
        for (int ano = _anoInicial; ano >= _anoFinal; ano--)
        {
            int a = ano; var h = new Button { Content = (_anosAbertos.Contains(a) ? "−  " : "+  ") + a, FontWeight = FontWeights.Bold, Background = Brushes.Transparent, BorderThickness = new Thickness(0), Tag = a }; h.Click += Ano_Click;
            GridDfc.Columns.Add(CriarValorColuna(h, $"[Y{a}]", 125, a));
            if (_anosAbertos.Contains(a)) for(int mes=1;mes<=12;mes++)
            {
                var primeiroDia = new DateTime(a, mes, 1);
                var ultimoDia = new DateTime(a, mes, DateTime.DaysInMonth(a, mes));
                if (ultimoDia < _periodoInicio || primeiroDia > _periodoFim) continue;
                GridDfc.Columns.Add(CriarValorColuna(CultureInfo.GetCultureInfo("pt-BR").DateTimeFormat.GetAbbreviatedMonthName(mes).ToUpperInvariant(), $"[M{a}{mes:00}]", 92, a, mes));
            }
        }
        GridDfc.Columns.Add(CriarValorColuna("Total Geral", "TotalGeral", 135));
    }

    private DataGridTextColumn CriarValorColuna(object header, string path, double largura, int? ano=null, int? mes=null)
    {
        var c = new DataGridTextColumn { Header = header, Width = new DataGridLength(largura), SortMemberPath = path.Trim('[', ']'), Binding = new Binding(path) { Converter = new MoedaDfcConverter() } };
        var st = new Style(typeof(TextBlock));
        st.Setters.Add(new Setter(TextBlock.TextAlignmentProperty, TextAlignment.Right));
        st.Setters.Add(new Setter(TextBlock.HorizontalAlignmentProperty, HorizontalAlignment.Stretch));
        st.Setters.Add(new Setter(TextBlock.VerticalAlignmentProperty, VerticalAlignment.Center));
        // Destaque somente para CABEÇA/GRUPO, Margem e Total.
        // SUB-GRUPO/detalhe permanece com peso normal.
        st.Setters.Add(new Setter(TextBlock.FontWeightProperty,
            new Binding(".") { Converter = new DfcValorFontWeightConverter() }));
        st.Setters.Add(new Setter(TextBlock.PaddingProperty, new Thickness(4,0,10,0)));
        st.Setters.Add(new Setter(ToolTipService.InitialShowDelayProperty, 0));
        st.Setters.Add(new Setter(ToolTipService.BetweenShowDelayProperty, 0));
        st.Setters.Add(new Setter(ToolTipService.ShowDurationProperty, 60000));
        var cor = new MultiBinding { Converter = new DfcValorForegroundConverter() };
        cor.Bindings.Add(new Binding(path));
        cor.Bindings.Add(new Binding("Nivel"));
        cor.Bindings.Add(new Binding("Grupo"));
        cor.Bindings.Add(new Binding("Total"));
        st.Setters.Add(new Setter(TextBlock.ForegroundProperty, cor));
        // Tooltip em TODAS as células de valor, inclusive grupos, subgrupos e detalhes.
        // Abre apenas ao passar o mouse; nenhum clique é necessário.
        var tooltipKey = ano.HasValue ? (mes.HasValue ? $"M{ano.Value}{mes.Value:00}" : $"Y{ano.Value}") : "TOTAL";
        st.Setters.Add(new Setter(FrameworkElement.ToolTipProperty,
            new Binding(".") { Converter = new DfcTooltipConverter(), ConverterParameter = tooltipKey }));
        c.ElementStyle = st;
        return c;
    }

    private void Ano_Click(object sender, RoutedEventArgs e) { if (sender is Button b && b.Tag is int a) { if(!_anosAbertos.Add(a)) _anosAbertos.Remove(a); MontarColunas(); } }
    private void Descricao_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
        if ((sender as FrameworkElement)?.DataContext is not DfcLinha l) return;

        if (e.ClickCount >= 2) return;

        if (!l.Grupo) return;
        if (!_gruposAbertos.Add(l.Chave)) _gruposAbertos.Remove(l.Chave);
        AplicarLinhas();
        e.Handled = true;
    }

    private void GridDfc_MouseDoubleClick(object sender, MouseButtonEventArgs e)
    {
        var row = Ancestral<DataGridRow>(e.OriginalSource as DependencyObject);
        var cell = Ancestral<DataGridCell>(e.OriginalSource as DependencyObject);
        if (row?.Item is not DfcLinha linha || cell == null) return;

        // Margem e Total Geral são cálculos, não contas individuais.
        if (linha.Margem || linha.Total) return;

        DateTime? inicio = null;
        DateTime? fim = null;
        var chaveColuna = cell.Column.SortMemberPath ?? "";

        // Duplo clique em M202604 = somente abril/2026.
        if (chaveColuna.StartsWith("M") && chaveColuna.Length == 7 &&
            int.TryParse(chaveColuna.Substring(1,4), out var anoMes) &&
            int.TryParse(chaveColuna.Substring(5,2), out var mes))
        {
            inicio = new DateTime(anoMes, mes, 1);
            fim = inicio.Value.AddMonths(1).AddDays(-1);
        }
        // Duplo clique no total do ano = somente aquele ano.
        else if (chaveColuna.StartsWith("Y") &&
                 int.TryParse(chaveColuna.Substring(1), out var ano))
        {
            inicio = new DateTime(ano, 1, 1);
            fim = new DateTime(ano, 12, 31);
        }

        if (Window.GetWindow(this) is MainWindow principal)
        {
            principal.AbrirLancamentosDoDfc(FiltroPesquisaDfc(linha), inicio, fim);
            e.Handled = true;
        }
    }

    private static string FiltroPesquisaDfc(DfcLinha l)
    {
        if (l.Nivel > 0) return l.Descricao;
        var n = Normal(l.Descricao);
        if (n.Contains("RECEB")) return "RECEB";
        if (n.Contains("DESP")) return "DESP";
        if (n.Contains("INVEST")) return "INVEST";
        if (n.Contains("TRANSF")) return "TRANSF";
        return l.Descricao;
    }
    private void RecolherTudo_Click(object sender, RoutedEventArgs e)
    {
        // Fecha toda a hierarquia de contas e também todos os anos.
        _gruposAbertos.Clear();
        _anosAbertos.Clear();
        MontarColunas();
        AplicarLinhas();
    }

    private void ExpandirTodos_Click(object sender, RoutedEventArgs e) { foreach(var x in _linhasBase.Where(x=>x.Grupo)) _gruposAbertos.Add(x.Chave); foreach(var a in Enumerable.Range(_anoFinal,_anoInicial-_anoFinal+1)) _anosAbertos.Add(a); MontarColunas(); AplicarLinhas(); }
    private void RecolherTodos_Click(object sender, RoutedEventArgs e) { _gruposAbertos.Clear(); _anosAbertos.Clear(); MontarColunas(); AplicarLinhas(); }
    private void RecolherParcial_Click(object sender, RoutedEventArgs e)
    {
        // GRUPO = mantém as cabeças abertas e mostra somente os GRUPOS (nível 1),
        // sem abrir os lançamentos/subgrupos internos (nível 2).
        // MARGEM DE CONTRIBUIÇÃO e TOTAL GERAL permanecem visíveis.
        _gruposAbertos.Clear();
        foreach (var x in _linhasBase.Where(x => x.Grupo && x.Nivel == 0))
            _gruposAbertos.Add(x.Chave);
        AplicarLinhas();
    }
    private void RecolherAteSubGrupo_Click(object sender, RoutedEventArgs e)
    {
        _gruposAbertos.Clear();

        // Cabeças e grupos ficam abertos; o detalhamento final/subgrupo fica visível,
        // sem abrir qualquer nível adicional.
        foreach (var x in _linhasBase.Where(x => x.Grupo && (x.Nivel == 0 || x.Nivel == 1)))
            _gruposAbertos.Add(x.Chave);

        AplicarLinhas();
    }

    private int OrdemDe(string chave)
    {
        // A ordem escolhida pelo usuário sempre vence e fica gravada permanentemente.
        if (_ordemManual.TryGetValue(chave, out var ordem)) return ordem;

        // Estrutura padrão do DFC. Ela só define a posição inicial; depois o usuário
        // pode arrastar qualquer grupo/conta entre suas irmãs e a posição fica salva.
        var n = Normal(chave);
        string[] padrao =
        {
            "SALDO INICIAL",
            "RECEBIMENTO OPERACIONAL", "RECEB. OPERACIONAL",
            "DEDUCOES", "DEDUCOES COMERCIAIS", "DEDUCOES TRIBUTARIAS",
            "RECEBIMENTO LIQUIDO",
            "CUSTOS", "COMPRA DE MERCADORIA",
            "MARGEM DE CONTRIBUICAO",
            "DESP. OPERACIONAIS", "DESP OPERACIONAIS",
            "DESP. ADMINISTRATIVA", "DESP ADMINISTRATIVA",
            "DESP. C/ COLABORADORES", "DESP C/ COLABORADORES",
            "DESP. PREDIAL", "DESP PREDIAL",
            "DESP. GERAIS", "DESP GERAIS",
            "SERVICOS DE TERCEIROS",
            "GERACAO DE CAIXA OP. ANTES DOS SOCIOS", "GERACAO DE CAIXA OP ANTES DOS SOCIOS",
            "DESP. C/ SOCIOS", "DESP C/ SOCIOS", "PRO-LABORE",
            "GERACAO DE CAIXA OPERACIONAL",
            "INVESTIMENTO ENTRADA", "INVESTIMENTO SAIDA",
            "GERACAO DE CAIXA APOS INVESTIMENTOS",
            "FINANCIAMENTO ENTRADA", "FINANCIAMENTO SAIDA",
            "GERACAO DE CAIXA LIQUIDA",
            "TRANSFERENCIAS",
            "SALDO FINAL"
        };
        for (int i = 0; i < padrao.Length; i++)
            if (n.Contains(padrao[i], StringComparison.OrdinalIgnoreCase)) return 1000 + i;
        return 100000;
    }

    private void CarregarOrdem()
    {
        _ordemManual.Clear();
        try
        {
            if (!File.Exists(_arquivoOrdem)) return;
            foreach (var linha in File.ReadAllLines(_arquivoOrdem))
            {
                var p = linha.Split('\t');
                if (p.Length == 2 && int.TryParse(p[1], out var ordem))
                    _ordemManual[p[0]] = ordem;
            }
        }
        catch { }
    }

    private void SalvarOrdem()
    {
        try
        {
            Directory.CreateDirectory(Path.GetDirectoryName(_arquivoOrdem)!);
            File.WriteAllLines(_arquivoOrdem, _ordemManual.OrderBy(x => x.Value).Select(x => $"{x.Key}\t{x.Value}"));
        }
        catch { }
    }

    private static T? Ancestral<T>(DependencyObject? origem) where T : DependencyObject
    {
        while (origem != null)
        {
            if (origem is T achado) return achado;
            origem = VisualTreeHelper.GetParent(origem);
        }
        return null;
    }

    private void GridDfc_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
        _dragStart = e.GetPosition(GridDfc);
        _linhaArrastada = Ancestral<DataGridRow>(e.OriginalSource as DependencyObject)?.Item as DfcLinha;

        // Clique no +/- é somente expandir/recolher. Não inicia DragDrop, evitando
        // a inconsistência que fazia o DFC desaparecer ao tentar abrir um grupo.
        var cell = Ancestral<DataGridCell>(e.OriginalSource as DependencyObject);
        if (_linhaArrastada?.Grupo == true && cell?.Column?.DisplayIndex == 0)
            _linhaArrastada = null;
    }

    private void GridDfc_PreviewMouseMove(object sender, MouseEventArgs e)
    {
        if (e.LeftButton != MouseButtonState.Pressed || _linhaArrastada == null) return;
        var p = e.GetPosition(GridDfc);
        if (Math.Abs(p.X - _dragStart.X) < SystemParameters.MinimumHorizontalDragDistance &&
            Math.Abs(p.Y - _dragStart.Y) < SystemParameters.MinimumVerticalDragDistance) return;
        DragDrop.DoDragDrop(GridDfc, _linhaArrastada, DragDropEffects.Move);
    }

    private void GridDfc_Drop(object sender, DragEventArgs e)
    {
        if (!e.Data.GetDataPresent(typeof(DfcLinha))) return;
        var origem = e.Data.GetData(typeof(DfcLinha)) as DfcLinha;
        var destino = Ancestral<DataGridRow>(e.OriginalSource as DependencyObject)?.Item as DfcLinha;
        if (origem == null || destino == null || ReferenceEquals(origem, destino)) return;

        // Reordena sem quebrar a hierarquia: cabeça com cabeça, grupo dentro da mesma cabeça,
        // conta final dentro do mesmo grupo.
        if (origem.Nivel != destino.Nivel || origem.Margem || origem.Total || destino.Margem || destino.Total) return;
        if (origem.Nivel == 1 && !string.Equals(origem.ChavePai, destino.ChavePai, StringComparison.OrdinalIgnoreCase)) return;
        if (origem.Nivel == 2 && !string.Equals(origem.ChavePai, destino.ChavePai, StringComparison.OrdinalIgnoreCase)) return;

        IEnumerable<DfcLinha> irmas = origem.Nivel switch
        {
            0 => _linhasBase.Where(x => x.Nivel == 0 && x.Grupo && !x.Margem && !x.Total),
            1 => _linhasBase.Where(x => x.Nivel == 1 && string.Equals(x.ChavePai, origem.ChavePai, StringComparison.OrdinalIgnoreCase)),
            _ => _linhasBase.Where(x => x.Nivel == 2 && string.Equals(x.ChavePai, origem.ChavePai, StringComparison.OrdinalIgnoreCase))
        };

        var lista = irmas.OrderBy(x => OrdemDe(x.Chave)).ThenBy(x => x.Descricao, StringComparer.CurrentCultureIgnoreCase).ToList();
        lista.Remove(origem);
        var idx = lista.IndexOf(destino);
        if (idx < 0) return;
        lista.Insert(idx, origem);

        for (int i = 0; i < lista.Count; i++) _ordemManual[lista[i].Chave] = i;
        SalvarOrdem();
        MontarLinhas();
        PrepararReferenciasFaturamento();
        AplicarLinhas();
    }

    private static string Normal(string? s) => (s??"").ToUpperInvariant().Replace("Ê","E").Replace("É","E").Replace("Á","A").Replace("Ã","A").Replace("Ç","C");
}

public sealed class DfcLinha
{
 public string Chave {get;set;}=""; public string ChavePai {get;set;}=""; public string ChaveAvo {get;set;}=""; public string Descricao {get;set;}=""; public int Nivel {get;set;} public bool Grupo {get;set;} public bool Aberto {get;set;} public bool Margem {get;set;} public bool Resultado {get;set;} public bool Total {get;set;}
 public Dictionary<int,decimal> Anos {get;}=new(); public Dictionary<(int,int),decimal> Meses {get;}=new(); public decimal TotalGeral {get;set;}
 public Dictionary<int,decimal> FaturamentoAnos {get;}=new(); public Dictionary<(int,int),decimal> FaturamentoMeses {get;}=new(); public decimal FaturamentoTotal {get;set;}
 public decimal this[string key] { get { if (key.StartsWith("Y") && int.TryParse(key[1..], out var y)) return Anos.TryGetValue(y,out var v)?v:0m; if(key.StartsWith("M") && key.Length>=7 && int.TryParse(key.Substring(1,4),out y) && int.TryParse(key.Substring(5,2),out var m)) return Meses.TryGetValue((y,m),out var mv)?mv:0m; return 0m; } }
 public string DescricaoExibicao => Resultado
     ? "=   " + Descricao
     : Grupo
       ? (Nivel == 0
           ? (Aberto ? "−   " : "+   ") + Descricao
           : "    " + (Aberto ? "−   " : "+   ") + Descricao)
       : (Nivel == 2 ? "            " + Descricao : "        " + Descricao);
}
public sealed class DfcRowBackgroundConverter : IValueConverter
{
 public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
 {
  if (value is not DfcLinha l) return Brushes.White;
  if (l.Resultado) return new SolidColorBrush(Color.FromRgb(255,242,154));
  if (l.Total) return new SolidColorBrush(Color.FromRgb(167,232,181));
  if (l.Grupo && l.Nivel == 0) return new SolidColorBrush(Color.FromRgb(33,97,140));
  if (l.Grupo && l.Nivel == 1) return new SolidColorBrush(Color.FromRgb(220,236,248));
  return Brushes.White;
 }
 public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)=>Binding.DoNothing;
}
public sealed class DfcRowForegroundConverter : IValueConverter
{
 public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
 {
  if (value is DfcLinha l && l.Grupo && l.Nivel == 0) return Brushes.White;
  return new SolidColorBrush(Color.FromRgb(11,45,79));
 }
 public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)=>Binding.DoNothing;
}
public sealed class DfcRowFontWeightConverter : IValueConverter
{
 public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
 {
  if (value is DfcLinha l && (l.Grupo || l.Resultado || l.Total)) return FontWeights.Bold;
  return FontWeights.Normal;
 }
 public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)=>Binding.DoNothing;
}

public sealed class MoedaDfcConverter : IValueConverter
{
 public object Convert(object value, Type targetType, object parameter, CultureInfo culture) { var v=value is decimal d?d:0m; return v==0?"-":Math.Abs(v).ToString("N2",CultureInfo.GetCultureInfo("pt-BR")); }
 public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)=>Binding.DoNothing;
}

public sealed class DfcValorFontWeightConverter : IValueConverter
{
 public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
 {
  if (value is DfcLinha l)
  {
      // CABEÇA (nível 0), GRUPO (nível 1) e TOTAL GERAL em negrito.
      // SUB-GRUPO/detalhe (nível 2), como ÁGUA E ESGOTO ... PISCINA, sem negrito.
      if ((l.Grupo && (l.Nivel == 0 || l.Nivel == 1)) || l.Resultado || l.Total)
          return FontWeights.Bold;
      return FontWeights.Normal;
  }
  return FontWeights.Normal;
 }
 public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)=>Binding.DoNothing;
}
public sealed class DfcValorForegroundConverter : IMultiValueConverter
{
 public object Convert(object[] values, Type targetType, object parameter, CultureInfo culture)
 {
  var valor = values.Length > 0 && values[0] is decimal d ? d : 0m;
  var nivel = values.Length > 1 && values[1] is int n ? n : 0;
  var grupo = values.Length > 2 && values[2] is bool g && g;
  // Cabeças do grupo sempre usam branco, mesmo quando o resultado é negativo.
  if (grupo && nivel == 0) return Brushes.White;
  // Total Geral usa a cor padrão do sistema; não fica vermelho apenas por ser negativo.
  if (values.Length > 3 && values[3] is bool total && total)
      return new SolidColorBrush(Color.FromRgb(11,45,79));
  if (valor < 0) return Brushes.Red;
  return new SolidColorBrush(Color.FromRgb(11,45,79));
 }
 public object[] ConvertBack(object value, Type[] targetTypes, object parameter, CultureInfo culture)=>throw new NotSupportedException();
}
public sealed class DfcTooltipConverter : IValueConverter
{
 public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
 {
  if (value is not DfcLinha l) return null!;
  // Tooltip em TODAS as linhas do DFC: grupos principais, subgrupos, contas, margens, investimentos, transferências e totais.
  var key = parameter?.ToString() ?? "TOTAL";
  decimal valor; decimal faturamento; string periodo;
  if (key.StartsWith("Y") && int.TryParse(key[1..], out var ano))
  {
   valor = l.Anos.TryGetValue(ano, out var v) ? v : 0m;
   faturamento = l.FaturamentoAnos.TryGetValue(ano, out var f) ? f : 0m;
   periodo = $"Ano: {ano}";
  }
  else if (key.StartsWith("M") && key.Length >= 7 && int.TryParse(key.Substring(1,4), out ano) && int.TryParse(key.Substring(5,2), out var mes))
  {
   valor = l.Meses.TryGetValue((ano,mes), out var v) ? v : 0m;
   faturamento = l.FaturamentoMeses.TryGetValue((ano,mes), out var f) ? f : 0m;
   periodo = $"Período: {mes:00}/{ano}";
  }
  else
  {
   valor = l.TotalGeral; faturamento = l.FaturamentoTotal; periodo = "Período: Total Geral";
  }
  var pt = CultureInfo.GetCultureInfo("pt-BR");
  var percentual = faturamento == 0 ? 0 : (valor / faturamento) * 100m;
  return $"{l.Descricao}\nValor: {Math.Abs(valor).ToString("N2",pt)}\n% do Faturamento: {percentual.ToString("N2",pt)}%\nFaturamento (Receb. Operacional): {Math.Abs(faturamento).ToString("N2",pt)}\n{periodo}";
 }
 public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)=>Binding.DoNothing;
}

public sealed class DfcDescricaoForegroundConverter : IValueConverter
{
 public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
 {
  if (value is DfcLinha l && l.Grupo && l.Nivel == 0) return Brushes.White;
  return new SolidColorBrush(Color.FromRgb(11,45,79));
 }
 public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)=>Binding.DoNothing;
}
