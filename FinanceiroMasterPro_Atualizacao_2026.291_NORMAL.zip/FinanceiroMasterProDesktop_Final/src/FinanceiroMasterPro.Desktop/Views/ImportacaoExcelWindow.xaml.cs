using Microsoft.Data.Sqlite;
using Microsoft.Win32;
using FinanceiroMasterPro.Infrastructure.Data;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Windows;
using System.Xml.Linq;

namespace FinanceiroMasterPro.Desktop.Views;

public partial class ImportacaoExcelWindow : Window
{
    private string _arquivo = string.Empty;

    private readonly HashSet<string> _contas =
        new(StringComparer.CurrentCultureIgnoreCase);

    private readonly HashSet<string> _clientes =
        new(StringComparer.CurrentCultureIgnoreCase);

    private readonly HashSet<string> _planos =
        new(StringComparer.CurrentCultureIgnoreCase);

    private readonly HashSet<string> _centros =
        new(StringComparer.CurrentCultureIgnoreCase);

    private readonly HashSet<string> _grupos =
        new(StringComparer.CurrentCultureIgnoreCase);

    private readonly HashSet<string> _fluxos =
        new(StringComparer.CurrentCultureIgnoreCase);

    private int _quantidadeLancamentos;

    public ImportacaoExcelWindow()
    {
        InitializeComponent();
    }

    private void Procurar_Click(
        object sender,
        RoutedEventArgs e)
    {
        var dialog = new OpenFileDialog
        {
            Title = "Selecione a planilha do Financeiro Master Pro",
            Filter = "Planilhas Excel (*.xlsx;*.xlsm)|*.xlsx;*.xlsm",
            CheckFileExists = true
        };

        if (dialog.ShowDialog() != true)
            return;

        _arquivo = dialog.FileName;
        TxtArquivo.Text = _arquivo;

        AnalisarPlanilha();
    }

    private void AnalisarPlanilha()
    {
        try
        {
            LimparPrevia();

            LblStatus.Text = "Analisando a planilha...";
            BtnImportar.IsEnabled = false;

            using FileStream stream = new(
                _arquivo,
                FileMode.Open,
                FileAccess.Read,
                FileShare.ReadWrite);

            using ZipArchive zip = new(
                stream,
                ZipArchiveMode.Read,
                leaveOpen: false);

            List<string> sharedStrings =
                LerSharedStrings(zip);

            string? caminhoPlanilha =
                LocalizarPlanilhaLancamentos(zip);

            // Compatibilidade adicional: planilhas de conciliação com aba CONSOLIDADO.
            if (string.IsNullOrWhiteSpace(caminhoPlanilha))
            {
                caminhoPlanilha = LocalizarPlanilhaPorNome(zip, "CONSOLIDADO");
                if (!string.IsNullOrWhiteSpace(caminhoPlanilha))
                {
                    AnalisarConsolidado(zip, caminhoPlanilha, sharedStrings);
                    AtualizarPrevia();
                    LblStatus.Text = _quantidadeLancamentos > 0
                        ? "Planilha CONSOLIDADO analisada com sucesso."
                        : "Nenhum lançamento foi identificado na aba CONSOLIDADO.";
                    BtnImportar.IsEnabled = _quantidadeLancamentos > 0;
                    return;
                }

                MessageBox.Show(
                    "Não encontrei as abas LANÇAMENTOS ou CONSOLIDADO.",
                    "Importação",
                    MessageBoxButton.OK,
                    MessageBoxImage.Warning);
                LblStatus.Text = "Formato de planilha não reconhecido.";
                return;
            }

            ZipArchiveEntry? entradaPlanilha =
                zip.GetEntry(caminhoPlanilha);

            if (entradaPlanilha == null)
            {
                MessageBox.Show(
                    "A aba LANÇAMENTOS foi localizada, " +
                    "mas não foi possível abrir seus dados.",
                    "Importação",
                    MessageBoxButton.OK,
                    MessageBoxImage.Warning);

                return;
            }

            using Stream planilhaStream =
                entradaPlanilha.Open();

            XDocument documento =
                XDocument.Load(planilhaStream);

            XNamespace ns =
                "http://schemas.openxmlformats.org/spreadsheetml/2006/main";

            foreach (XElement linha in
                     documento.Descendants(ns + "row"))
            {
                if (!int.TryParse((string?)linha.Attribute("r"), out int numeroLinha) || numeroLinha < 12)
                    continue;

                Dictionary<int, string> celulas =
                    LerCelulasLinha(
                        linha,
                        ns,
                        sharedStrings);

                string conta = Obter(celulas, 2);
                string cliente = Obter(celulas, 5);
                string descricao = Obter(celulas, 6);
                string plano = Obter(celulas, 7);
                string centro = Obter(celulas, 8);
                string valor = Obter(celulas, 9);
                string grupo = Obter(celulas, 12);
                string fluxo = Obter(celulas, 13);

                conta = NormalizarNomeCadastro(conta);
                cliente = NormalizarNomeCadastro(cliente);
                plano = NormalizarNomeCadastro(plano);
                centro = NormalizarNomeCadastro(centro);
                grupo = NormalizarNomeCadastro(grupo);
                fluxo = NormalizarNomeCadastro(fluxo);

                DateTime? dataPagamento = LerDataExcel(Obter(celulas, 3));
                if (string.IsNullOrWhiteSpace(conta) ||
                    !DataFinanceiraValida(dataPagamento) ||
                    !TentarLerDecimal(valor, out decimal valorFinanceiro) ||
                    valorFinanceiro == 0 ||
                    PareceNumero(conta))
                {
                    continue;
                }

                grupo = TextoCadastroSeguro(grupo);
                fluxo = TextoCadastroSeguro(fluxo);

                Adicionar(_contas, conta);
                Adicionar(_clientes, cliente);
                Adicionar(_planos, plano);
                Adicionar(_centros, centro);
                Adicionar(_grupos, grupo);
                Adicionar(_fluxos, fluxo);

                _quantidadeLancamentos++;
            }

            AtualizarPrevia();

            if (_quantidadeLancamentos == 0)
            {
                LblStatus.Text =
                    "Nenhum lançamento foi identificado.";

                return;
            }

            LblStatus.Text =
                "Planilha analisada com sucesso.";

            BtnImportar.IsEnabled = true;
        }
        catch (Exception ex)
        {
            BtnImportar.IsEnabled = false;

            MessageBox.Show(
                "Não foi possível analisar a planilha.\n\n" +
                ex.Message,
                "Importação",
                MessageBoxButton.OK,
                MessageBoxImage.Error);

            LblStatus.Text =
                "Erro durante a análise.";
        }
    }

    private void Importar_Click(
        object sender,
        RoutedEventArgs e)
    {
        if (string.IsNullOrWhiteSpace(_arquivo) ||
            !File.Exists(_arquivo))
        {
            MessageBox.Show(
                "Selecione primeiro a planilha.",
                "Importação",
                MessageBoxButton.OK,
                MessageBoxImage.Warning);

            return;
        }

        MessageBoxResult resposta =
            MessageBox.Show(
                $"Foram identificados " +
                $"{_quantidadeLancamentos:N0} lançamentos.\n\n" +
                "Deseja iniciar a importação?",
                "Financeiro Master Pro",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question);

        if (resposta != MessageBoxResult.Yes)
            return;

        try
        {
            BtnImportar.IsEnabled = false;
            LblStatus.Text = "Importando...";

            int quantidade =
                ExecutarImportacao();

            LblStatus.Text =
                $"Importação concluída: {quantidade:N0}.";

            MessageBox.Show(
                "IMPORTAÇÃO CONCLUÍDA!\n\n" +
                $"Lançamentos importados: {quantidade:N0}",
                "Financeiro Master Pro",
                MessageBoxButton.OK,
                MessageBoxImage.Information);

            DialogResult = true;
            Close();
        }
        catch (Exception ex)
        {
            BtnImportar.IsEnabled = true;

            LblStatus.Text =
                "Erro durante a importação.";

            MessageBox.Show(
                "A importação foi cancelada.\n\n" +
                "Nenhum dado parcial foi mantido.\n\n" +
                ex.Message,
                "Erro",
                MessageBoxButton.OK,
                MessageBoxImage.Error);
        }
    }

    private int ExecutarImportacao()
    {
        using FileStream stream = new(
            _arquivo,
            FileMode.Open,
            FileAccess.Read,
            FileShare.ReadWrite);

        using ZipArchive zip = new(
            stream,
            ZipArchiveMode.Read,
            leaveOpen: false);

        List<string> sharedStrings =
            LerSharedStrings(zip);

        string? caminhoPlanilha =
            LocalizarPlanilhaLancamentos(zip);

        if (string.IsNullOrWhiteSpace(caminhoPlanilha))
        {
            caminhoPlanilha = LocalizarPlanilhaPorNome(zip, "CONSOLIDADO");
            if (!string.IsNullOrWhiteSpace(caminhoPlanilha))
                return ExecutarImportacaoConsolidado(zip, caminhoPlanilha, sharedStrings);

            throw new Exception("Não encontrei as abas LANÇAMENTOS ou CONSOLIDADO.");
        }

        ZipArchiveEntry? entrada =
            zip.GetEntry(caminhoPlanilha);

        if (entrada == null)
            throw new Exception(
                "Não foi possível abrir LANÇAMENTOS.");

        using Stream planilhaStream =
            entrada.Open();

        XDocument documento =
            XDocument.Load(planilhaStream);

        XNamespace ns =
            "http://schemas.openxmlformats.org/spreadsheetml/2006/main";

        using var connection =
            new SqliteConnection(
                DatabaseInitializer.ConnectionString);

        connection.Open();

        using var transaction =
            connection.BeginTransaction();

        try
        {
            Dictionary<string, long> contas =
                CarregarCadastros(
                    connection,
                    transaction,
                    "ContasBancarias");

            Dictionary<string, long> clientes =
                CarregarCadastros(
                    connection,
                    transaction,
                    "ClientesFornecedores");

            Dictionary<string, long> planos =
                CarregarCadastros(
                    connection,
                    transaction,
                    "PlanosContas");

            Dictionary<string, long> centros =
                CarregarCadastros(
                    connection,
                    transaction,
                    "CentrosCustos");

            Dictionary<string, long> grupos =
                CarregarCadastros(
                    connection,
                    transaction,
                    "GruposContas");

            Dictionary<string, long> fluxos =
                CarregarCadastros(
                    connection,
                    transaction,
                    "FluxosCaixa");

            int importados = 0;

            foreach (XElement linha in
                     documento.Descendants(ns + "row"))
            {
                if (!int.TryParse((string?)linha.Attribute("r"), out int numeroLinha) || numeroLinha < 12)
                    continue;

                Dictionary<int, string> celulas =
                    LerCelulasLinha(
                        linha,
                        ns,
                        sharedStrings);

                string baixa = Obter(celulas, 1);
                string conta = Obter(celulas, 2);
                string dataPagamentoTexto = Obter(celulas, 3);
                string dataEmissaoTexto = Obter(celulas, 4);
                string cliente = Obter(celulas, 5);
                string descricao = Obter(celulas, 6);
                string plano = Obter(celulas, 7);
                string centro = Obter(celulas, 8);
                string valorTexto = Obter(celulas, 9);
                string tipoOperacao = Obter(celulas, 10);
                string periodo = Obter(celulas, 11);
                string grupo = Obter(celulas, 12);
                string fluxo = Obter(celulas, 13);

                conta = NormalizarNomeCadastro(conta);
                cliente = NormalizarNomeCadastro(cliente);
                plano = NormalizarNomeCadastro(plano);
                centro = NormalizarNomeCadastro(centro);
                grupo = NormalizarNomeCadastro(grupo);
                fluxo = NormalizarNomeCadastro(fluxo);
                string anotacoes = Obter(celulas, 14);

                if (!EhLinhaDeLancamento(
                        conta,
                        cliente,
                        descricao,
                        plano,
                        centro,
                        valorTexto,
                        grupo,
                        fluxo))
                {
                    continue;
                }

                if (!TentarLerDecimal(
                        valorTexto,
                        out decimal valor) || valor == 0)
                {
                    continue;
                }

                DateTime? dataPagamento = LerDataExcel(dataPagamentoTexto);
                DateTime? dataEmissao = LerDataExcel(dataEmissaoTexto);

                // A planilha original tem o cabeçalho real na linha 11.
                // Para importar um lançamento usamos como fonte A-I; J-M contêm fórmulas.
                // Assim, resíduos/caches de fórmulas nunca viram lançamentos ou cadastros.
                if (string.IsNullOrWhiteSpace(conta) ||
                    PareceNumero(conta) ||
                    !DataFinanceiraValida(dataPagamento))
                {
                    continue;
                }

                bool baixado = InterpretarBaixa(baixa);
                string tipo = valor < 0 ? "Pagar" : "Receber";
                grupo = TextoCadastroSeguro(grupo);
                fluxo = TextoCadastroSeguro(fluxo);
                periodo = PeriodoSeguro(periodo, baixado, dataPagamento);

                long? contaId =
                    ObterOuCriarCadastro(
                        connection,
                        transaction,
                        "ContasBancarias",
                        conta,
                        contas);

                long? clienteId =
                    ObterOuCriarCadastro(
                        connection,
                        transaction,
                        "ClientesFornecedores",
                        cliente,
                        clientes);

                long? planoId =
                    ObterOuCriarCadastro(
                        connection,
                        transaction,
                        "PlanosContas",
                        plano,
                        planos);

                long? centroId =
                    ObterOuCriarCadastro(
                        connection,
                        transaction,
                        "CentrosCustos",
                        centro,
                        centros);

                long? grupoId =
                    ObterOuCriarCadastro(
                        connection,
                        transaction,
                        "GruposContas",
                        grupo,
                        grupos);

                long? fluxoId =
                    ObterOuCriarCadastro(
                        connection,
                        transaction,
                        "FluxosCaixa",
                        fluxo,
                        fluxos);

                // O cadastro unificado exibe os vínculos Plano -> Centro -> Grupo -> Fluxo.
                // Os lançamentos já recebiam os IDs, mas o vínculo não era gravado; por isso
                // o DFC e os lançamentos estavam corretos enquanto o CADASTRO aparecia vazio.
                VincularClassificacaoImportada(
                    connection, transaction, planoId, grupoId, fluxoId, centroId);

                using var command =
                    connection.CreateCommand();

                command.Transaction =
                    transaction;

                command.CommandText =
                """
                INSERT INTO Lancamentos
                (
                    Tipo,
                    ContaBancariaId,
                    DataPagamento,
                    DataEmissao,
                    ClienteFornecedorId,
                    Descricao,
                    PlanoContasId,
                    CentroCustosId,
                    GrupoContasId,
                    FluxoCaixaId,
                    Valor,
                    Periodo,
                    Anotacoes,
                    Baixado,
                    DataBaixa,
                    Ativo,
                    CriadoEm
                )
                VALUES
                (
                    $tipo,
                    $conta,
                    $dataPagamento,
                    $dataEmissao,
                    $cliente,
                    $descricao,
                    $plano,
                    $centro,
                    $grupo,
                    $fluxo,
                    $valor,
                    $periodo,
                    $anotacoes,
                    $baixado,
                    $dataBaixa,
                    1,
                    $criadoEm
                );
                """;

                command.Parameters.AddWithValue(
                    "$tipo",
                    tipo);

                command.Parameters.AddWithValue(
                    "$conta",
                    (object?)contaId ??
                    DBNull.Value);

                command.Parameters.AddWithValue(
                    "$dataPagamento",
                    DataParaBanco(
                        dataPagamento));

                command.Parameters.AddWithValue(
                    "$dataEmissao",
                    DataParaBanco(
                        dataEmissao ??
                        dataPagamento ??
                        DateTime.Today));

                command.Parameters.AddWithValue(
                    "$cliente",
                    (object?)clienteId ??
                    DBNull.Value);

                command.Parameters.AddWithValue(
                    "$descricao",
                    string.IsNullOrWhiteSpace(descricao)
                        ? "Importado do Excel"
                        : descricao.Trim());

                command.Parameters.AddWithValue(
                    "$plano",
                    (object?)planoId ??
                    DBNull.Value);

                command.Parameters.AddWithValue(
                    "$centro",
                    (object?)centroId ??
                    DBNull.Value);

                command.Parameters.AddWithValue(
                    "$grupo",
                    (object?)grupoId ??
                    DBNull.Value);

                command.Parameters.AddWithValue(
                    "$fluxo",
                    (object?)fluxoId ??
                    DBNull.Value);

                command.Parameters.AddWithValue(
                    "$valor",
                    valor);

                command.Parameters.AddWithValue(
                    "$periodo",
                    periodo.Trim());

                command.Parameters.AddWithValue(
                    "$anotacoes",
                    anotacoes.Trim());

                command.Parameters.AddWithValue(
                    "$baixado",
                    baixado ? 1 : 0);

                command.Parameters.AddWithValue(
                    "$dataBaixa",
                    baixado
                        ? DataParaBanco(dataPagamento)
                        : DBNull.Value);

                command.Parameters.AddWithValue(
                    "$criadoEm",
                    DateTime.UtcNow.ToString("O"));

                command.ExecuteNonQuery();

                importados++;
            }

            transaction.Commit();

            return importados;
        }
        catch
        {
            transaction.Rollback();
            throw;
        }
    }

    private void AnalisarConsolidado(ZipArchive zip, string caminho, List<string> sharedStrings)
    {
        var mapa = LerPlanoContasConsolidado(zip, sharedStrings);
        var entrada = zip.GetEntry(caminho) ?? throw new Exception("Não foi possível abrir CONSOLIDADO.");
        using var st = entrada.Open();
        var doc = XDocument.Load(st);
        XNamespace ns = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";
        foreach (var linha in doc.Descendants(ns + "row"))
        {
            if (!int.TryParse((string?)linha.Attribute("r"), out int n) || n < 5) continue;
            var c = LerCelulasLinha(linha, ns, sharedStrings);
            var data = LerDataExcel(Obter(c, 1));
            string banco = NormalizarNomeCadastro(Obter(c, 5));
            string plano = NormalizarNomeCadastro(Obter(c, 7));
            if (!DataFinanceiraValida(data) || string.IsNullOrWhiteSpace(banco) || string.IsNullOrWhiteSpace(plano) ||
                !TentarLerDecimal(Obter(c, 4), out decimal valor) || valor == 0) continue;
            mapa.TryGetValue(plano, out var info);
            Adicionar(_contas, banco);
            Adicionar(_planos, plano);
            Adicionar(_centros, NormalizarNomeCadastro(Obter(c, 8)));
            if (info != null) { Adicionar(_grupos, info.Grupo); Adicionar(_fluxos, info.Fluxo); }
            _quantidadeLancamentos++;
        }
        // A prévia também informa os cadastros existentes na aba PLANO DE CONTAS, mesmo sem movimento no CONSOLIDADO.
        foreach (var kv in mapa) { Adicionar(_planos, kv.Key); Adicionar(_grupos, kv.Value.Grupo); Adicionar(_fluxos, kv.Value.Fluxo); }
    }

    private sealed class PlanoImportInfo
    {
        public string Grupo { get; init; } = "";
        public string Fluxo { get; init; } = "";
    }

    private static Dictionary<string, PlanoImportInfo> LerPlanoContasConsolidado(ZipArchive zip, List<string> sharedStrings)
    {
        var r = new Dictionary<string, PlanoImportInfo>(StringComparer.CurrentCultureIgnoreCase);
        string? caminho = LocalizarPlanilhaPorNome(zip, "PLANO DE CONTAS");
        if (string.IsNullOrWhiteSpace(caminho)) return r;
        var entrada = zip.GetEntry(caminho); if (entrada == null) return r;
        using var st = entrada.Open(); var doc = XDocument.Load(st);
        XNamespace ns = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";
        foreach (var linha in doc.Descendants(ns + "row"))
        {
            if (!int.TryParse((string?)linha.Attribute("r"), out int n) || n < 2) continue;
            var c = LerCelulasLinha(linha, ns, sharedStrings);
            string plano = NormalizarNomeCadastro(Obter(c, 2));
            string grupo = NormalizarNomeCadastro(Obter(c, 3));
            string codigo = Obter(c, 4).Trim();
            if (string.IsNullOrWhiteSpace(plano)) continue;
            string fluxo = FluxoPorCodigoDfc(codigo, grupo);
            r[plano] = new PlanoImportInfo { Grupo = grupo, Fluxo = fluxo };
        }
        return r;
    }

    private static string FluxoPorCodigoDfc(string codigo, string grupo)
    {
        if (decimal.TryParse(codigo, NumberStyles.Any, CultureInfo.InvariantCulture, out var cod))
        {
            int c = (int)cod;
            if (c == 1) return "RECEBIMENTO OPERACIONAL";
            if (c == 11) return "INVESTIMENTO (C/D)";
            if (c == 17) return "TRANSFERENCIAS";
            if (c == 2 || c == 3 || c == 6) return "DESP. OPERACIONAIS";
        }
        string n = (grupo ?? "").ToUpperInvariant();
        if (n.Contains("TRANSFER")) return "TRANSFERENCIAS";
        if (n.Contains("INVEST")) return "INVESTIMENTO (C/D)";
        if (n.Contains("RECEB") || n.Contains("RECEITA")) return "RECEBIMENTO OPERACIONAL";
        return "DESP. OPERACIONAIS";
    }

    private int ExecutarImportacaoConsolidado(ZipArchive zip, string caminho, List<string> sharedStrings)
    {
        var mapa = LerPlanoContasConsolidado(zip, sharedStrings);
        var entrada = zip.GetEntry(caminho) ?? throw new Exception("Não foi possível abrir CONSOLIDADO.");
        using var st = entrada.Open(); var doc = XDocument.Load(st);
        XNamespace ns = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";
        using var connection = new SqliteConnection(DatabaseInitializer.ConnectionString); connection.Open();
        using var transaction = connection.BeginTransaction();
        try
        {
            var contas = CarregarCadastros(connection, transaction, "ContasBancarias");
            var clientes = CarregarCadastros(connection, transaction, "ClientesFornecedores");
            var planos = CarregarCadastros(connection, transaction, "PlanosContas");
            var centros = CarregarCadastros(connection, transaction, "CentrosCustos");
            var grupos = CarregarCadastros(connection, transaction, "GruposContas");
            var fluxos = CarregarCadastros(connection, transaction, "FluxosCaixa");

            // Importa a estrutura inteira de PLANO DE CONTAS para os cadastros.
            foreach (var kv in mapa)
            {
                ObterOuCriarCadastro(connection, transaction, "PlanosContas", kv.Key, planos);
                if (!string.IsNullOrWhiteSpace(kv.Value.Grupo)) ObterOuCriarCadastro(connection, transaction, "GruposContas", kv.Value.Grupo, grupos);
                if (!string.IsNullOrWhiteSpace(kv.Value.Fluxo)) ObterOuCriarCadastro(connection, transaction, "FluxosCaixa", kv.Value.Fluxo, fluxos);
            }

            int importados = 0;
            foreach (var linha in doc.Descendants(ns + "row"))
            {
                if (!int.TryParse((string?)linha.Attribute("r"), out int n) || n < 5) continue;
                var c = LerCelulasLinha(linha, ns, sharedStrings);
                DateTime? data = LerDataExcel(Obter(c, 1));
                string descricao = Obter(c, 2).Trim();
                string documento = Obter(c, 3).Trim();
                string valorTexto = Obter(c, 4);
                string banco = NormalizarNomeCadastro(Obter(c, 5));
                string tipoOrigem = Obter(c, 6).Trim().ToUpperInvariant();
                string plano = NormalizarNomeCadastro(Obter(c, 7));
                string centro = NormalizarNomeCadastro(Obter(c, 8));
                string obs = Obter(c, 9).Trim();
                if (!DataFinanceiraValida(data) || string.IsNullOrWhiteSpace(banco) || string.IsNullOrWhiteSpace(plano) ||
                    !TentarLerDecimal(valorTexto, out decimal valor) || valor == 0) continue;

                mapa.TryGetValue(plano, out var info);
                string grupo = info?.Grupo ?? "";
                string fluxo = info?.Fluxo ?? FluxoPorCodigoDfc("", grupo);
                string tipo = tipoOrigem.Contains("TRANSF") ? "Transferência" : (valor < 0 || tipoOrigem.Contains("PAGO") ? "Pagar" : "Receber");
                long? contaId = ObterOuCriarCadastro(connection, transaction, "ContasBancarias", banco, contas);
                long? planoId = ObterOuCriarCadastro(connection, transaction, "PlanosContas", plano, planos);
                long? centroId = ObterOuCriarCadastro(connection, transaction, "CentrosCustos", centro, centros);
                long? grupoId = ObterOuCriarCadastro(connection, transaction, "GruposContas", grupo, grupos);
                long? fluxoId = ObterOuCriarCadastro(connection, transaction, "FluxosCaixa", fluxo, fluxos);
                VincularClassificacaoImportada(connection, transaction, planoId, grupoId, fluxoId, centroId);

                using var cmd = connection.CreateCommand(); cmd.Transaction = transaction;
                cmd.CommandText = @"INSERT INTO Lancamentos
                    (Tipo,ContaBancariaId,DataPagamento,DataEmissao,Descricao,NumeroDocumento,PlanoContasId,CentroCustosId,GrupoContasId,FluxoCaixaId,Valor,Periodo,Anotacoes,Baixado,DataBaixa,Ativo,CriadoEm)
                    VALUES ($tipo,$conta,$data,$data,$descricao,$doc,$plano,$centro,$grupo,$fluxo,$valor,$periodo,$obs,1,$data,1,$criado);";
                cmd.Parameters.AddWithValue("$tipo", tipo); cmd.Parameters.AddWithValue("$conta", (object?)contaId ?? DBNull.Value);
                cmd.Parameters.AddWithValue("$data", DataParaBanco(data)); cmd.Parameters.AddWithValue("$descricao", string.IsNullOrWhiteSpace(descricao)?"Importado do Excel - Consolidado":descricao);
                cmd.Parameters.AddWithValue("$doc", documento); cmd.Parameters.AddWithValue("$plano", (object?)planoId ?? DBNull.Value);
                cmd.Parameters.AddWithValue("$centro", (object?)centroId ?? DBNull.Value); cmd.Parameters.AddWithValue("$grupo", (object?)grupoId ?? DBNull.Value);
                cmd.Parameters.AddWithValue("$fluxo", (object?)fluxoId ?? DBNull.Value); cmd.Parameters.AddWithValue("$valor", valor);
                cmd.Parameters.AddWithValue("$periodo", data!.Value.ToString("MM/yyyy")); cmd.Parameters.AddWithValue("$obs", string.IsNullOrWhiteSpace(obs)?"Importado do Excel - CONSOLIDADO":obs);
                cmd.Parameters.AddWithValue("$criado", DateTime.UtcNow.ToString("O")); cmd.ExecuteNonQuery(); importados++;
            }
            transaction.Commit(); return importados;
        }
        catch { transaction.Rollback(); throw; }
    }

    private static string? LocalizarPlanilhaPorNome(ZipArchive zip, string nomeAba)
    {
        var workbookEntry = zip.GetEntry("xl/workbook.xml"); var relsEntry = zip.GetEntry("xl/_rels/workbook.xml.rels");
        if (workbookEntry == null || relsEntry == null) return null;
        XDocument workbook; using (var st = workbookEntry.Open()) workbook = XDocument.Load(st);
        XNamespace ns = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";
        XNamespace rel = "http://schemas.openxmlformats.org/officeDocument/2006/relationships";
        var aba = workbook.Descendants(ns + "sheet").FirstOrDefault(x => string.Equals(x.Attribute("name")?.Value?.Trim(), nomeAba, StringComparison.CurrentCultureIgnoreCase));
        if (aba == null) return null; string? rid = aba.Attribute(rel + "id")?.Value; if (string.IsNullOrWhiteSpace(rid)) return null;
        XDocument rels; using (var st = relsEntry.Open()) rels = XDocument.Load(st);
        XNamespace rns = "http://schemas.openxmlformats.org/package/2006/relationships";
        var rr = rels.Descendants(rns + "Relationship").FirstOrDefault(x => string.Equals(x.Attribute("Id")?.Value, rid, StringComparison.OrdinalIgnoreCase));
        string? target = rr?.Attribute("Target")?.Value; if (string.IsNullOrWhiteSpace(target)) return null;
        target = target.Replace('\\','/').TrimStart('/'); if (target.StartsWith("xl/", StringComparison.OrdinalIgnoreCase)) return target;
        return "xl/" + target.TrimStart('/');
    }

    private static Dictionary<int, string>
        LerCelulasLinha(
            XElement linha,
            XNamespace ns,
            List<string> sharedStrings)
    {
        var celulas =
            new Dictionary<int, string>();

        foreach (XElement celula in
                 linha.Elements(ns + "c"))
        {
            string referencia =
                celula.Attribute("r")?.Value ?? "";

            int coluna =
                ObterNumeroColuna(referencia);

            if (coluna <= 0)
                continue;

            celulas[coluna] =
                ObterValorCelula(
                    celula,
                    ns,
                    sharedStrings);
        }

        return celulas;
    }

    private static Dictionary<string, long>
        CarregarCadastros(
            SqliteConnection connection,
            SqliteTransaction transaction,
            string tabela)
    {
        var resultado =
            new Dictionary<string, long>(
                StringComparer.CurrentCultureIgnoreCase);

        using var command =
            connection.CreateCommand();

        command.Transaction =
            transaction;

        command.CommandText =
            $"SELECT Id, Nome FROM {tabela};";

        using var reader =
            command.ExecuteReader();

        while (reader.Read())
        {
            string nome =
                reader.IsDBNull(1)
                    ? ""
                    : reader.GetString(1).Trim();

            if (!string.IsNullOrWhiteSpace(nome) &&
                !resultado.ContainsKey(nome))
            {
                resultado[nome] =
                    reader.GetInt64(0);
            }
        }

        return resultado;
    }

    private static long? ObterOuCriarCadastro(
        SqliteConnection connection,
        SqliteTransaction transaction,
        string tabela,
        string nome,
        Dictionary<string, long> cache)
    {
        nome = nome.Trim();

        if (string.IsNullOrWhiteSpace(nome))
            return null;

        if (cache.TryGetValue(
                nome,
                out long idExistente))
        {
            return idExistente;
        }

        using var command =
            connection.CreateCommand();

        command.Transaction =
            transaction;

        if (tabela == "ContasBancarias")
        {
            command.CommandText =
            """
            INSERT INTO ContasBancarias
            (
                Nome,
                Banco,
                Agencia,
                Conta,
                Ativo,
                CriadoEm,
                TipoConta
            )
            VALUES
            (
                $nome,
                '',
                '',
                '',
                1,
                $criadoEm,
                COALESCE((SELECT TipoConta FROM ContaClassificacoesPersistentes WHERE NomeNormalizado=UPPER(TRIM($nome))), 'Conta Bancária')
            );

            SELECT last_insert_rowid();
            """;
        }
        else if (tabela ==
                 "ClientesFornecedores")
        {
            command.CommandText =
            """
            INSERT INTO ClientesFornecedores
            (
                Nome,
                Documento,
                Tipo,
                Ativo,
                CriadoEm
            )
            VALUES
            (
                $nome,
                '',
                '',
                1,
                $criadoEm
            );

            SELECT last_insert_rowid();
            """;
        }
        else
        {
            command.CommandText =
                $"""
                INSERT INTO {tabela}
                (
                    Nome,
                    Ativo,
                    CriadoEm
                )
                VALUES
                (
                    $nome,
                    1,
                    $criadoEm
                );

                SELECT last_insert_rowid();
                """;
        }

        command.Parameters.AddWithValue(
            "$nome",
            nome);

        command.Parameters.AddWithValue(
            "$criadoEm",
            DateTime.UtcNow.ToString("O"));

        long novoId =
            Convert.ToInt64(
                command.ExecuteScalar());

        cache[nome] = novoId;

        return novoId;
    }

    private static void GarantirTabelaClassificacoes(SqliteConnection connection, SqliteTransaction transaction)
    {
        using var command = connection.CreateCommand();
        command.Transaction = transaction;
        command.CommandText = """
        CREATE TABLE IF NOT EXISTS PlanoClassificacoes
        (
            Id INTEGER PRIMARY KEY AUTOINCREMENT,
            PlanoContasId INTEGER NOT NULL,
            GrupoContasId INTEGER NOT NULL,
            FluxoCaixaId INTEGER NOT NULL,
            CentroCustosId INTEGER NULL,
            CriadoEm TEXT NOT NULL,
            UNIQUE(PlanoContasId, GrupoContasId, FluxoCaixaId)
        );
        """;
        command.ExecuteNonQuery();
    }

    private static void VincularClassificacaoImportada(
        SqliteConnection connection,
        SqliteTransaction transaction,
        long? planoId,
        long? grupoId,
        long? fluxoId,
        long? centroId)
    {
        if (!planoId.HasValue || !grupoId.HasValue || !fluxoId.HasValue)
            return;

        GarantirTabelaClassificacoes(connection, transaction);

        using var command = connection.CreateCommand();
        command.Transaction = transaction;
        command.CommandText = """
        INSERT INTO PlanoClassificacoes
            (PlanoContasId, GrupoContasId, FluxoCaixaId, CentroCustosId, CriadoEm)
        VALUES
            ($plano, $grupo, $fluxo, $centro, $criadoEm)
        ON CONFLICT(PlanoContasId, GrupoContasId, FluxoCaixaId) DO UPDATE SET
            CentroCustosId = COALESCE(excluded.CentroCustosId, PlanoClassificacoes.CentroCustosId);
        """;
        command.Parameters.AddWithValue("$plano", planoId.Value);
        command.Parameters.AddWithValue("$grupo", grupoId.Value);
        command.Parameters.AddWithValue("$fluxo", fluxoId.Value);
        command.Parameters.AddWithValue("$centro", (object?)centroId ?? DBNull.Value);
        command.Parameters.AddWithValue("$criadoEm", DateTime.UtcNow.ToString("O"));
        command.ExecuteNonQuery();
    }

    private static List<string> LerSharedStrings(
        ZipArchive zip)
    {
        var resultado =
            new List<string>();

        ZipArchiveEntry? entrada =
            zip.GetEntry(
                "xl/sharedStrings.xml");

        if (entrada == null)
            return resultado;

        using Stream stream =
            entrada.Open();

        XDocument documento =
            XDocument.Load(stream);

        XNamespace ns =
            "http://schemas.openxmlformats.org/spreadsheetml/2006/main";

        foreach (XElement item in
                 documento.Descendants(ns + "si"))
        {
            string texto =
                string.Concat(
                    item.Descendants(ns + "t")
                        .Select(x => x.Value));

            resultado.Add(texto);
        }

        return resultado;
    }

    private static string?
        LocalizarPlanilhaLancamentos(
            ZipArchive zip)
    {
        ZipArchiveEntry? workbookEntry =
            zip.GetEntry(
                "xl/workbook.xml");

        ZipArchiveEntry? relsEntry =
            zip.GetEntry(
                "xl/_rels/workbook.xml.rels");

        if (workbookEntry == null ||
            relsEntry == null)
        {
            return null;
        }

        XDocument workbook;

        using (Stream stream =
               workbookEntry.Open())
        {
            workbook =
                XDocument.Load(stream);
        }

        XNamespace ns =
            "http://schemas.openxmlformats.org/spreadsheetml/2006/main";

        XNamespace rel =
            "http://schemas.openxmlformats.org/officeDocument/2006/relationships";

        XElement? aba =
            workbook
                .Descendants(ns + "sheet")
                .FirstOrDefault(x =>
                    string.Equals(
                        x.Attribute("name")?
                            .Value?
                            .Trim(),
                        "LANÇAMENTOS",
                        StringComparison
                            .CurrentCultureIgnoreCase));

        if (aba == null)
            return null;

        string? relationshipId =
            aba.Attribute(rel + "id")?
                .Value;

        if (string.IsNullOrWhiteSpace(
                relationshipId))
        {
            return null;
        }

        XDocument rels;

        using (Stream stream =
               relsEntry.Open())
        {
            rels =
                XDocument.Load(stream);
        }

        XNamespace relNs =
            "http://schemas.openxmlformats.org/package/2006/relationships";

        XElement? relacionamento =
            rels
                .Descendants(
                    relNs + "Relationship")
                .FirstOrDefault(x =>
                    string.Equals(
                        x.Attribute("Id")?.Value,
                        relationshipId,
                        StringComparison
                            .OrdinalIgnoreCase));

        string? target =
            relacionamento?
                .Attribute("Target")?
                .Value;

        if (string.IsNullOrWhiteSpace(target))
            return null;

        target =
            target.Replace("\\", "/");

        if (target.StartsWith("/"))
            return target.TrimStart('/');

        while (target.StartsWith("../"))
            target = target.Substring(3);

        if (target.StartsWith("xl/"))
            return target;

        return "xl/" +
               target.TrimStart('/');
    }

    private static string ObterValorCelula(
        XElement celula,
        XNamespace ns,
        List<string> sharedStrings)
    {
        string tipo =
            celula.Attribute("t")?.Value ?? "";

        if (tipo == "inlineStr")
        {
            return string.Concat(
                    celula
                        .Descendants(ns + "t")
                        .Select(x => x.Value))
                .Trim();
        }

        XElement? valorElement =
            celula.Element(ns + "v");

        if (valorElement == null)
            return string.Empty;

        string valor =
            valorElement.Value.Trim();

        if (tipo == "s")
        {
            if (int.TryParse(
                    valor,
                    NumberStyles.Integer,
                    CultureInfo.InvariantCulture,
                    out int indice) &&
                indice >= 0 &&
                indice < sharedStrings.Count)
            {
                return sharedStrings[indice]
                    .Trim();
            }

            return string.Empty;
        }

        if (tipo == "b")
        {
            return valor == "1"
                ? "TRUE"
                : "FALSE";
        }

        return valor;
    }

    private static int ObterNumeroColuna(
        string referencia)
    {
        if (string.IsNullOrWhiteSpace(
                referencia))
        {
            return 0;
        }

        int coluna = 0;

        foreach (char caractere in referencia)
        {
            if (!char.IsLetter(caractere))
                break;

            coluna =
                coluna * 26 +
                (char.ToUpperInvariant(caractere) -
                 'A' + 1);
        }

        return coluna;
    }

    private static string Obter(
        Dictionary<int, string> celulas,
        int coluna)
    {
        return celulas.TryGetValue(
            coluna,
            out string? valor)
            ? valor.Trim()
            : string.Empty;
    }

    private static string NormalizarNomeCadastro(string texto)
    {
        string valor = (texto ?? "").Trim();
        if (string.IsNullOrWhiteSpace(valor))
            return string.Empty;

        // Plano/Centro/Grupo/Fluxo são campos textuais.
        // Valores puramente numéricos são resultados/caches de fórmulas do Excel
        // e nunca devem virar cadastros.
        string teste = valor.Replace("R$", "").Replace(" ", "").Trim();
        if (decimal.TryParse(teste, NumberStyles.Any, CultureInfo.InvariantCulture, out _) ||
            decimal.TryParse(teste, NumberStyles.Any, new CultureInfo("pt-BR"), out _))
            return string.Empty;

        return valor;
    }

    private static bool EhLinhaDeLancamento(
        string conta,
        string cliente,
        string descricao,
        string plano,
        string centro,
        string valor,
        string grupo,
        string fluxo)
    {
        if (string.IsNullOrWhiteSpace(conta))
            return false;

        if (string.Equals(
                conta,
                "CONTAS BANCÁRIAS",
                StringComparison
                    .CurrentCultureIgnoreCase))
        {
            return false;
        }

        if (string.Equals(
                cliente,
                "CLIENTES/FORNECEDORES",
                StringComparison
                    .CurrentCultureIgnoreCase))
        {
            return false;
        }

        if (string.Equals(
                plano,
                "PLANO DE CONTA",
                StringComparison
                    .CurrentCultureIgnoreCase))
        {
            return false;
        }

        bool possuiDados =
            !string.IsNullOrWhiteSpace(conta) ||
            !string.IsNullOrWhiteSpace(cliente) ||
            !string.IsNullOrWhiteSpace(descricao) ||
            !string.IsNullOrWhiteSpace(plano) ||
            !string.IsNullOrWhiteSpace(centro) ||
            !string.IsNullOrWhiteSpace(grupo) ||
            !string.IsNullOrWhiteSpace(fluxo);

        if (!possuiDados)
            return false;

        return PossuiValor(valor);
    }

    private static bool PossuiValor(
        string valor)
    {
        return TentarLerDecimal(
            valor,
            out _);
    }

    private static bool TentarLerDecimal(
        string texto,
        out decimal valor)
    {
        valor = 0;

        if (string.IsNullOrWhiteSpace(texto))
            return false;

        string limpo =
            texto
                .Replace("R$", "")
                .Replace(" ", "")
                .Trim();

        if (decimal.TryParse(
                limpo,
                NumberStyles.Any,
                CultureInfo.InvariantCulture,
                out valor))
        {
            return true;
        }

        return decimal.TryParse(
            limpo,
            NumberStyles.Any,
            new CultureInfo("pt-BR"),
            out valor);
    }

    private static DateTime? LerDataExcel(
        string texto)
    {
        if (string.IsNullOrWhiteSpace(texto))
            return null;

        if (double.TryParse(
                texto,
                NumberStyles.Any,
                CultureInfo.InvariantCulture,
                out double numero))
        {
            try
            {
                return DateTime
                    .FromOADate(numero)
                    .Date;
            }
            catch
            {
            }
        }

        if (DateTime.TryParse(
                texto,
                new CultureInfo("pt-BR"),
                DateTimeStyles.None,
                out DateTime dataBr))
        {
            return dataBr.Date;
        }

        if (DateTime.TryParse(
                texto,
                CultureInfo.InvariantCulture,
                DateTimeStyles.None,
                out DateTime data))
        {
            return data.Date;
        }

        return null;
    }

    private static bool PareceNumero(string texto)
    {
        return TentarLerDecimal((texto ?? string.Empty).Trim(), out _);
    }

    private static string TextoCadastroSeguro(string texto)
    {
        string valor = NormalizarNomeCadastro(texto);
        if (string.IsNullOrWhiteSpace(valor) || PareceNumero(valor))
            return string.Empty;
        return valor;
    }

    private static string PeriodoSeguro(string texto, bool baixado, DateTime? dataPagamento)
    {
        string valor = (texto ?? string.Empty).Trim();
        if (DateTime.TryParseExact(valor, new[] { "MM/yyyy", "MM/yyyy ", "yyyy-MM" },
                CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime p))
            return p.ToString("MM/yyyy", CultureInfo.InvariantCulture);

        return baixado && dataPagamento.HasValue
            ? dataPagamento.Value.ToString("MM/yyyy", CultureInfo.InvariantCulture)
            : string.Empty;
    }

    private static bool InterpretarBaixa(
        string texto)
    {
        string valor =
            texto.Trim()
                .ToUpperInvariant();

        return
            valor == "SIM" ||
            valor == "S" ||
            valor == "TRUE" ||
            valor == "VERDADEIRO" ||
            valor == "1" ||
            valor == "BAIXADO" ||
            valor == "BAIXADA" ||
            valor == "PAGO" ||
            valor == "PAGA" ||
            valor == "RECEBIDO" ||
            valor == "RECEBIDA";
    }

    private static bool TipoOperacaoValido(string tipoExcel)
    {
        string tipo = (tipoExcel ?? string.Empty).Trim().ToUpperInvariant();
        return tipo == "PAGAR" || tipo == "RECEBER" ||
               tipo == "DESPESA" || tipo == "RECEITA" ||
               tipo == "DÉBITO" || tipo == "DEBITO" ||
               tipo == "CRÉDITO" || tipo == "CREDITO";
    }

    private static bool DataFinanceiraValida(DateTime? data)
    {
        return data.HasValue && data.Value.Year >= 2000 && data.Value.Year <= 2100;
    }

    private static string NormalizarTipo(
        string tipoExcel,
        decimal valor)
    {
        string tipo = (tipoExcel ?? string.Empty).Trim().ToUpperInvariant();
        if (tipo == "RECEBER" || tipo == "RECEITA" || tipo == "CRÉDITO" || tipo == "CREDITO")
            return "Receber";
        if (tipo == "PAGAR" || tipo == "DESPESA" || tipo == "DÉBITO" || tipo == "DEBITO")
            return "Pagar";
        return valor < 0 ? "Pagar" : "Receber";
    }

    private static object DataParaBanco(
        DateTime? data)
    {
        return data.HasValue
            ? data.Value.ToString("O")
            : DBNull.Value;
    }

    private static void Adicionar(
        HashSet<string> lista,
        string valor)
    {
        if (!string.IsNullOrWhiteSpace(valor))
            lista.Add(valor.Trim());
    }

    private void AtualizarPrevia()
    {
        LblContas.Text =
            _contas.Count.ToString();

        LblClientes.Text =
            _clientes.Count.ToString();

        LblPlanos.Text =
            _planos.Count.ToString();

        LblCentros.Text =
            _centros.Count.ToString();

        LblGrupos.Text =
            _grupos.Count.ToString();

        LblFluxos.Text =
            _fluxos.Count.ToString();

        LblLancamentos.Text =
            _quantidadeLancamentos.ToString();
    }

    private void LimparPrevia()
    {
        _contas.Clear();
        _clientes.Clear();
        _planos.Clear();
        _centros.Clear();
        _grupos.Clear();
        _fluxos.Clear();

        _quantidadeLancamentos = 0;

        AtualizarPrevia();
    }

    private void Cancelar_Click(
        object sender,
        RoutedEventArgs e)
    {
        Close();
    }
}