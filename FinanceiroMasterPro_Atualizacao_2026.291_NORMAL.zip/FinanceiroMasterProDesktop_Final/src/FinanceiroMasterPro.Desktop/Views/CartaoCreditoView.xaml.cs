﻿using FinanceiroMasterPro.Infrastructure.Data;
using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace FinanceiroMasterPro.Desktop.Views;
public partial class CartaoCreditoView : UserControl
{
 readonly ContaBancariaRepository _contas=new(); readonly LancamentoRepository _lanc=new();
 List<ContaBancaria> _cartoes=new(); ContaBancaria? _cartao; bool _carregandoFatura;
 readonly HashSet<string> _fechadas=new(StringComparer.OrdinalIgnoreCase);
 readonly HashSet<string> _pagas=new(StringComparer.OrdinalIgnoreCase);
 string _modoFatura="ABERTA";
 string ArquivoEstadoFaturas => System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"FinanceiroMasterPro","EstadosFaturasCartao.txt");
 void CarregarEstadosFaturas(){
  try{if(!System.IO.File.Exists(ArquivoEstadoFaturas))return;foreach(var l in System.IO.File.ReadAllLines(ArquivoEstadoFaturas)){var p=l.Split('|');if(p.Length!=3)continue;var k=p[0]+"|"+p[1];if(p[2]=="PAGA")_pagas.Add(k);else if(p[2]=="FECHADA")_fechadas.Add(k);}}catch{}
 }
 void SalvarEstadosFaturas(){
  try{System.IO.Directory.CreateDirectory(System.IO.Path.GetDirectoryName(ArquivoEstadoFaturas)!);var l=_fechadas.Select(k=>k+"|FECHADA").Concat(_pagas.Select(k=>k+"|PAGA")).Distinct();System.IO.File.WriteAllLines(ArquivoEstadoFaturas,l);}catch{}
 }
 public CartaoCreditoView(long? cartaoId=null){InitializeComponent();Loaded+=(_,__)=>{CarregarEstadosFaturas();Carregar(cartaoId);CarregarLayoutCartao();};Unloaded+=(_,__)=>{SalvarLayoutCartao();SalvarEstadosFaturas();};}
 void Carregar(long? id){_cartoes=_contas.Listar().Where(x=>x.Ativo&&x.TipoConta=="Cartão de Crédito").ToList();ListaCartoes.ItemsSource=_cartoes;ListaCartoes.SelectedItem=_cartoes.FirstOrDefault(x=>x.Id==id)??_cartoes.FirstOrDefault();}
 void Cartao_Changed(object s,SelectionChangedEventArgs e){
   _cartao=ListaCartoes.SelectedItem as ContaBancaria;
   _carregandoFatura=true;CmbFatura.SelectedItem=null;_carregandoFatura=false;
   CorrigirVencimentosParcelasDoCartao();CarregarFaturas();
 }
  static DateTime Pascoa(int ano){int a=ano%19,b=ano/100,c=ano%100,d=b/4,e=b%4,f=(b+8)/25,g=(b-f+1)/3,h=(19*a+b-d-g+15)%30,i=c/4,k=c%4,l=(32+2*e+2*i-h-k)%7,m=(a+11*h+22*l)/451;return new DateTime(ano,(h+l-7*m+114)/31,((h+l-7*m+114)%31)+1);}
  static bool FeriadoNacional(DateTime d){var fixos=new[]{(1,1),(4,21),(5,1),(9,7),(10,12),(11,2),(11,15),(11,20),(12,25)};if(fixos.Any(x=>x.Item1==d.Month&&x.Item2==d.Day))return true;var p=Pascoa(d.Year);return d.Date==p.AddDays(-48).Date||d.Date==p.AddDays(-47).Date||d.Date==p.AddDays(-2).Date||d.Date==p.AddDays(60).Date;}
  static DateTime ProximoDiaUtil(DateTime d){while(d.DayOfWeek==DayOfWeek.Saturday||d.DayOfWeek==DayOfWeek.Sunday||FeriadoNacional(d))d=d.AddDays(1);return d;}
  string ChaveFatura(DateTime d)=>d.ToString("MM/yyyy");
 void CarregarFaturas(){
   if(_cartao==null)return;
   var itens=_lanc.Listar().Where(x=>x.Ativo&&x.ContaBancariaId==_cartao.Id).ToList();
   var grupos=itens.GroupBy(x=>ChaveFatura(x.DataPagamento??x.DataEmissao)).ToList();
   foreach(var g in grupos){
     string k=_cartao.Id+"|"+g.Key;
     if(g.Any() && g.All(x=>x.Baixado)){_pagas.Add(k);_fechadas.Remove(k);}
   }
   var atual=CmbFatura.SelectedItem?.ToString();
   bool Mostrar(string fat){string k=_cartao.Id+"|"+fat;return _modoFatura=="PAGA"?_pagas.Contains(k):_modoFatura=="FECHADA"?(_fechadas.Contains(k)&&!_pagas.Contains(k)):(!_fechadas.Contains(k)&&!_pagas.Contains(k));}
   var faturas=grupos.Select(g=>g.Key).Where(Mostrar)
     .Select(z=>DateTime.ParseExact("01/"+z,"dd/MM/yyyy",CultureInfo.GetCultureInfo("pt-BR")))
     .OrderBy(z=>z).Select(ChaveFatura).ToList();
   _carregandoFatura=true;CmbFatura.ItemsSource=faturas;
   // A fatura principal de cada cartão é a mais antiga que ainda está realmente ABERTA.
   // A lista visual continua decrescente, mas a seleção automática respeita a pendência mais antiga.
   string? primeiraAberta=faturas
      .Select(z=>new { Texto=z, Data=DateTime.ParseExact("01/"+z,"dd/MM/yyyy",CultureInfo.GetCultureInfo("pt-BR")) })
      .OrderBy(z=>z.Data)
      .Select(z=>z.Texto)
      .FirstOrDefault();
   CmbFatura.SelectedItem=atual!=null&&faturas.Contains(atual)?atual:primeiraAberta;
   _carregandoFatura=false;
   if(CmbFatura.SelectedItem==null){GridFatura.ItemsSource=null;TxtFatura.Text="0,00";TxtStatusFatura.Text=_modoFatura;TxtRodape.Text="Nenhuma fatura nesta situação.";return;}
   Atualizar();SalvarEstadosFaturas();
 }
 void Abertas_Click(object s,RoutedEventArgs e){_modoFatura="ABERTA";EstiloAbas();CarregarFaturas();}
 void Fechadas_Click(object s,RoutedEventArgs e){_modoFatura="FECHADA";EstiloAbas();CarregarFaturas();}
 void Pagas_Click(object s,RoutedEventArgs e){_modoFatura="PAGA";EstiloAbas();CarregarFaturas();}
 void EstiloAbas(){
   foreach(var b in new[]{BtnAbertas,BtnFechadas,BtnPagas}){b.Background=System.Windows.Media.Brushes.LightGray;b.Foreground=System.Windows.Media.Brushes.Black;}
   var a=_modoFatura=="ABERTA"?BtnAbertas:_modoFatura=="FECHADA"?BtnFechadas:BtnPagas;a.Background=new System.Windows.Media.SolidColorBrush(System.Windows.Media.Color.FromRgb(20,124,193));a.Foreground=System.Windows.Media.Brushes.White;
 }
 void Fatura_Changed(object s,SelectionChangedEventArgs e){
   if(_carregandoFatura)return;
   if(TxtPesquisaAvancada!=null && !string.IsNullOrEmpty(TxtPesquisaAvancada.Text)){TxtPesquisaAvancada.Clear();return;}
   Atualizar();
 }
  void CorrigirVencimentosParcelasDoCartao(){
    if(_cartao==null||!_cartao.DiaVencimento.HasValue)return;
    var todos=_lanc.Listar().Where(x=>x.Ativo&&x.ContaBancariaId==_cartao.Id&&x.DataPagamento.HasValue).ToList();
    foreach(var z in todos){
      var atual=z.DataPagamento!.Value;
      int dia=Math.Min(_cartao.DiaVencimento.Value,DateTime.DaysInMonth(atual.Year,atual.Month));
      var correto=ProximoDiaUtil(new DateTime(atual.Year,atual.Month,dia));
      if(atual.Date==correto.Date)continue;
      z.DataPagamento=correto;z.Periodo=correto.ToString("MM/yyyy");_lanc.Salvar(z);
    }
  }

 void Atualizar(){
   if(_cartao==null||CmbFatura.SelectedItem==null)return;
   Titulo.Text="CARTÃO DE CRÉDITO — "+_cartao.Nome;
   var todos=_lanc.Listar().Where(x=>x.Ativo&&x.ContaBancariaId==_cartao.Id).ToList();
   string fat=CmbFatura.SelectedItem.ToString()!;
   var itens=todos.Where(x=>ChaveFatura(x.DataPagamento??x.DataEmissao)==fat).OrderByDescending(x=>x.DataPagamento??x.DataEmissao).ToList();
   GridFatura.ItemsSource=itens.Select(x=>new Linha(x)).ToList();
   decimal fatura=itens.Where(x=>!x.Baixado&&x.Tipo.Equals("Pagar",StringComparison.OrdinalIgnoreCase)).Sum(x=>Math.Abs(x.Valor));
   decimal total=todos.Where(x=>!x.Baixado&&x.Tipo.Equals("Pagar",StringComparison.OrdinalIgnoreCase)).Sum(x=>Math.Abs(x.Valor));
   TxtFatura.Text=fatura.ToString("N2",CultureInfo.GetCultureInfo("pt-BR"));
   TxtSaldoTotal.Text=total.ToString("N2",CultureInfo.GetCultureInfo("pt-BR"));
   TxtSaldoAtualCartao.Text="Fatura selecionada: "+fat+"  •  Saldo: "+TxtFatura.Text;
   TxtLimite.Text=_cartao.LimiteCredito.ToString("N2",CultureInfo.GetCultureInfo("pt-BR"));
   TxtDisponivel.Text=(_cartao.LimiteCredito-total).ToString("N2",CultureInfo.GetCultureInfo("pt-BR"));
   var dt=DateTime.ParseExact("01/"+fat,"dd/MM/yyyy",CultureInfo.GetCultureInfo("pt-BR"));
   int dia=Math.Min(_cartao.DiaVencimento??1,DateTime.DaysInMonth(dt.Year,dt.Month));
   TxtVencimento.Text=ProximoDiaUtil(new DateTime(dt.Year,dt.Month,dia)).ToString("dd/MM/yyyy");
   string chave=_cartao.Id+"|"+fat;TxtStatusFatura.Text=_pagas.Contains(chave)?"PAGA":_fechadas.Contains(chave)?"FECHADA":"ABERTA";
   TxtRodape.Text=$"{itens.Count} lançamento(s)  •  Fatura {fat}: {TxtFatura.Text}  •  Total aberto do cartão: {TxtSaldoTotal.Text}";
 }
 void FecharFatura_Click(object s,RoutedEventArgs e){
   if(_cartao==null||CmbFatura.SelectedItem==null)return;string fat=CmbFatura.SelectedItem.ToString()!;_fechadas.Add(_cartao.Id+"|"+fat);_pagas.Remove(_cartao.Id+"|"+fat);SalvarEstadosFaturas();_modoFatura="ABERTA";EstiloAbas();CarregarFaturas();
 }
 void ReabrirFatura_Click(object s,RoutedEventArgs e){
   if(_cartao==null||CmbFatura.SelectedItem==null)return;
   string fat=CmbFatura.SelectedItem.ToString()!;string chave=_cartao.Id+"|"+fat;
   if(_pagas.Contains(chave)){MessageBox.Show("Esta fatura está PAGA. Para reabri-la, use CANCELAR PAGAMENTO.","Cartão de Crédito",MessageBoxButton.OK,MessageBoxImage.Information);return;}
   if(!_fechadas.Contains(chave)){MessageBox.Show("Selecione uma fatura FECHADA para reabrir.","Cartão de Crédito",MessageBoxButton.OK,MessageBoxImage.Information);return;}
   if(MessageBox.Show($"Reabrir a fatura {fat}?\n\nEla sairá de FATURAS FECHADAS e voltará para FATURAS ABERTAS. As compras e valores serão mantidos.","Reabrir fatura",MessageBoxButton.YesNo,MessageBoxImage.Question)!=MessageBoxResult.Yes)return;
   _fechadas.Remove(chave);_pagas.Remove(chave);SalvarEstadosFaturas();
   _modoFatura="ABERTA";EstiloAbas();CarregarFaturas();
   CmbFatura.SelectedItem=fat;Atualizar();
 }
 void PagarFatura_Click(object s,RoutedEventArgs e){
   if(_cartao==null||CmbFatura.SelectedItem==null)return;
   string fat=CmbFatura.SelectedItem.ToString()!;string chave=_cartao.Id+"|"+fat;
   // Mantém o estado visual da fatura e a situação dos lançamentos coerentes.
   var itens=_lanc.Listar().Where(x=>x.Ativo&&x.ContaBancariaId==_cartao.Id&&ChaveFatura(x.DataPagamento??x.DataEmissao)==fat).ToList();
   foreach(var z in itens){if(!z.Baixado){z.Baixado=true;_lanc.Salvar(z);}}
   _fechadas.Remove(chave);_pagas.Add(chave);SalvarEstadosFaturas();
   _modoFatura="PAGA";EstiloAbas();CarregarFaturas();
 }
 void CancelarPagamentoFatura_Click(object s,RoutedEventArgs e){
   if(_cartao==null||CmbFatura.SelectedItem==null)return;
   string fat=CmbFatura.SelectedItem.ToString()!;string chave=_cartao.Id+"|"+fat;
   if(!_pagas.Contains(chave)){MessageBox.Show("Selecione uma fatura paga para cancelar o pagamento.","Cartão de Crédito",MessageBoxButton.OK,MessageBoxImage.Information);return;}
   if(MessageBox.Show($"Cancelar o pagamento da fatura {fat}?\n\nA fatura voltará para FATURAS ABERTAS e as compras não serão apagadas.","Cancelar pagamento da fatura",MessageBoxButton.YesNo,MessageBoxImage.Question)!=MessageBoxResult.Yes)return;
   var itens=_lanc.Listar().Where(x=>x.Ativo&&x.ContaBancariaId==_cartao.Id&&ChaveFatura(x.DataPagamento??x.DataEmissao)==fat).ToList();
   foreach(var z in itens){if(z.Baixado){z.Baixado=false;_lanc.Salvar(z);}}
   _pagas.Remove(chave);_fechadas.Remove(chave);SalvarEstadosFaturas();
   _modoFatura="ABERTA";EstiloAbas();CarregarFaturas();
   CmbFatura.SelectedItem=fat;Atualizar();
 }
 void AvancarFatura(){
   if(_cartao==null)return;var atual=CmbFatura.SelectedIndex;
   for(int i=atual+1;i<CmbFatura.Items.Count;i++){var z=CmbFatura.Items[i]?.ToString();if(z!=null&&!_fechadas.Contains(_cartao.Id+"|"+z)){CmbFatura.SelectedIndex=i;return;}}
   Atualizar();
 }

 bool CombinaPesquisa(Lancamento z,string p)=>PesquisaAvancada.Texto(z.Descricao,p)||PesquisaAvancada.Texto(z.NumeroDocumento,p)||PesquisaAvancada.Texto(z.ClienteFornecedorNome,p)||PesquisaAvancada.Texto(z.ContaBancariaNome,p)||PesquisaAvancada.Texto(z.PlanoContasNome,p)||PesquisaAvancada.Texto(z.CentroCustosNome,p)||PesquisaAvancada.Texto(z.GrupoContasNome,p)||PesquisaAvancada.Texto(z.FluxoCaixaNome,p)||PesquisaAvancada.Texto(z.Periodo,p)||PesquisaAvancada.Texto(z.Anotacoes,p)||PesquisaAvancada.Texto(z.Tipo,p)||PesquisaAvancada.Valor(z.Valor,p)||PesquisaAvancada.Valor(z.Tipo.Equals("Pagar",StringComparison.OrdinalIgnoreCase)?-Math.Abs(z.Valor):Math.Abs(z.Valor),p)||PesquisaAvancada.Data(z.DataPagamento,p)||PesquisaAvancada.Data(z.DataEmissao,p);
 void PesquisaCartao_TextChanged(object s,TextChangedEventArgs e){
   if(TxtPesquisaAvancada==null||_cartao==null||CmbFatura.SelectedItem==null)return;
   var p=TxtPesquisaAvancada.Text.Trim();
   if(string.IsNullOrWhiteSpace(p)){Atualizar();return;}
   string fat=CmbFatura.SelectedItem.ToString()!;
   var r=_lanc.Listar()
     .Where(z=>z.Ativo&&z.ContaBancariaId==_cartao.Id&&ChaveFatura(z.DataPagamento??z.DataEmissao)==fat)
     .Where(z=>CombinaPesquisa(z,p))
     .OrderByDescending(z=>z.DataPagamento??z.DataEmissao).ToList();
   GridFatura.ItemsSource=r.Select(z=>new Linha(z)).ToList();
   TxtRodape.Text=$"Fatura {fat}: {r.Count} resultado(s) para “{p}”";
 }
 void LimparPesquisa_Click(object s,RoutedEventArgs e){TxtPesquisaAvancada.Clear();Atualizar();}

 void NovoLancamento_Click(object s,RoutedEventArgs e){if(_cartao==null)return;(Window.GetWindow(this) as MainWindow)?.AbrirNovoLancamentoCartao(_cartao.Id);}
 void GridFatura_DoubleClick(object s,MouseButtonEventArgs e){
   if(GridFatura.SelectedItem is not Linha linha)return;
   (Window.GetWindow(this) as MainWindow)?.AbrirLancamentoPorId(linha.Id);
 }
 void EditarCartao_Click(object s,RoutedEventArgs e){if(_cartao==null)return;var v=new ContaBancariaView("Cartão de Crédito");v.SelecionarConta(_cartao.Id);(Window.GetWindow(this) as MainWindow)?.AbrirView(v);}
 void CriarCartao_Click(object s,RoutedEventArgs e){(Window.GetWindow(this) as MainWindow)?.AbrirView(new ContaBancariaView("Cartão de Crédito"));}

 void Conciliacao_Click(object s,RoutedEventArgs e){if((s as CheckBox)?.DataContext is Linha l) l.Conciliado=!l.Conciliado; /* conferência visual: não altera saldo/baixa */ }
 void Transferir_Click(object s,RoutedEventArgs e){
   if(GridFatura.SelectedItem is not Linha l){MessageBox.Show("Selecione o lançamento que deseja transferir.","Cartão de Crédito");return;}
   var destinos=_cartoes.Where(x=>x.Id!=_cartao?.Id).ToList(); if(destinos.Count==0){MessageBox.Show("Não existe outro cartão cadastrado.");return;}
   var w=new Window{Title="Transferir entre cartões",Width=420,Height=230,WindowStartupLocation=WindowStartupLocation.CenterOwner,Owner=Window.GetWindow(this),ResizeMode=ResizeMode.NoResize};
   var sp=new StackPanel{Margin=new Thickness(18)}; sp.Children.Add(new TextBlock{Text=$"{l.Descricao}  •  {l.ValorTexto}",FontWeight=FontWeights.Bold,Margin=new Thickness(0,0,0,12)});
   sp.Children.Add(new TextBlock{Text="Transferir para:"}); var cb=new ComboBox{ItemsSource=destinos,DisplayMemberPath="Nome",Margin=new Thickness(0,5,0,15)};cb.SelectedIndex=0;sp.Children.Add(cb);
   var all=new CheckBox{Content="Transferir também as demais parcelas deste lançamento",Margin=new Thickness(0,0,0,15)};sp.Children.Add(all);
   var bt=new Button{Content="TRANSFERIR",Padding=new Thickness(15,7,15,7),HorizontalAlignment=HorizontalAlignment.Right};sp.Children.Add(bt);w.Content=sp;
   bt.Click+=(_,__)=>{if(cb.SelectedItem is not ContaBancaria d)return;var itens=_lanc.Listar();var alvo=itens.FirstOrDefault(x=>x.Id==l.Id);if(alvo==null)return;
      var mudar=all.IsChecked==true?ParcelasRelacionadas(itens,alvo):new List<Lancamento>{alvo};foreach(var z in mudar){z.ContaBancariaId=d.Id;_lanc.Salvar(z);}w.DialogResult=true;}; if(w.ShowDialog()==true)CarregarFaturas();
 }
 void AjustarParcelas_Click(object s,RoutedEventArgs e){
   if(GridFatura.SelectedItem is not Linha l){MessageBox.Show("Selecione uma parcela para ajustar.","Cartão de Crédito");return;}var itens=_lanc.Listar();var alvo=itens.FirstOrDefault(x=>x.Id==l.Id);if(alvo==null)return;
   var rel=ParcelasRelacionadas(itens,alvo).OrderBy(x=>x.DataPagamento).ToList();var nova=alvo.DataPagamento??DateTime.Today;
   var dlg=new Window{Title="Ajuste de parcelas",Width=470,Height=260,WindowStartupLocation=WindowStartupLocation.CenterOwner,Owner=Window.GetWindow(this),ResizeMode=ResizeMode.NoResize};
   var sp=new StackPanel{Margin=new Thickness(18)};sp.Children.Add(new TextBlock{Text=$"Parcela selecionada: {alvo.Descricao}",FontWeight=FontWeights.Bold});sp.Children.Add(new TextBlock{Text="Nova data/vencimento:",Margin=new Thickness(0,12,0,4)});
   var dp=new DatePicker{SelectedDate=nova};sp.Children.Add(dp);var all=new CheckBox{Content=$"Ajustar esta e as demais parcelas deste lançamento ({rel.Count} parcela(s) relacionadas)",IsChecked=true,Margin=new Thickness(0,15,0,15)};sp.Children.Add(all);
   var bt=new Button{Content="CONFIRMAR AJUSTE",Padding=new Thickness(15,7,15,7),HorizontalAlignment=HorizontalAlignment.Right};sp.Children.Add(bt);dlg.Content=sp;
   bt.Click+=(_,__)=>{if(dp.SelectedDate is not DateTime nd)return;var deltaMes=(nd.Year-nova.Year)*12+nd.Month-nova.Month;var deltaDias=nd.Day-nova.Day;var mudar=all.IsChecked==true?rel.Where(x=>(x.DataPagamento??DateTime.MinValue)>=nova).ToList():new List<Lancamento>{alvo};
      foreach(var z in mudar){var od=z.DataPagamento??z.DataEmissao;z.DataPagamento=od.AddMonths(deltaMes).AddDays(deltaDias);z.Periodo=z.DataPagamento.Value.ToString("MM/yyyy");_lanc.Salvar(z);}dlg.DialogResult=true;};if(dlg.ShowDialog()==true)CarregarFaturas();
 }
 static List<Lancamento> ParcelasRelacionadas(List<Lancamento> itens,Lancamento alvo){
   string Base(string v)=>System.Text.RegularExpressions.Regex.Replace(v??"",@"\s*\(\d+\s*/\s*\d+\)\s*$","").Trim();
   var b=Base(alvo.Descricao);return itens.Where(x=>x.Ativo&&x.ContaBancariaId==alvo.ContaBancariaId&&Base(x.Descricao).Equals(b,StringComparison.OrdinalIgnoreCase)&&x.ClienteFornecedorId==alvo.ClienteFornecedorId).ToList();
 }

 string ArquivoLayoutCartao => System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"FinanceiroMasterPro","GridCartaoLayout.txt");
 void CarregarLayoutCartao(){
  try{
   if(!System.IO.File.Exists(ArquivoLayoutCartao))return;
   var d=System.IO.File.ReadAllLines(ArquivoLayoutCartao).Select(z=>z.Split('|')).Where(z=>z.Length==3).ToList();
   foreach(var c in GridFatura.Columns){var p=d.FirstOrDefault(z=>z[0]==(c.Header?.ToString()??""));if(p!=null&&double.TryParse(p[1],System.Globalization.NumberStyles.Any,CultureInfo.InvariantCulture,out var w))c.Width=new DataGridLength(Math.Max(35,w));}
   var o=GridFatura.Columns.Select((c,i)=>new{C=c,I=i,D=(d.FirstOrDefault(z=>z[0]==(c.Header?.ToString()??"")) is string[] p&&int.TryParse(p[2],out var di))?di:i}).OrderBy(z=>z.D).ThenBy(z=>z.I).ToList();
   for(int i=0;i<o.Count;i++)o[i].C.DisplayIndex=i;
  }catch{}
 }
 void SalvarLayoutCartao(){
  try{System.IO.Directory.CreateDirectory(System.IO.Path.GetDirectoryName(ArquivoLayoutCartao)!);System.IO.File.WriteAllLines(ArquivoLayoutCartao,GridFatura.Columns.Select(c=>(c.Header?.ToString()??"")+"|"+c.ActualWidth.ToString(CultureInfo.InvariantCulture)+"|"+c.DisplayIndex));}catch{}
 }
 void GridFatura_LayoutChanged(object sender,EventArgs e)=>Dispatcher.BeginInvoke(new Action(SalvarLayoutCartao),System.Windows.Threading.DispatcherPriority.Background);

 sealed class Linha{
   public long Id{get;} public DateTime? DataPagamento{get;} public string NumeroDocumento{get;} public string Descricao{get;} public string ClienteFornecedorNome{get;} public string PlanoContasNome{get;} public string CentroCustosNome{get;} public string GrupoContasNome{get;} public decimal Valor{get;} public string ValorTexto{get;} public bool Conciliado{get;set;} public string SituacaoCartao{get;}
   public Linha(Lancamento x){Id=x.Id;DataPagamento=x.DataPagamento;NumeroDocumento=x.NumeroDocumento;Descricao=x.Descricao;ClienteFornecedorNome=x.ClienteFornecedorNome;PlanoContasNome=x.PlanoContasNome;CentroCustosNome=x.CentroCustosNome;GrupoContasNome=x.GrupoContasNome;Valor=x.Tipo.Equals("Pagar",StringComparison.OrdinalIgnoreCase)?-Math.Abs(x.Valor):Math.Abs(x.Valor);ValorTexto=Math.Abs(Valor).ToString("N2",CultureInfo.GetCultureInfo("pt-BR"));SituacaoCartao=x.Baixado?"Pago":"Aberto";}
 }
}