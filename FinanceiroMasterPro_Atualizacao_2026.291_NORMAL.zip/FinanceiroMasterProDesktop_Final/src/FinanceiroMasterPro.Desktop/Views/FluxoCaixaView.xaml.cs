using FinanceiroMasterPro.Infrastructure.Data;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace FinanceiroMasterPro.Desktop.Views;

public partial class FluxoCaixaView : UserControl
{
    private readonly FluxoCaixaRepository _repository = new();
    private List<FluxoCaixa> _fluxos = new();

    private long _idAtual = 0;

    public FluxoCaixaView()
    {
        InitializeComponent();

        CarregarFluxos();
        Novo();
    }

    private void CarregarFluxos()
    {
        _fluxos = _repository.Listar();

        GridFluxos.ItemsSource = null;
        GridFluxos.ItemsSource = _fluxos;
    }

    private void Novo()
    {
        _idAtual = 0;

        TxtNome.Clear();
        ChkAtivo.IsChecked = true;

        GridFluxos.SelectedItem = null;

        TxtNome.Focus();
    }

    private void Novo_Click(object sender, RoutedEventArgs e)
    {
        Novo();
    }

    private void Salvar_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            if (string.IsNullOrWhiteSpace(TxtNome.Text))
            {
                MessageBox.Show(
                    "Informe o nome do Fluxo de Caixa.",
                    "Financeiro Master Pro",
                    MessageBoxButton.OK,
                    MessageBoxImage.Information);

                TxtNome.Focus();
                return;
            }

            var fluxo = new FluxoCaixa
            {
                Id = _idAtual,
                Nome = TxtNome.Text,
                Ativo = ChkAtivo.IsChecked == true
            };

            _idAtual = _repository.Salvar(fluxo);

            MessageBox.Show(
                "Fluxo de Caixa salvo com sucesso.",
                "Financeiro Master Pro",
                MessageBoxButton.OK,
                MessageBoxImage.Information);

            CarregarFluxos();
            Novo();
        }
        catch (System.Exception ex)
        {
            MessageBox.Show(
                $"Não foi possível salvar o Fluxo de Caixa.\n\n{ex.Message}",
                "Financeiro Master Pro",
                MessageBoxButton.OK,
                MessageBoxImage.Error);
        }
    }

    private void GridFluxos_SelectionChanged(
        object sender,
        SelectionChangedEventArgs e)
    {
        if (GridFluxos.SelectedItem is not FluxoCaixa fluxo)
            return;

        _idAtual = fluxo.Id;

        TxtNome.Text = fluxo.Nome;
        ChkAtivo.IsChecked = fluxo.Ativo;
    }

    private void AlterarStatus_Click(object sender, RoutedEventArgs e)
    {
        if (_idAtual == 0)
        {
            MessageBox.Show(
                "Selecione um Fluxo de Caixa na lista.",
                "Financeiro Master Pro",
                MessageBoxButton.OK,
                MessageBoxImage.Information);

            return;
        }

        bool novoStatus = ChkAtivo.IsChecked != true;

        _repository.AlterarStatus(_idAtual, novoStatus);

        CarregarFluxos();
        Novo();
    }

    private void Pesquisar_TextChanged(
        object sender,
        TextChangedEventArgs e)
    {
        string pesquisa =
            TxtPesquisar.Text.Trim().ToLower();

        if (string.IsNullOrWhiteSpace(pesquisa))
        {
            GridFluxos.ItemsSource = _fluxos;
            return;
        }

        GridFluxos.ItemsSource =
            _fluxos
                .Where(f =>
                    PesquisaAvancada.Texto(f.Nome,pesquisa))
                .ToList();
    }

    private void Alterar_Click(object sender, RoutedEventArgs e)
    {
        if (_idAtual == 0)
        {
            MessageBox.Show("Selecione um cadastro na lista para alterar.", "Financeiro Master Pro", MessageBoxButton.OK, MessageBoxImage.Information);
            return;
        }
        Salvar_Click(sender, e);
    }

    private void Excluir_Click(object sender, RoutedEventArgs e)
    {
        if (_idAtual == 0)
        {
            MessageBox.Show("Selecione um cadastro na lista para excluir.", "Financeiro Master Pro", MessageBoxButton.OK, MessageBoxImage.Information);
            return;
        }

        var resposta = MessageBox.Show(
            "Deseja realmente excluir este cadastro?\n\nSe ele estiver vinculado a lançamentos, parcelamentos ou rateios, a exclusão será bloqueada para proteger os dados.",
            "Financeiro Master Pro",
            MessageBoxButton.YesNo,
            MessageBoxImage.Warning);
        if (resposta != MessageBoxResult.Yes) return;

        try
        {
            _repository.Excluir(_idAtual);
            CarregarFluxos();
            Novo();
        }
        catch (System.Exception ex)
        {
            MessageBox.Show(ex.Message, "Financeiro Master Pro", MessageBoxButton.OK, MessageBoxImage.Information);
        }
    }

    private void Cadastro_PreviewKeyDown(object sender, KeyEventArgs e)
    {
        if (e.Key != Key.Enter) return;
        if (Keyboard.FocusedElement is Button) return;
        e.Handled = true;
        (Keyboard.FocusedElement as UIElement)?.MoveFocus(new TraversalRequest(FocusNavigationDirection.Next));
    }
    private void AlterarLote_Click(object sender, RoutedEventArgs e)
    {
        var selecionados = GridFluxos.SelectedItems.Cast<FluxoCaixa>().ToList();
        if (selecionados.Count == 0)
        {
            MessageBox.Show("Selecione um ou mais cadastros. Use Ctrl+clique para selecionar vários.", "Financeiro Master Pro", MessageBoxButton.OK, MessageBoxImage.Information);
            return;
        }
        var janela = new EdicaoLoteWindow(selecionados.Count) { Owner = Window.GetWindow(this) };
        if (janela.ShowDialog() != true) return;
        int alterados = 0;
        foreach (var item in selecionados)
        {
            if (!item.Nome.Contains(janela.Localizar, System.StringComparison.OrdinalIgnoreCase)) continue;
            item.Nome = System.Text.RegularExpressions.Regex.Replace(item.Nome, System.Text.RegularExpressions.Regex.Escape(janela.Localizar), janela.Substituir, System.Text.RegularExpressions.RegexOptions.IgnoreCase).Trim();
            _repository.Salvar(item); alterados++;
        }
        CarregarFluxos();
        MessageBox.Show($"{alterados} cadastro(s) alterado(s).", "Financeiro Master Pro", MessageBoxButton.OK, MessageBoxImage.Information);
    }

    private void ExcluirLote_Click(object sender, RoutedEventArgs e)
    {
        var selecionados = GridFluxos.SelectedItems.Cast<FluxoCaixa>().ToList();
        if (selecionados.Count == 0)
        {
            MessageBox.Show("Selecione um ou mais cadastros para excluir.", "Financeiro Master Pro", MessageBoxButton.OK, MessageBoxImage.Information); return;
        }
        if (MessageBox.Show($"Excluir {selecionados.Count} cadastro(s) selecionado(s)?\n\nCadastros vinculados serão protegidos pelo sistema.", "Financeiro Master Pro", MessageBoxButton.YesNo, MessageBoxImage.Warning) != MessageBoxResult.Yes) return;
        int excluidos=0, bloqueados=0;
        foreach (var item in selecionados)
        {
            try { _repository.Excluir(item.Id); excluidos++; } catch { bloqueados++; }
        }
        CarregarFluxos(); Novo();
        MessageBox.Show($"Excluídos: {excluidos}\nProtegidos/bloqueados: {bloqueados}", "Financeiro Master Pro", MessageBoxButton.OK, MessageBoxImage.Information);
    }

}
