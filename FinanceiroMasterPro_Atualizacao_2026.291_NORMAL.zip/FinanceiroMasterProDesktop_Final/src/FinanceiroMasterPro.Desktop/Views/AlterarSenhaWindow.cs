using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using FinanceiroMasterPro.Infrastructure.Security;

namespace FinanceiroMasterPro.Desktop.Views;

public sealed class AlterarSenhaWindow : Window
{
    public AlterarSenhaWindow(bool obrigatoria = false)
    {
        Title = "Alterar Minha Senha";
        Width = 520;
        Height = 510;
        MinHeight = 510;
        WindowStartupLocation = WindowStartupLocation.CenterScreen;
        ResizeMode = ResizeMode.NoResize;

        var root = new Grid { Margin = new Thickness(28) };
        root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
        root.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });
        root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });

        var titulo = new TextBlock
        {
            Text = obrigatoria ? "TROCA DE SENHA OBRIGATÓRIA" : "ALTERAR MINHA SENHA",
            FontSize = 22,
            FontWeight = FontWeights.Bold,
            Margin = new Thickness(0, 0, 0, 16)
        };
        Grid.SetRow(titulo, 0);
        root.Children.Add(titulo);

        var campos = new StackPanel();
        Grid.SetRow(campos, 1);
        root.Children.Add(campos);

        var atual = CriarCampoSenha(campos, "Senha atual");
        var nova = CriarCampoSenha(campos, "Nova senha");
        var conf = CriarCampoSenha(campos, "Confirmar nova senha");

        var rodape = new Grid { Margin = new Thickness(0, 22, 0, 0) };
        rodape.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
        rodape.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
        rodape.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

        if (!obrigatoria)
        {
            var cancelar = new Button { Content = "CANCELAR", Width = 120, Height = 40, Margin = new Thickness(0, 0, 10, 0) };
            cancelar.Click += (_, __) => Close();
            Grid.SetColumn(cancelar, 1);
            rodape.Children.Add(cancelar);
        }

        var confirmar = new Button
        {
            Content = obrigatoria ? "CONFIRMAR NOVA SENHA" : "ALTERAR SENHA",
            Width = 190,
            Height = 40,
            FontWeight = FontWeights.SemiBold
        };
        confirmar.Click += (_, __) =>
        {
            try
            {
                var senhaAtual = atual.GetPassword();
                var senhaNova = nova.GetPassword();
                var confirmacao = conf.GetPassword();
                if (senhaNova != confirmacao)
                    throw new InvalidOperationException("A confirmação da nova senha não confere.");

                var u = SecuritySession.CurrentUser ?? throw new InvalidOperationException("Usuário não identificado.");
                SecurityStore.AlterarSenha(u.Id, senhaAtual, senhaNova);
                DialogResult = true;
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Alterar Senha", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        };
        Grid.SetColumn(confirmar, 2);
        rodape.Children.Add(confirmar);
        Grid.SetRow(rodape, 2);
        root.Children.Add(rodape);

        Content = root;
        if (obrigatoria)
            Closing += (_, e) => { if (DialogResult != true) e.Cancel = true; };
    }

    private static PasswordField CriarCampoSenha(Panel parent, string rotulo)
    {
        parent.Children.Add(new TextBlock { Text = rotulo, Margin = new Thickness(0, 10, 0, 5), FontWeight = FontWeights.SemiBold });
        var field = new PasswordField();
        parent.Children.Add(field.Container);
        return field;
    }

    private sealed class PasswordField
    {
        public Grid Container { get; } = new() { Height = 38 };
        private readonly PasswordBox _password = new() { Height = 38, Padding = new Thickness(8, 4, 42, 4) };
        private readonly TextBox _text = new() { Height = 38, Padding = new Thickness(8, 4, 42, 4), Visibility = Visibility.Collapsed };
        private readonly Button _eye = new() { Content = "👁", Width = 38, Height = 30, HorizontalAlignment = HorizontalAlignment.Right, Margin = new Thickness(0, 4, 4, 4), ToolTip = "Mostrar / ocultar senha" };
        private bool _visible;

        public PasswordField()
        {
            Container.Children.Add(_password);
            Container.Children.Add(_text);
            Container.Children.Add(_eye);
            _eye.Click += (_, __) => Toggle();
        }

        private void Toggle()
        {
            _visible = !_visible;
            if (_visible)
            {
                _text.Text = _password.Password;
                _password.Visibility = Visibility.Collapsed;
                _text.Visibility = Visibility.Visible;
                _text.Focus();
                _text.CaretIndex = _text.Text.Length;
            }
            else
            {
                _password.Password = _text.Text;
                _text.Visibility = Visibility.Collapsed;
                _password.Visibility = Visibility.Visible;
                _password.Focus();
            }
        }

        public string GetPassword() => _visible ? _text.Text : _password.Password;
    }
}
