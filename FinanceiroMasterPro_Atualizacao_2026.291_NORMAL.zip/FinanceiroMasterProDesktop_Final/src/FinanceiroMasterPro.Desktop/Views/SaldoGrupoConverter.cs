using System;
using System.Collections;
using System.Globalization;
using System.Linq;
using System.Windows.Data;
namespace FinanceiroMasterPro.Desktop.Views;
public sealed class SaldoGrupoConverter : IValueConverter
{
 public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
 {
   if(value is IEnumerable itens){ decimal total=0; foreach(var i in itens){ var p=i?.GetType().GetProperty("Saldo"); if(p?.GetValue(i) is decimal d) total+=d; } return total.ToString("C2", new CultureInfo("pt-BR")); }
   return "R$ 0,00";
 }
 public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)=>throw new NotSupportedException();
}
