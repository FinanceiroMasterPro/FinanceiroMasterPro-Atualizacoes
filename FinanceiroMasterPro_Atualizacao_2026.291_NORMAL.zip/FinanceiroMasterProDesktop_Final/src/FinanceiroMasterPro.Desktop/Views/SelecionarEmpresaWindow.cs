using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using FinanceiroMasterPro.Infrastructure.Data;
using FinanceiroMasterPro.Infrastructure.Security;

namespace FinanceiroMasterPro.Desktop.Views;

public sealed class SelecionarEmpresaWindow : Window
{
    private readonly ListBox _lista = new();
    private readonly TextBox _nova = new();
    private readonly TextBox _pesquisa = new();
    private DateTime? _de, _ate;
    public EmpresaBanco? EmpresaSelecionada { get; private set; }

    public SelecionarEmpresaWindow()
    {
        Title = "Financeiro Master Pro - Selecione a Empresa";
        Width = 760; Height = 620; MinWidth = 680; MinHeight = 520;
        WindowStartupLocation = WindowStartupLocation.CenterScreen;
        ResizeMode = ResizeMode.CanResize; Background = Brushes.White;

        var raiz = new Grid { Margin = new Thickness(28) };
        raiz.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
        raiz.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
        raiz.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });
        raiz.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
        raiz.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });

        var titulo = new TextBlock { Text = "SELECIONE A EMPRESA", FontSize = 24, FontWeight = FontWeights.Bold, Foreground = new SolidColorBrush(Color.FromRgb(22,32,42)), Margin = new Thickness(0,0,0,14) };
        Grid.SetRow(titulo,0); raiz.Children.Add(titulo);

        var busca = new Grid { Margin = new Thickness(0,0,0,12) };
        busca.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
        busca.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
        busca.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
        _pesquisa.Height = 38; _pesquisa.FontSize = 14; _pesquisa.VerticalContentAlignment = VerticalAlignment.Center; _pesquisa.ToolTip = "Pesquisar pelo nome da empresa";
        _pesquisa.TextChanged += (_,__) => Carregar();
        busca.Children.Add(_pesquisa);
        var avancada = Botao("PESQUISA AVANÇADA", 165); avancada.Margin = new Thickness(10,0,0,0); avancada.Click += (_,__) => PesquisaAvancada(); Grid.SetColumn(avancada,1); busca.Children.Add(avancada);
        var limpar = Botao("LIMPAR PESQUISA", 145); limpar.Margin = new Thickness(10,0,0,0); limpar.Click += (_,__) => { _pesquisa.Clear(); _de = _ate = null; Carregar(); }; Grid.SetColumn(limpar,2); busca.Children.Add(limpar);
        Grid.SetRow(busca,1); raiz.Children.Add(busca);

        _lista.DisplayMemberPath = "Nome"; _lista.FontSize = 16; _lista.Margin = new Thickness(0,0,0,18);
        _lista.MouseDoubleClick += (_,__) => Abrir(); Grid.SetRow(_lista,2); raiz.Children.Add(_lista);

        var novaPainel = new DockPanel { Margin = new Thickness(0,0,0,16) };
        var btnNova = Botao("NOVA EMPRESA", 135); btnNova.Click += (_,__) => Criar(); DockPanel.SetDock(btnNova, Dock.Right);
        _nova.Height = 38; _nova.FontSize = 14; _nova.VerticalContentAlignment = VerticalAlignment.Center; _nova.Margin = new Thickness(0,0,10,0); _nova.ToolTip = "Digite o nome da nova empresa";
        novaPainel.Children.Add(btnNova); novaPainel.Children.Add(_nova); Grid.SetRow(novaPainel,3); raiz.Children.Add(novaPainel);

        var rodape = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right };
        var inativas = Botao("EMPRESAS INATIVAS", 160); inativas.Margin = new Thickness(0,0,10,0); inativas.Click += (_,__) => MostrarInativas();
        var inativar = Botao("INATIVAR", 105); inativar.Margin = new Thickness(0,0,10,0); inativar.Click += (_,__) => Inativar();
        var cancelar = Botao("SAIR", 90); cancelar.Margin = new Thickness(0,0,10,0); cancelar.Click += (_,__) => { DialogResult = false; Close(); };
        var alterar = Botao("ALTERAR EMPRESA", 145); alterar.Margin = new Thickness(0,0,10,0); alterar.Click += (_,__) => Alterar();
        var abrir = Botao("ABRIR EMPRESA", 145); abrir.FontWeight = FontWeights.Bold; abrir.Click += (_,__) => Abrir();
        rodape.Children.Add(inativas); rodape.Children.Add(inativar); rodape.Children.Add(cancelar); rodape.Children.Add(alterar); rodape.Children.Add(abrir);
        Grid.SetRow(rodape,4); raiz.Children.Add(rodape);
        Content = raiz; Carregar();
    }

    private static Button Botao(string texto, double largura) => new() { Content = texto, Width = largura, Height = 38, Padding = new Thickness(8,0,8,0) };
    private void Carregar()
    {
        IEnumerable<EmpresaBanco> q = EmpresaDatabaseManager.Listar();
        if (SecuritySession.CurrentUser is { } usuario) q = q.Where(x => SecurityStore.PodeAcessarEmpresa(usuario, x.Id));
        var t = _pesquisa.Text.Trim(); if (t.Length > 0) q = q.Where(x => x.Nome.Contains(t, StringComparison.CurrentCultureIgnoreCase));
        if (_de.HasValue) q = q.Where(x => x.CriadaEm.Date >= _de.Value.Date);
        if (_ate.HasValue) q = q.Where(x => x.CriadaEm.Date <= _ate.Value.Date);
        _lista.ItemsSource = q.ToList(); if (_lista.Items.Count > 0) _lista.SelectedIndex = 0;
    }

    private void PesquisaAvancada()
    {
        var w = new Window { Title="Pesquisa Avançada de Empresas", Width=480, Height=285, Owner=this, WindowStartupLocation=WindowStartupLocation.CenterOwner, ResizeMode=ResizeMode.NoResize };
        var p = new StackPanel { Margin=new Thickness(22) };
        p.Children.Add(new TextBlock { Text="Nome contém:", FontWeight=FontWeights.SemiBold });
        var nome = new TextBox { Text=_pesquisa.Text, Height=34, Margin=new Thickness(0,6,0,12), VerticalContentAlignment=VerticalAlignment.Center }; p.Children.Add(nome);
        p.Children.Add(new TextBlock { Text="Período de criação da empresa:", FontWeight=FontWeights.SemiBold });
        var datas = new StackPanel { Orientation=Orientation.Horizontal, Margin=new Thickness(0,6,0,16) };
        var de = new DatePicker { Width=180, SelectedDate=_de }; var ate = new DatePicker { Width=180, SelectedDate=_ate, Margin=new Thickness(12,0,0,0) };
        datas.Children.Add(de); datas.Children.Add(ate); p.Children.Add(datas);
        var aplicar=Botao("APLICAR PESQUISA",155); aplicar.HorizontalAlignment=HorizontalAlignment.Right; aplicar.Click += (_,__) => { _pesquisa.Text=nome.Text; _de=de.SelectedDate; _ate=ate.SelectedDate; w.DialogResult=true; }; p.Children.Add(aplicar);
        w.Content=p; if (w.ShowDialog()==true) Carregar();
    }

    private void Criar() { if (SecuritySession.CurrentUser?.Administrador != true) { MessageBox.Show("Somente administradores podem criar empresas."); return; } try { var e=EmpresaDatabaseManager.Criar(_nova.Text); Carregar(); _lista.SelectedItem=_lista.Items.Cast<EmpresaBanco>().FirstOrDefault(x=>x.Id==e.Id); _nova.Clear(); } catch(Exception ex){ MessageBox.Show(ex.Message,"Nova Empresa",MessageBoxButton.OK,MessageBoxImage.Information); } }
    private void Alterar()
    {
        if (SecuritySession.CurrentUser?.Administrador != true) { MessageBox.Show("Somente administradores podem alterar empresas."); return; }
        if (_lista.SelectedItem is not EmpresaBanco e) { MessageBox.Show("Selecione a empresa que deseja alterar.","Financeiro Master Pro",MessageBoxButton.OK,MessageBoxImage.Information); return; }
        var w=new Window { Title="Alterar Empresa",Width=460,Height=190,Owner=this,WindowStartupLocation=WindowStartupLocation.CenterOwner,ResizeMode=ResizeMode.NoResize };
        var p=new StackPanel { Margin=new Thickness(20) }; p.Children.Add(new TextBlock { Text="Nome da empresa:",FontWeight=FontWeights.SemiBold });
        var nome=new TextBox { Text=e.Nome,Height=34,Margin=new Thickness(0,8,0,14),FontSize=14,VerticalContentAlignment=VerticalAlignment.Center }; p.Children.Add(nome);
        var salvar=Botao("SALVAR ALTERAÇÃO",155); salvar.HorizontalAlignment=HorizontalAlignment.Right; salvar.Click += (_,__) => { try { EmpresaDatabaseManager.AlterarNome(e,nome.Text); w.DialogResult=true; } catch(Exception ex){ MessageBox.Show(ex.Message,"Alterar Empresa",MessageBoxButton.OK,MessageBoxImage.Information); } }; p.Children.Add(salvar); w.Content=p;
        if(w.ShowDialog()==true) Carregar();
    }

    private void Inativar()
    {
        if (SecuritySession.CurrentUser?.Administrador != true) { MessageBox.Show("Somente administradores podem inativar empresas."); return; }
        if (_lista.SelectedItem is not EmpresaBanco e) { MessageBox.Show("Selecione a empresa que deseja inativar."); return; }
        if (MessageBox.Show($"Deseja inativar a empresa '{e.Nome}'?\n\nNenhum dado será excluído. O banco e todos os lançamentos serão preservados.","Inativar Empresa",MessageBoxButton.YesNo,MessageBoxImage.Question)!=MessageBoxResult.Yes) return;
        try { EmpresaDatabaseManager.Inativar(e); Carregar(); } catch(Exception ex){ MessageBox.Show(ex.Message,"Inativar Empresa",MessageBoxButton.OK,MessageBoxImage.Information); }
    }

    private void MostrarInativas()
    {
        if (SecuritySession.CurrentUser?.Administrador != true) { MessageBox.Show("Somente administradores podem acessar empresas inativas."); return; }
        var w=new Window { Title="Financeiro Master Pro - Empresas Inativas",Width=650,Height=460,Owner=this,WindowStartupLocation=WindowStartupLocation.CenterOwner };
        var g=new Grid { Margin=new Thickness(22) }; g.RowDefinitions.Add(new RowDefinition{Height=GridLength.Auto}); g.RowDefinitions.Add(new RowDefinition{Height=GridLength.Auto}); g.RowDefinitions.Add(new RowDefinition{Height=new GridLength(1,GridUnitType.Star)}); g.RowDefinitions.Add(new RowDefinition{Height=GridLength.Auto});
        var titulo=new TextBlock { Text="EMPRESAS INATIVAS",FontSize=22,FontWeight=FontWeights.Bold,Margin=new Thickness(0,0,0,12) }; g.Children.Add(titulo);
        var busca=new TextBox { Height=36,VerticalContentAlignment=VerticalAlignment.Center,ToolTip="Pesquisar empresa inativa",Margin=new Thickness(0,0,0,10) }; Grid.SetRow(busca,1); g.Children.Add(busca);
        var lista=new ListBox { DisplayMemberPath="Nome",FontSize=15,Margin=new Thickness(0,0,0,14) }; Grid.SetRow(lista,2); g.Children.Add(lista);
        void Load(){ IEnumerable<EmpresaBanco> q=EmpresaDatabaseManager.ListarInativas(); var t=busca.Text.Trim(); if(t.Length>0) q=q.Where(x=>x.Nome.Contains(t,StringComparison.CurrentCultureIgnoreCase)); lista.ItemsSource=q.ToList(); if(lista.Items.Count>0) lista.SelectedIndex=0; }
        busca.TextChanged += (_,__)=>Load();
        var botoes=new StackPanel { Orientation=Orientation.Horizontal,HorizontalAlignment=HorizontalAlignment.Right }; var fechar=Botao("FECHAR",100); fechar.Margin=new Thickness(0,0,10,0); fechar.Click += (_,__)=>w.Close(); var ativar=Botao("ATIVAR EMPRESA",145); ativar.Click += (_,__)=> { if(lista.SelectedItem is not EmpresaBanco e){MessageBox.Show("Selecione uma empresa inativa.");return;} EmpresaDatabaseManager.Ativar(e); Load(); Carregar(); }; botoes.Children.Add(fechar); botoes.Children.Add(ativar); Grid.SetRow(botoes,3); g.Children.Add(botoes);
        w.Content=g; Load(); w.ShowDialog(); Carregar();
    }

    private void Abrir() { if(_lista.SelectedItem is not EmpresaBanco e){MessageBox.Show("Selecione uma empresa.","Financeiro Master Pro",MessageBoxButton.OK,MessageBoxImage.Information);return;} EmpresaSelecionada=e; DialogResult=true; Close(); }
}
