using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Media;

namespace FinanceiroMasterPro.Desktop.Views;

public sealed class EscolherCadastroDuplicadoWindow : Window
{
    private readonly ListBox _lista = new();
    public object? Escolhido { get; private set; }
    private sealed class Linha { public object Item { get; init; } = null!; public string Texto { get; init; } = ""; }

    public EscolherCadastroDuplicadoWindow(IEnumerable<object> itens, Func<object,string> nome)
    {
        Title="Escolher classificação"; Width=520; Height=330; WindowStartupLocation=WindowStartupLocation.CenterOwner; ResizeMode=ResizeMode.NoResize;
        var raiz=new DockPanel{Margin=new Thickness(16)};
        var titulo=new TextBlock{Text="Existem cadastros com o mesmo nome. Escolha o correto:",FontWeight=FontWeights.SemiBold,Margin=new Thickness(0,0,0,10)};
        DockPanel.SetDock(titulo,Dock.Top); raiz.Children.Add(titulo);
        var botoes=new StackPanel{Orientation=Orientation.Horizontal,HorizontalAlignment=HorizontalAlignment.Right,Margin=new Thickness(0,10,0,0)};
        var ok=new Button{Content="CONFIRMAR",Width=110,Height=32,IsDefault=true,Margin=new Thickness(6,0,0,0)};
        var cancelar=new Button{Content="CANCELAR",Width=100,Height=32,IsCancel=true};
        ok.Click += (_,__)=>Confirmar(); botoes.Children.Add(cancelar); botoes.Children.Add(ok); DockPanel.SetDock(botoes,Dock.Bottom); raiz.Children.Add(botoes);
        _lista.DisplayMemberPath="Texto"; _lista.MouseDoubleClick += (_,__)=>Confirmar();
        _lista.ItemsSource=itens.Select(x=>new Linha{Item=x,Texto=$"{nome(x)}   •   código {Id(x)}"}).ToList();
        raiz.Children.Add(_lista); Content=raiz;
    }
    private static string Id(object x)=>x.GetType().GetProperty("Id")?.GetValue(x)?.ToString()??"-";
    private void Confirmar(){if(_lista.SelectedItem is not Linha l)return;Escolhido=l.Item;DialogResult=true;Close();}
}
