﻿using FinanceiroMasterPro.Infrastructure.Data;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Media;
using System.Printing;
using System.Diagnostics;
using System.Text;
using System.Threading;

namespace FinanceiroMasterPro.Desktop.Views;

public sealed class RelatorioLancamentosWindow : Window
{
    readonly List<Lancamento> _itens;
    readonly List<Lancamento> _originais;
    readonly List<(string Campo, string Valor)> _filtrosAtivos = new();
    readonly DataGrid _grid = new();
    readonly StackPanel _listaFiltros = new();
    readonly CultureInfo _br = CultureInfo.GetCultureInfo("pt-BR");
    readonly string _arquivoLayout = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "FinanceiroMasterPro", "relatorio_lancamentos_colunas.txt");

    public RelatorioLancamentosWindow(IEnumerable<Lancamento> itens)
    {
        _itens = itens.Where(x => x.Ativo).ToList();
        _originais = _itens.ToList();
        Title = "Relatório de Lançamentos";
        Width = 1450; Height = 820; MinWidth = 1050; MinHeight = 650;
        WindowStartupLocation = WindowStartupLocation.CenterOwner;
        Background = Brushes.White;
        Content = MontarTela();
        Loaded += (_,__) => CarregarLayoutColunas();
        Closing += (_,__) => SalvarLayoutColunas();
    }

    UIElement MontarTela()
    {
        var raiz = new DockPanel { Margin = new Thickness(12) };
        var topo = new Grid { Margin = new Thickness(0,0,0,10) };
        topo.ColumnDefinitions.Add(new ColumnDefinition()); topo.ColumnDefinitions.Add(new ColumnDefinition{Width=GridLength.Auto});
        var marca = new StackPanel();
        marca.Children.Add(new TextBlock { Text="Financeiro Master Pro", FontSize=27, FontWeight=FontWeights.Bold, Foreground=new SolidColorBrush(Color.FromRgb(15,70,130)) });
        marca.Children.Add(new TextBlock { Text="CONTROLE FINANCEIRO MULTIEMPRESA", FontSize=13, FontWeight=FontWeights.Bold });
        topo.Children.Add(marca);
        var titulo = new TextBlock { Text="RELATÓRIO DE LANÇAMENTOS", FontSize=24, FontWeight=FontWeights.Bold, Foreground=new SolidColorBrush(Color.FromRgb(15,70,130)), VerticalAlignment=VerticalAlignment.Center };
        Grid.SetColumn(titulo,1); topo.Children.Add(titulo); DockPanel.SetDock(topo,Dock.Top); raiz.Children.Add(topo);

        var rodape = new StackPanel { Orientation=Orientation.Vertical, Margin=new Thickness(0,8,0,0) };
        var totais = new Grid { Height=68 };
        for(int i=0;i<4;i++) totais.ColumnDefinitions.Add(new ColumnDefinition());
        decimal pagar=_itens.Where(x=>x.Tipo.Equals("Pagar",StringComparison.OrdinalIgnoreCase)&&!x.Baixado).Sum(x=>Math.Abs(x.Valor));
        decimal receber=_itens.Where(x=>x.Tipo.Equals("Receber",StringComparison.OrdinalIgnoreCase)&&!x.Baixado).Sum(x=>Math.Abs(x.Valor));
        decimal pago=_itens.Where(x=>x.Tipo.Equals("Pagar",StringComparison.OrdinalIgnoreCase)&&x.Baixado).Sum(x=>Math.Abs(x.Valor));
        decimal recebido=_itens.Where(x=>x.Tipo.Equals("Receber",StringComparison.OrdinalIgnoreCase)&&x.Baixado).Sum(x=>Math.Abs(x.Valor));
        AddTotal(totais,0,"A PAGAR",pagar,Color.FromRgb(255,235,235)); AddTotal(totais,1,"A RECEBER",receber,Color.FromRgb(235,248,235)); AddTotal(totais,2,"PAGO",pago,Color.FromRgb(225,240,252)); AddTotal(totais,3,"RECEBIDO",recebido,Color.FromRgb(255,249,218));
        rodape.Children.Add(totais);
        var botoes = new Grid { Margin=new Thickness(0,8,0,0) }; botoes.ColumnDefinitions.Add(new ColumnDefinition()); botoes.ColumnDefinitions.Add(new ColumnDefinition{Width=GridLength.Auto}); botoes.ColumnDefinitions.Add(new ColumnDefinition{Width=GridLength.Auto});
        var voltar = new Button { Content="←  VOLTAR", Width=120, Height=38, FontWeight=FontWeights.Bold }; voltar.Click += (_,__)=> { if (Owner is MainWindow main) main.VoltarDoRelatorioParaLancamentos(); Close(); }; botoes.Children.Add(voltar);
        var excel = new Button { Content="▦  EXCEL", Width=125, Height=38, Margin=new Thickness(0,0,8,0), FontWeight=FontWeights.Bold }; excel.Click += Excel_Click; Grid.SetColumn(excel,1); botoes.Children.Add(excel);
        var imprimir = new Button { Content="🖨  IMPRIMIR", Width=150, Height=38, FontWeight=FontWeights.Bold, Background=new SolidColorBrush(Color.FromRgb(25,105,200)), Foreground=Brushes.White }; imprimir.Click += Imprimir_Click; Grid.SetColumn(imprimir,2); botoes.Children.Add(imprimir); rodape.Children.Add(botoes);
        DockPanel.SetDock(rodape,Dock.Bottom); raiz.Children.Add(rodape);

        var pesquisa = CriarPainelPesquisa();
        DockPanel.SetDock(pesquisa, Dock.Top);
        raiz.Children.Add(pesquisa);

        var ordem = CriarPainelOrdenacao();
        DockPanel.SetDock(ordem, Dock.Top);
        raiz.Children.Add(ordem);

        _grid.AutoGenerateColumns=false; _grid.IsReadOnly=true; _grid.CanUserAddRows=false; _grid.HeadersVisibility=DataGridHeadersVisibility.Column; _grid.GridLinesVisibility=DataGridGridLinesVisibility.All; _grid.RowHeight=27; _grid.ColumnHeaderHeight=46; _grid.FontSize=12; _grid.ItemsSource=_itens;
        _grid.CanUserResizeColumns = true;
        _grid.CanUserSortColumns = true;
        _grid.MouseDoubleClick += Grid_MouseDoubleClick;
        var cabecalho = new Style(typeof(DataGridColumnHeader));
        cabecalho.Setters.Add(new Setter(Control.FontWeightProperty, FontWeights.Bold));
        cabecalho.Setters.Add(new Setter(Control.HorizontalContentAlignmentProperty, HorizontalAlignment.Center));
        cabecalho.Setters.Add(new Setter(Control.VerticalContentAlignmentProperty, VerticalAlignment.Center));
        _grid.ColumnHeaderStyle = cabecalho;

        AddCol("DATA\nPAGTO/RECEB","DataPagamento",105,"{0:dd/MM/yyyy}", HorizontalAlignment.Center);
        AddCol("TIPO","TipoExibicao",80,null, HorizontalAlignment.Center);
        AddCol("CONTA BANCÁRIA","ContaBancariaNome",160);
        AddCol("CLIENTE / FORNECEDOR","ClienteFornecedorNome",180);
        AddCol("DESCRIÇÃO","Descricao",220);
        AddCol("Nº DOC","NumeroDocumento",100);
        AddCol("VALOR","ValorExibicaoSemSinal",105,null, HorizontalAlignment.Right);
        AddCol("PLANO DE CONTAS","PlanoContasNome",170);
        AddCol("CENTRO DE CUSTOS","CentroCustosNome",150,null, HorizontalAlignment.Center);
        AddCol("GRUPO DE CONTAS","GrupoContasNome",150);
        AddCol("FLUXO DE CAIXA","FluxoCaixaNome",150);
        AddCol("DATA EMISSÃO","DataEmissao",105,"{0:dd/MM/yyyy}", HorizontalAlignment.Center);
        AddCol("PERÍODO","Periodo",100);
        AddCol("PARCELADO / RATEADO","IdentificacaoAgrupamento",135);
        AddCol("ANOTAÇÕES","Anotacoes",220);
        raiz.Children.Add(_grid); return raiz;
    }

    UIElement CriarPainelPesquisa()
    {
        var bloco = new StackPanel { Orientation = Orientation.Vertical, Margin = new Thickness(0,0,0,8) };
        var linha = new WrapPanel { VerticalAlignment = VerticalAlignment.Center };
        linha.Children.Add(new TextBlock { Text="PESQUISAR NO RELATÓRIO:", FontWeight=FontWeights.Bold, VerticalAlignment=VerticalAlignment.Center, Margin=new Thickness(0,0,8,0) });

        string[] campos = { "Todos os campos", "Data Pagto/Receb", "Data Emissão", "Tipo", "Status", "Conta Bancária", "Cliente/Fornecedor", "Descrição", "Nº Documento", "Valor", "Plano de Contas", "Centro de Custos", "Grupo de Contas", "Fluxo de Caixa", "Período", "Anotações", "Parcelado/Rateado" };
        var campo = new ComboBox { Width=175, Height=30, ItemsSource=campos, SelectedIndex=0, Margin=new Thickness(0,0,5,0) };
        var valor = new TextBox { Width=240, Height=30, VerticalContentAlignment=VerticalAlignment.Center, Margin=new Thickness(0,0,5,0) };
        var adicionar = new Button { Content="+ ADICIONAR FILTRO", Height=30, Padding=new Thickness(10,0,10,0), FontWeight=FontWeights.Bold, Margin=new Thickness(0,0,5,0) };
        var limpar = new Button { Content="LIMPAR PESQUISA", Height=30, Padding=new Thickness(10,0,10,0), FontWeight=FontWeights.Bold };
        adicionar.Click += (_,__) => {
            var v=(valor.Text??"").Trim(); if(v.Length==0) return;
            _filtrosAtivos.Add((campo.SelectedItem?.ToString() ?? "Todos os campos", v));
            valor.Clear(); AtualizarListaFiltros(); AplicarPesquisa();
        };
        valor.KeyDown += (_,e) => { if(e.Key == System.Windows.Input.Key.Enter) { adicionar.RaiseEvent(new RoutedEventArgs(Button.ClickEvent)); e.Handled=true; } };
        limpar.Click += (_,__) => { _filtrosAtivos.Clear(); AtualizarListaFiltros(); AplicarPesquisa(); };
        linha.Children.Add(campo); linha.Children.Add(valor); linha.Children.Add(adicionar); linha.Children.Add(limpar);
        bloco.Children.Add(linha);
        _listaFiltros.Orientation=Orientation.Horizontal; _listaFiltros.Margin=new Thickness(0,5,0,0);
        bloco.Children.Add(_listaFiltros);
        return bloco;
    }

    void AtualizarListaFiltros()
    {
        _listaFiltros.Children.Clear();
        for(int i=0;i<_filtrosAtivos.Count;i++)
        {
            int idx=i; var f=_filtrosAtivos[i];
            var b=new Button { Content=$"{f.Campo}: {f.Valor}  ×", Margin=new Thickness(0,0,5,0), Padding=new Thickness(7,2,7,2) };
            b.Click += (_,__) => { if(idx < _filtrosAtivos.Count) _filtrosAtivos.RemoveAt(idx); AtualizarListaFiltros(); AplicarPesquisa(); };
            _listaFiltros.Children.Add(b);
        }
    }

    void AplicarPesquisa()
    {
        IEnumerable<Lancamento> q=_originais;
        foreach(var f in _filtrosAtivos) q=q.Where(x => CampoContem(x, f.Campo, f.Valor));
        _itens.Clear(); _itens.AddRange(q);
        _grid.ItemsSource=null; _grid.ItemsSource=_itens;
    }

    bool CampoContem(Lancamento x, string campo, string busca)
    {
        bool C(string? v) => (v ?? "").IndexOf(busca, StringComparison.CurrentCultureIgnoreCase) >= 0;
        string status = x.Baixado ? "Baixado Pago Recebido Fechado" : "Aberto Pendente";
        string dataPg = x.DataPagamento?.ToString("dd/MM/yyyy") ?? "";
        string dataEm = x.DataEmissao.ToString("dd/MM/yyyy");
        string valor = Math.Abs(x.Valor).ToString("N2", _br);
        return campo switch {
            "Data Pagto/Receb" => C(dataPg), "Data Emissão" => C(dataEm), "Tipo" => C(x.TipoExibicao), "Status" => C(status),
            "Conta Bancária" => C(x.ContaBancariaNome), "Cliente/Fornecedor" => C(x.ClienteFornecedorNome), "Descrição" => C(x.Descricao),
            "Nº Documento" => C(x.NumeroDocumento), "Valor" => C(valor), "Plano de Contas" => C(x.PlanoContasNome), "Centro de Custos" => C(x.CentroCustosNome),
            "Grupo de Contas" => C(x.GrupoContasNome), "Fluxo de Caixa" => C(x.FluxoCaixaNome), "Período" => C(x.Periodo), "Anotações" => C(x.Anotacoes),
            "Parcelado/Rateado" => C(x.IdentificacaoAgrupamento),
            _ => new[]{dataPg,dataEm,x.TipoExibicao,status,x.ContaBancariaNome,x.ClienteFornecedorNome,x.Descricao,x.NumeroDocumento,valor,x.PlanoContasNome,x.CentroCustosNome,x.GrupoContasNome,x.FluxoCaixaNome,x.Periodo,x.Anotacoes,x.IdentificacaoAgrupamento}.Any(C)
        };
    }

    UIElement CriarPainelOrdenacao()
    {
        var painel = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0,0,0,8), VerticalAlignment = VerticalAlignment.Center };
        painel.Children.Add(new TextBlock { Text = "ORDENAR RELATÓRIO:", FontWeight = FontWeights.Bold, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0,0,10,0) });

        string[] campos = { "(nenhum)", "Data", "Tipo", "Conta Bancária", "Cliente/Fornecedor", "Descrição", "Nº Documento", "Valor", "Plano de Contas", "Centro de Custos", "Grupo de Contas", "Fluxo de Caixa", "Data Emissão", "Período", "Parcelado/Rateado", "Anotações" };
        var combos = new List<ComboBox>();
        var dirs = new List<ComboBox>();
        for (int i=0; i<3; i++)
        {
            painel.Children.Add(new TextBlock { Text = $"{i+1}ª", FontWeight=FontWeights.Bold, VerticalAlignment=VerticalAlignment.Center, Margin=new Thickness(i==0?0:10,0,4,0) });
            var cb = new ComboBox { Width=145, Height=30, ItemsSource=campos, SelectedIndex=0 };
            var dir = new ComboBox { Width=105, Height=30, Margin=new Thickness(4,0,0,0), ItemsSource=new[]{"Crescente ↑","Decrescente ↓"}, SelectedIndex=0 };
            combos.Add(cb); dirs.Add(dir); painel.Children.Add(cb); painel.Children.Add(dir);
        }
        var aplicar = new Button { Content="APLICAR ORDEM", Height=32, Padding=new Thickness(12,0,12,0), Margin=new Thickness(10,0,0,0), FontWeight=FontWeights.Bold };
        aplicar.Click += (_,__) => AplicarOrdenacaoMultipla(combos, dirs);
        painel.Children.Add(aplicar);
        return painel;
    }

    void AplicarOrdenacaoMultipla(List<ComboBox> campos, List<ComboBox> dirs)
    {
        IEnumerable<Lancamento> atual = _itens;
        IOrderedEnumerable<Lancamento>? ordenado = null;
        for (int i=0; i<campos.Count; i++)
        {
            var campo = campos[i].SelectedItem?.ToString();
            if (string.IsNullOrWhiteSpace(campo) || campo == "(nenhum)") continue;
            bool desc = dirs[i].SelectedIndex == 1;
            Func<Lancamento, object?> chave = x => ChaveOrdenacao(x, campo);
            if (ordenado == null)
                ordenado = desc ? atual.OrderByDescending(chave, ComparadorObjetos.Instance) : atual.OrderBy(chave, ComparadorObjetos.Instance);
            else
                ordenado = desc ? ordenado.ThenByDescending(chave, ComparadorObjetos.Instance) : ordenado.ThenBy(chave, ComparadorObjetos.Instance);
        }
        if (ordenado == null) return;
        var lista = ordenado.ToList();
        _itens.Clear(); _itens.AddRange(lista);
        _grid.ItemsSource = null; _grid.ItemsSource = _itens;
    }

    static object? ChaveOrdenacao(Lancamento x, string campo) => campo switch
    {
        "Data" => x.DataPagamento,
        "Tipo" => x.TipoExibicao,
        "Conta Bancária" => x.ContaBancariaNome,
        "Cliente/Fornecedor" => x.ClienteFornecedorNome,
        "Descrição" => x.Descricao,
        "Nº Documento" => x.NumeroDocumento,
        "Valor" => Math.Abs(x.Valor),
        "Plano de Contas" => x.PlanoContasNome,
        "Centro de Custos" => x.CentroCustosNome,
        "Grupo de Contas" => x.GrupoContasNome,
        "Fluxo de Caixa" => x.FluxoCaixaNome,
        "Data Emissão" => x.DataEmissao,
        "Período" => x.Periodo,
        "Parcelado/Rateado" => x.IdentificacaoAgrupamento,
        "Anotações" => x.Anotacoes,
        _ => ""
    };

    sealed class ComparadorObjetos : IComparer<object?>
    {
        public static readonly ComparadorObjetos Instance = new();
        public int Compare(object? a, object? b)
        {
            if (ReferenceEquals(a,b)) return 0; if (a is null) return -1; if (b is null) return 1;
            if (a is string sa && b is string sb) return StringComparer.CurrentCultureIgnoreCase.Compare(sa,sb);
            if (a is IComparable ca) { try { return ca.CompareTo(b); } catch { } }
            return StringComparer.CurrentCultureIgnoreCase.Compare(a.ToString(), b.ToString());
        }
    }

    void Grid_MouseDoubleClick(object sender, System.Windows.Input.MouseButtonEventArgs e)
    {
        if (_grid.SelectedItem is not Lancamento item) return;
        if (Owner is not MainWindow main) return;
        var ids = _itens.Select(x => x.Id).ToList();
        Close();
        main.AbrirLancamentoDoRelatorio(item.Id, ids);
    }

    void AddCol(string h,string path,double width,string? fmt=null, HorizontalAlignment alinhamento=HorizontalAlignment.Left)
    {
        var b=new Binding(path); if(fmt!=null)b.StringFormat=fmt;
        var estilo = new Style(typeof(TextBlock));
        estilo.Setters.Add(new Setter(TextBlock.HorizontalAlignmentProperty, alinhamento));
        estilo.Setters.Add(new Setter(TextBlock.TextAlignmentProperty, alinhamento == HorizontalAlignment.Right ? TextAlignment.Right : alinhamento == HorizontalAlignment.Center ? TextAlignment.Center : TextAlignment.Left));
        estilo.Setters.Add(new Setter(FrameworkElement.MarginProperty, new Thickness(4,0,4,0)));
        _grid.Columns.Add(new DataGridTextColumn{Header=h,Binding=b,Width=width,ElementStyle=estilo,MinWidth=45});
    }

    void CarregarLayoutColunas()
    {
        try
        {
            if(!File.Exists(_arquivoLayout)) return;
            var linhas=File.ReadAllLines(_arquivoLayout);
            for(int i=0;i<_grid.Columns.Count && i<linhas.Length;i++)
                if(double.TryParse(linhas[i], NumberStyles.Any, CultureInfo.InvariantCulture, out var w))
                    _grid.Columns[i].Width=new DataGridLength(Math.Max(45,w));
        } catch { }
    }

    void SalvarLayoutColunas()
    {
        try
        {
            Directory.CreateDirectory(Path.GetDirectoryName(_arquivoLayout)!);
            File.WriteAllLines(_arquivoLayout,_grid.Columns.Select(c=>c.ActualWidth.ToString(CultureInfo.InvariantCulture)));
        } catch { }
    }
    void AddTotal(Grid g,int col,string nome,decimal valor,Color cor)
    { var b=new Border{Background=new SolidColorBrush(cor),Margin=new Thickness(3),BorderBrush=new SolidColorBrush(Color.FromRgb(220,225,230)),BorderThickness=new Thickness(1)}; var s=new StackPanel{VerticalAlignment=VerticalAlignment.Center}; s.Children.Add(new TextBlock{Text=nome,FontWeight=FontWeights.Bold,FontSize=14,HorizontalAlignment=HorizontalAlignment.Center}); s.Children.Add(new TextBlock{Text="R$ "+valor.ToString("N2",_br),FontWeight=FontWeights.Bold,FontSize=22,HorizontalAlignment=HorizontalAlignment.Center}); b.Child=s; Grid.SetColumn(b,col); g.Children.Add(b); }

    void Excel_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            var pasta = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "Financeiro Master Pro");
            Directory.CreateDirectory(pasta);
            var arquivo = Path.Combine(pasta, $"Relatorio_Lancamentos_{DateTime.Now:yyyyMMdd_HHmmss}.csv");
            static string Csv(string? v) => "\"" + (v ?? "").Replace("\"", "\"\"") + "\"";
            using var sw = new StreamWriter(arquivo, false, new UTF8Encoding(true));
            sw.WriteLine("DATA PAGTO/RECEB;TIPO;CONTA BANCÁRIA;CLIENTE/FORNECEDOR;DESCRIÇÃO;Nº DOC;VALOR;PLANO DE CONTAS;CENTRO DE CUSTOS;PARCELADO/RATEADO;ANOTAÇÕES");
            foreach (var x in _grid.Items.Cast<object>().OfType<Lancamento>())
                sw.WriteLine(string.Join(";", new[] { Csv(x.DataPagamento?.ToString("dd/MM/yyyy")), Csv(x.TipoExibicao), Csv(x.ContaBancariaNome), Csv(x.ClienteFornecedorNome), Csv(x.Descricao), Csv(x.NumeroDocumento), x.Valor.ToString("0.00", CultureInfo.InvariantCulture).Replace('.', ','), Csv(x.PlanoContasNome), Csv(x.CentroCustosNome), Csv(x.IdentificacaoAgrupamento), Csv(x.Anotacoes) }));
            Process.Start(new ProcessStartInfo(arquivo) { UseShellExecute = true });
        }
        catch (Exception ex)
        {
            MessageBox.Show("Não foi possível exportar para Excel.\n\n" + ex.Message, "Excel", MessageBoxButton.OK, MessageBoxImage.Warning);
        }
    }

    void Imprimir_Click(object sender, RoutedEventArgs e)
    {
        // Snapshot SOMENTE de dados simples. Nenhum objeto WPF da janela é levado para a thread de impressão.
        var itensOrdenados = _grid.Items.Cast<object>().OfType<Lancamento>().ToList();
        var linhas = itensOrdenados.Select(x => new[] {
            x.DataPagamento?.ToString("dd/MM/yyyy") ?? "", x.TipoExibicao ?? "", x.ContaBancariaNome ?? "",
            x.ClienteFornecedorNome ?? "", x.Descricao ?? "", x.NumeroDocumento ?? "", x.ValorExibicaoSemSinal ?? "",
            x.PlanoContasNome ?? "", x.CentroCustosNome ?? ""
        }).ToList();
        decimal ap = itensOrdenados.Where(x => x.Tipo.Equals("Pagar", StringComparison.OrdinalIgnoreCase) && !x.Baixado).Sum(x => Math.Abs(x.Valor));
        decimal ar = itensOrdenados.Where(x => x.Tipo.Equals("Receber", StringComparison.OrdinalIgnoreCase) && !x.Baixado).Sum(x => Math.Abs(x.Valor));
        decimal pg = itensOrdenados.Where(x => x.Tipo.Equals("Pagar", StringComparison.OrdinalIgnoreCase) && x.Baixado).Sum(x => Math.Abs(x.Valor));
        decimal rc = itensOrdenados.Where(x => x.Tipo.Equals("Receber", StringComparison.OrdinalIgnoreCase) && x.Baixado).Sum(x => Math.Abs(x.Valor));

        var thread = new Thread(() =>
        {
            try
            {
                // TUDO que é WPF da impressão nasce e morre nesta mesma STA.
                var br = CultureInfo.GetCultureInfo("pt-BR");
                var dlg = new System.Windows.Controls.PrintDialog();
                dlg.PrintTicket ??= new PrintTicket();
                dlg.PrintTicket.PageOrientation = PageOrientation.Landscape;
                if (dlg.ShowDialog() != true) return;

                var doc = CriarDocumentoImpressao(linhas, ap, ar, pg, rc, br);
                double w = dlg.PrintableAreaWidth, h = dlg.PrintableAreaHeight;
                if (w <= 0 || double.IsNaN(w)) w = 1056;
                if (h <= 0 || double.IsNaN(h)) h = 768;
                doc.PageWidth = w; doc.PageHeight = h; doc.PagePadding = new Thickness(24); doc.ColumnWidth = Math.Max(1, w - 48);
                var paginator = ((IDocumentPaginatorSource)doc).DocumentPaginator;
                paginator.PageSize = new Size(w, h);
                dlg.PrintDocument(paginator, "Financeiro Master Pro - Relatório de Lançamentos");
            }
            catch (Exception ex)
            {
                System.Windows.MessageBox.Show("Não foi possível concluir a impressão.\n\n" + ex.Message, "Impressão", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        });
        thread.IsBackground = true;
        thread.SetApartmentState(ApartmentState.STA);
        thread.Start();
        // Não há Join/Wait: X, Cancelar e Voltar não prendem a Tela de Lançamentos.
    }

    static FlowDocument CriarDocumentoImpressao(List<string[]> linhas, decimal ap, decimal ar, decimal pg, decimal rc, CultureInfo br)
    {
        var doc = new FlowDocument
        {
            PagePadding = new Thickness(24),
            ColumnGap = 0,
            FontFamily = new FontFamily("Segoe UI"),
            FontSize = 8.5
        };

        doc.Blocks.Add(new Paragraph(new Bold(new Run("Financeiro Master Pro — RELATÓRIO DE LANÇAMENTOS")))
        { FontSize = 15, TextAlignment = TextAlignment.Center, Margin = new Thickness(0,0,0,8) });

        var t = new Table { CellSpacing = 0 };
        string[] hs = { "Data", "Tipo", "Conta", "Cliente/Fornecedor", "Descrição", "Nº Doc", "Valor", "Plano", "Centro" };
        double[] larguras = { .08, .07, .13, .14, .18, .07, .08, .14, .11 };
        foreach (var largura in larguras) t.Columns.Add(new TableColumn { Width = new GridLength(largura, GridUnitType.Star) });

        var rg = new TableRowGroup();
        var hr = new TableRow();
        foreach (var h in hs) hr.Cells.Add(Cell(h, true));
        rg.Rows.Add(hr);

        foreach (var vs in linhas)
        {
            var r = new TableRow();
            for (int i=0;i<vs.Length;i++) r.Cells.Add(Cell(vs[i], false, i==6 ? TextAlignment.Right : TextAlignment.Left));
            rg.Rows.Add(r);
        }
        t.RowGroups.Add(rg);
        doc.Blocks.Add(t);

        doc.Blocks.Add(new Paragraph(new Bold(new Run(
            $"A PAGAR: R$ {ap.ToString("N2", br)}     A RECEBER: R$ {ar.ToString("N2", br)}     PAGO: R$ {pg.ToString("N2", br)}     RECEBIDO: R$ {rc.ToString("N2", br)}")))
        { Margin = new Thickness(0, 10, 0, 0) });

        return doc;
    }
    static TableCell Cell(string s,bool bold, TextAlignment alignment=TextAlignment.Left){var p=new Paragraph{Margin=new Thickness(2),TextAlignment=alignment}; p.Inlines.Add(bold?new Bold(new Run(s)):new Run(s)); return new TableCell(p){BorderBrush=Brushes.LightGray,BorderThickness=new Thickness(.5),Padding=new Thickness(2)};}
}
