using Microsoft.Win32;
using FinanceiroMasterPro.Infrastructure.Data;
using System.Collections.ObjectModel;
using System.Globalization;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows;

namespace FinanceiroMasterPro.Desktop.Views;

public partial class ImportacaoExtratoWindow : Window
{
    private readonly ObservableCollection<ExtratoItem> _itens = new();
    private readonly ContaBancariaRepository _contas = new();
    private readonly LancamentoRepository _lancamentos = new();
    private static readonly CultureInfo PtBr = CultureInfo.GetCultureInfo("pt-BR");

    public ImportacaoExtratoWindow()
    {
        InitializeComponent();
        GridItens.ItemsSource = _itens;
        CmbConta.ItemsSource = _contas.Listar().Where(x => x.Ativo && !x.TipoConta.Contains("Cartão", StringComparison.OrdinalIgnoreCase)).ToList();
        if (CmbConta.Items.Count > 0) CmbConta.SelectedIndex = 0;
    }

    private void SelecionarArquivo_Click(object sender, RoutedEventArgs e)
    {
        var dlg = new OpenFileDialog { Title = "Selecione o extrato bancário", Filter = "Extrato bancário (*.ofx;*.csv)|*.ofx;*.csv|OFX (*.ofx)|*.ofx|CSV (*.csv)|*.csv" };
        if (dlg.ShowDialog() != true) return;
        try
        {
            _itens.Clear();
            IEnumerable<ExtratoItem> lidos = Path.GetExtension(dlg.FileName).Equals(".ofx", StringComparison.OrdinalIgnoreCase)
                ? LerOfx(dlg.FileName) : LerCsv(dlg.FileName);
            foreach (var item in lidos.OrderBy(x => x.Data)) _itens.Add(item);
            TxtArquivo.Text = dlg.FileName;
            TxtStatus.Text = $"{_itens.Count} movimentação(ões) encontrada(s). Confira antes de importar.";
        }
        catch (Exception ex)
        {
            MessageBox.Show("Não foi possível ler o extrato.\n\n" + ex.Message, "Importar Extrato", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    private void Importar_Click(object sender, RoutedEventArgs e)
    {
        if (CmbConta.SelectedItem is not ContaBancaria conta) { MessageBox.Show("Selecione a Conta Bancária."); return; }
        var selecionados = _itens.Where(x => x.Importar).ToList();
        if (selecionados.Count == 0) { MessageBox.Show("Não há movimentações selecionadas para importar."); return; }

        var existentes = _lancamentos.Listar().Where(x => x.Ativo && x.ContaBancariaId == conta.Id).ToList();
        int importados = 0, duplicados = 0;
        foreach (var x in selecionados)
        {
            bool repetido = existentes.Any(e => e.DataPagamento?.Date == x.Data.Date && Math.Abs(e.Valor - x.Valor) < 0.005m &&
                string.Equals(Normalizar(e.Descricao), Normalizar(x.Descricao), StringComparison.OrdinalIgnoreCase));
            if (repetido) { duplicados++; continue; }

            _lancamentos.Salvar(new Lancamento
            {
                Tipo = x.Valor < 0 ? "Pagar" : "Receber",
                ContaBancariaId = conta.Id,
                DataPagamento = x.Data,
                DataEmissao = x.Data,
                Descricao = string.IsNullOrWhiteSpace(x.Descricao) ? "MOVIMENTAÇÃO BANCÁRIA" : x.Descricao.Trim(),
                NumeroDocumento = x.Documento?.Trim() ?? "",
                Valor = x.Valor < 0 ? -Math.Abs(x.Valor) : Math.Abs(x.Valor),
                Periodo = x.Data.ToString("MM/yyyy"),
                Anotacoes = "Importado do extrato bancário",
                Baixado = true,
                DataBaixa = x.Data,
                Ativo = true
            });
            importados++;
        }
        MessageBox.Show($"Importação concluída.\n\nImportados: {importados}\nDuplicados ignorados: {duplicados}", "Importar Extrato", MessageBoxButton.OK, MessageBoxImage.Information);
        DialogResult = true;
    }

    private static IEnumerable<ExtratoItem> LerOfx(string caminho)
    {
        string texto = LerTexto(caminho);
        foreach (Match bloco in Regex.Matches(texto, @"<STMTTRN>(.*?)(?=<STMTTRN>|</BANKTRANLIST>|</STMTTRN>)", RegexOptions.Singleline | RegexOptions.IgnoreCase))
        {
            string b = bloco.Groups[1].Value;
            string ds = Tag(b, "DTPOSTED"); string vs = Tag(b, "TRNAMT");
            if (!LerDataOfx(ds, out var data) || !DecimalFlex(vs, out var valor) || valor == 0) continue;
            string memo = Tag(b, "MEMO"), name = Tag(b, "NAME"), doc = Tag(b, "FITID");
            string desc = string.Join(" - ", new[] { name, memo }.Where(s => !string.IsNullOrWhiteSpace(s)).Distinct(StringComparer.OrdinalIgnoreCase));
            yield return new ExtratoItem { Data = data, Valor = valor, Descricao = Limpar(desc), Documento = Limpar(doc) };
        }
    }

    private static IEnumerable<ExtratoItem> LerCsv(string caminho)
    {
        var linhas = File.ReadAllLines(caminho, Encoding.UTF8).Where(x => !string.IsNullOrWhiteSpace(x)).ToList();
        if (linhas.Count == 0) yield break;
        char sep = linhas[0].Count(c => c == ';') >= linhas[0].Count(c => c == ',') ? ';' : ',';
        var cab = SepararCsv(linhas[0], sep).Select(Normalizar).ToArray();
        int iData = Indice(cab, "data", "date", "dt");
        int iDesc = Indice(cab, "descricao", "descrição", "historico", "histórico", "memo", "lancamento", "lançamento");
        int iValor = Indice(cab, "valor", "amount", "vlr");
        int iDoc = Indice(cab, "documento", "doc", "id", "fitid");
        int inicio = iData >= 0 && iValor >= 0 ? 1 : 0;
        if (inicio == 0) { iData = 0; iDesc = 1; iValor = 2; iDoc = -1; }
        for (int n = inicio; n < linhas.Count; n++)
        {
            var c = SepararCsv(linhas[n], sep);
            if (iData >= c.Count || iValor >= c.Count || !DateTime.TryParse(c[iData], PtBr, DateTimeStyles.None, out var data) || !DecimalFlex(c[iValor], out var valor) || valor == 0) continue;
            yield return new ExtratoItem { Data = data, Valor = valor, Descricao = iDesc >= 0 && iDesc < c.Count ? Limpar(c[iDesc]) : "MOVIMENTAÇÃO BANCÁRIA", Documento = iDoc >= 0 && iDoc < c.Count ? Limpar(c[iDoc]) : "" };
        }
    }

    private static string Tag(string texto, string tag)
    {
        var m = Regex.Match(texto, $@"<{tag}>\s*([^<\r\n]+)", RegexOptions.IgnoreCase);
        return m.Success ? m.Groups[1].Value.Trim() : "";
    }
    private static bool LerDataOfx(string s, out DateTime d) { d = default; var m = Regex.Match(s ?? "", @"\d{8}"); return m.Success && DateTime.TryParseExact(m.Value, "yyyyMMdd", CultureInfo.InvariantCulture, DateTimeStyles.None, out d); }
    private static bool DecimalFlex(string s, out decimal v)
    {
        v = 0m;
        s = (s ?? "").Trim().Replace("R$", "", StringComparison.OrdinalIgnoreCase).Replace(" ", "");
        if (string.IsNullOrWhiteSpace(s)) return false;

        bool negativoParenteses = s.StartsWith("(") && s.EndsWith(")");
        if (negativoParenteses) s = s[1..^1];

        int ultimaVirgula = s.LastIndexOf(',');
        int ultimoPonto = s.LastIndexOf('.');
        string normalizado;

        if (ultimaVirgula >= 0 && ultimoPonto >= 0)
        {
            normalizado = ultimaVirgula > ultimoPonto
                ? s.Replace(".", "").Replace(',', '.')       // 1.234,56
                : s.Replace(",", "");                        // 1,234.56
        }
        else if (ultimaVirgula >= 0)
        {
            normalizado = s.Replace(".", "").Replace(',', '.'); // 89,99
        }
        else
        {
            normalizado = s.Replace(",", "");                    // 89.99 ou 89
        }

        if (!decimal.TryParse(normalizado,
                NumberStyles.AllowLeadingSign | NumberStyles.AllowDecimalPoint,
                CultureInfo.InvariantCulture, out v)) return false;

        if (negativoParenteses) v = -Math.Abs(v);
        return true;
    }
    private static string LerTexto(string p) { try { return File.ReadAllText(p, Encoding.UTF8); } catch { return File.ReadAllText(p, Encoding.GetEncoding(1252)); } }
    private static string Limpar(string s) => System.Net.WebUtility.HtmlDecode((s ?? "").Trim());
    private static string Normalizar(string s) => Regex.Replace((s ?? "").Trim().ToUpperInvariant().Normalize(NormalizationForm.FormD), @"\p{Mn}|\s+", " ");
    private static int Indice(string[] c, params string[] nomes) { for (int i=0;i<c.Length;i++) if (nomes.Any(n => c[i].Contains(Normalizar(n), StringComparison.OrdinalIgnoreCase))) return i; return -1; }
    private static List<string> SepararCsv(string linha, char sep)
    {
        var r = new List<string>(); var b = new StringBuilder(); bool asp = false;
        for (int i=0;i<linha.Length;i++) { char ch=linha[i]; if(ch=='"'){ if(asp && i+1<linha.Length && linha[i+1]=='"'){b.Append('"');i++;} else asp=!asp; } else if(ch==sep && !asp){r.Add(b.ToString().Trim());b.Clear();} else b.Append(ch); }
        r.Add(b.ToString().Trim()); return r;
    }
    private void Cancelar_Click(object sender, RoutedEventArgs e) => Close();
}

public sealed class ExtratoItem
{
    public bool Importar { get; set; } = true;
    public DateTime Data { get; set; }
    public string Descricao { get; set; } = "";
    public string Documento { get; set; } = "";
    public decimal Valor { get; set; }
    public string Tipo => Valor < 0 ? "Pagar" : "Receber";
    public string ValorExibicao => Math.Abs(Valor).ToString("N2", CultureInfo.GetCultureInfo("pt-BR"));
}
