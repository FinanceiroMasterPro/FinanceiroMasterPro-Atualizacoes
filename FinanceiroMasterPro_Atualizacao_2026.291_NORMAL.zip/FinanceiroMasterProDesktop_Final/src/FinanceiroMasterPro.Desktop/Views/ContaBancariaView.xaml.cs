﻿using FinanceiroMasterPro.Infrastructure.Data;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using Microsoft.Win32;

namespace FinanceiroMasterPro.Desktop.Views;
public partial class ContaBancariaView : UserControl
{
    private readonly ContaBancariaRepository _repository=new(); private List<ContaBancaria> _contas=new(); private long _idAtual; private readonly string? _filtroTipo;
    public ContaBancariaView(string? filtroTipo=null){InitializeComponent();_filtroTipo=filtroTipo;AtualizarBibliotecaBandeiras();CarregarContas();Novo();}
    private string TipoAtual()=> (CmbTipo.SelectedItem as ComboBoxItem)?.Content?.ToString() ?? "Conta Bancária";
    private void SelecionarTipo(string tipo){ foreach(ComboBoxItem i in CmbTipo.Items) if(string.Equals(i.Content?.ToString(),tipo,StringComparison.OrdinalIgnoreCase)){CmbTipo.SelectedItem=i;return;} CmbTipo.SelectedIndex=1; }
    private decimal Numero(string t){decimal.TryParse(t,NumberStyles.Any,new CultureInfo("pt-BR"),out var v);return v;}
    private int? Dia(string t){if(int.TryParse(t,out var d)&&d>=1&&d<=31)return d;return null;}
    private void CarregarContas(){_contas=_repository.Listar();var lista=string.IsNullOrWhiteSpace(_filtroTipo)?_contas:_contas.Where(x=>x.TipoConta==_filtroTipo).ToList();GridContas.ItemsSource=lista;CmbContaPagamento.ItemsSource=_contas.Where(x=>x.Ativo&&x.TipoConta!="Cartão de Crédito").ToList();Titulo.Text=_filtroTipo=="Cartão de Crédito"?"CARTÕES DE CRÉDITO":"CADASTRO DE CONTA";}
    private void Novo(){_idAtual=0;TxtNome.Clear();CmbBandeira.SelectedIndex=0;ImgBandeira.Source=null;TxtAgencia.Clear();TxtConta.Clear();TxtSaldoInicial.Text="0,00";TxtLimite.Text="0,00";TxtFechamento.Clear();TxtVencimento.Clear();CmbContaPagamento.SelectedItem=null;ChkAtivo.IsChecked=true;SelecionarTipo(_filtroTipo??"Conta Bancária");GridContas.SelectedItem=null;TxtNome.Focus();}
    private void Moeda_LostFocus(object sender, RoutedEventArgs e)
    {
        if (sender is not TextBox caixa) return;
        var texto=(caixa.Text??string.Empty).Trim();
        if(string.IsNullOrWhiteSpace(texto)){caixa.Text="0,00";return;}
        if(decimal.TryParse(texto,NumberStyles.Number,new CultureInfo("pt-BR"),out var valor) ||
           decimal.TryParse(texto,NumberStyles.Number,CultureInfo.InvariantCulture,out valor))
            caixa.Text=valor.ToString("N2",new CultureInfo("pt-BR"));
    }

    private void Novo_Click(object s,RoutedEventArgs e)=>Novo();
    private void Tipo_SelectionChanged(object s,SelectionChangedEventArgs e){if(PainelCartao!=null)PainelCartao.Visibility=TipoAtual()=="Cartão de Crédito"?Visibility.Visible:Visibility.Collapsed;}
    private void Salvar_Click(object s,RoutedEventArgs e){try{if(string.IsNullOrWhiteSpace(TxtNome.Text)){MessageBox.Show("Informe o nome da conta.");return;}var tipo=TipoAtual();var bandeiraSelecionada=(CmbBandeira.SelectedItem as InstitutionOption)??InstitutionCatalog.PorNome(CmbBandeira.Text);var conta=new ContaBancaria{Id=_idAtual,Nome=TxtNome.Text,TipoConta=tipo,SaldoInicial=Numero(TxtSaldoInicial.Text),Banco=bandeiraSelecionada?.Nome??"",Bandeira=bandeiraSelecionada?.Key??"",Agencia=TxtAgencia.Text,Conta=TxtConta.Text,Ativo=ChkAtivo.IsChecked==true,LimiteCredito=tipo=="Cartão de Crédito"?Numero(TxtLimite.Text):0,DiaFechamento=tipo=="Cartão de Crédito"?Dia(TxtFechamento.Text):null,DiaVencimento=tipo=="Cartão de Crédito"?Dia(TxtVencimento.Text):null,ContaPagamentoId=(CmbContaPagamento.SelectedItem as ContaBancaria)?.Id};_idAtual=_repository.Salvar(conta);MessageBox.Show("Conta salva com sucesso.","Financeiro Master Pro");CarregarContas();Novo();}catch(Exception ex){MessageBox.Show(ex.Message,"Financeiro Master Pro",MessageBoxButton.OK,MessageBoxImage.Error);}}
    public void SelecionarConta(long id){var c=_contas.FirstOrDefault(x=>x.Id==id);if(c==null)return;GridContas.SelectedItem=c;GridContas.ScrollIntoView(c);Preencher(c);}
    private void GridContas_SelectionChanged(object s,SelectionChangedEventArgs e){if(GridContas.SelectedItem is ContaBancaria c)Preencher(c);}
    private void Preencher(ContaBancaria c){_idAtual=c.Id;TxtNome.Text=c.Nome;SelecionarTipo(c.TipoConta);TxtSaldoInicial.Text=c.SaldoInicial.ToString("N2",new CultureInfo("pt-BR"));CmbBandeira.SelectedItem=InstitutionCatalog.Resolver(c.Bandeira,c.Banco)??InstitutionCatalog.Opcoes[0];AtualizarPreviewBandeira();TxtAgencia.Text=c.Agencia;TxtConta.Text=c.Conta;TxtLimite.Text=c.LimiteCredito.ToString("N2",new CultureInfo("pt-BR"));TxtFechamento.Text=c.DiaFechamento?.ToString()??"";TxtVencimento.Text=c.DiaVencimento?.ToString()??"";CmbContaPagamento.SelectedItem=_contas.FirstOrDefault(x=>x.Id==c.ContaPagamentoId);ChkAtivo.IsChecked=c.Ativo;}
    private void Pesquisar_TextChanged(object s,TextChangedEventArgs e){var p=TxtPesquisar.Text.Trim();IEnumerable<ContaBancaria> q=_contas;if(!string.IsNullOrWhiteSpace(_filtroTipo))q=q.Where(x=>x.TipoConta==_filtroTipo);if(!string.IsNullOrWhiteSpace(p))q=q.Where(c=>PesquisaAvancada.Texto(c.Nome+" "+c.TipoConta+" "+c.Banco+" "+c.Bandeira+" "+c.Agencia+" "+c.Conta+" "+c.DiaFechamento+" "+c.DiaVencimento,p)||PesquisaAvancada.Valor(c.SaldoInicial,p)||PesquisaAvancada.Valor(c.LimiteCredito,p));GridContas.ItemsSource=q.ToList();}
    private void Alterar_Click(object s,RoutedEventArgs e){if(_idAtual==0){MessageBox.Show("Selecione uma conta para alterar.");return;}Salvar_Click(s,e);}
    private void Excluir_Click(object s,RoutedEventArgs e){if(_idAtual==0){MessageBox.Show("Selecione uma conta para excluir.");return;}if(MessageBox.Show("Deseja realmente excluir esta conta?","Financeiro Master Pro",MessageBoxButton.YesNo,MessageBoxImage.Warning)!=MessageBoxResult.Yes)return;try{_repository.Excluir(_idAtual);CarregarContas();Novo();}catch(Exception ex){MessageBox.Show(ex.Message,"Financeiro Master Pro",MessageBoxButton.OK,MessageBoxImage.Information);}}

    private void Bandeira_SelectionChanged(object s, SelectionChangedEventArgs e)=>AtualizarPreviewBandeira();
    private void AtualizarBibliotecaBandeiras(string? pesquisa=null, string? selecionarKey=null)
    {
        var lista=InstitutionCatalog.Carregar(pesquisa);
        CmbBandeira.ItemsSource=lista;
        if(!string.IsNullOrWhiteSpace(selecionarKey)) CmbBandeira.SelectedItem=lista.FirstOrDefault(x=>x.Key==selecionarKey);
        else if(CmbBandeira.SelectedItem==null && lista.Count>0) CmbBandeira.SelectedIndex=0;
    }
    private void Bandeira_KeyUp(object sender, KeyEventArgs e)
    {
        if(e.Key is Key.Up or Key.Down or Key.Enter or Key.Tab or Key.Escape) return;
        var texto=CmbBandeira.Text?.Trim()??"";
        var atual=(CmbBandeira.SelectedItem as InstitutionOption)?.Key;
        AtualizarBibliotecaBandeiras(texto,atual);
        CmbBandeira.IsDropDownOpen=true;
    }
    private string SolicitarNomeBandeira(string sugestao)
    {
        var w=new Window{Title="Adicionar bandeira personalizada",Width=430,Height=180,WindowStartupLocation=WindowStartupLocation.CenterOwner,ResizeMode=ResizeMode.NoResize,Owner=Window.GetWindow(this)};
        var painel=new StackPanel{Margin=new Thickness(18)};
        painel.Children.Add(new TextBlock{Text="Nome da bandeira / instituição:",Margin=new Thickness(0,0,0,7)});
        var caixa=new TextBox{Text=sugestao,Height=34,Padding=new Thickness(7,5,7,5)}; painel.Children.Add(caixa);
        var botoes=new StackPanel{Orientation=Orientation.Horizontal,HorizontalAlignment=HorizontalAlignment.Right,Margin=new Thickness(0,14,0,0)};
        var cancelar=new Button{Content="CANCELAR",Width=90,Height=32,Margin=new Thickness(0,0,8,0)}; var ok=new Button{Content="ADICIONAR",Width=100,Height=32,IsDefault=true};
        cancelar.Click+=(_,__)=>{w.DialogResult=false;w.Close();}; ok.Click+=(_,__)=>{if(!string.IsNullOrWhiteSpace(caixa.Text)){w.DialogResult=true;w.Close();}}; botoes.Children.Add(cancelar);botoes.Children.Add(ok);painel.Children.Add(botoes);w.Content=painel;caixa.SelectAll();caixa.Focus();
        return w.ShowDialog()==true?caixa.Text.Trim():"";
    }

    private void AdicionarBandeira_Click(object sender,RoutedEventArgs e)
    {
        var dlg=new OpenFileDialog{Title="Escolher imagem da bandeira / instituição",Filter="Imagens (*.png;*.jpg;*.jpeg;*.webp)|*.png;*.jpg;*.jpeg;*.webp|Todos os arquivos (*.*)|*.*"};
        if(dlg.ShowDialog()!=true)return;
        var nome=System.IO.Path.GetFileNameWithoutExtension(dlg.FileName).Replace('_',' ').Replace('-',' ').Trim();
        var entrada=SolicitarNomeBandeira(nome);
        if(string.IsNullOrWhiteSpace(entrada))return;
        try
        {
            var op=InstitutionCatalog.AdicionarPersonalizada(entrada,dlg.FileName);
            AtualizarBibliotecaBandeiras(null,op.Key);
            CmbBandeira.Text=op.Nome;
            AtualizarPreviewBandeira();
            MessageBox.Show("Bandeira adicionada à biblioteca. Ela ficará disponível para todas as empresas.","Financeiro Master Pro");
        }
        catch(Exception ex){MessageBox.Show("Não foi possível adicionar a imagem.\n\n"+ex.Message,"Financeiro Master Pro",MessageBoxButton.OK,MessageBoxImage.Error);}
    }
    private void SubstituirBandeira_Click(object sender,RoutedEventArgs e)
    {
        var op=CmbBandeira.SelectedItem as InstitutionOption;
        if(op==null||string.IsNullOrWhiteSpace(op.Key)){MessageBox.Show("Selecione uma bandeira para substituir.","Financeiro Master Pro");return;}
        var dlg=new OpenFileDialog{Title="Escolher nova imagem da bandeira",Filter="Imagens (*.png;*.jpg;*.jpeg;*.webp)|*.png;*.jpg;*.jpeg;*.webp|Todos os arquivos (*.*)|*.*"};
        if(dlg.ShowDialog()!=true)return;
        try{InstitutionCatalog.SubstituirImagem(op.Key,dlg.FileName);AtualizarBibliotecaBandeiras(null,op.Key);AtualizarPreviewBandeira();MessageBox.Show("Imagem substituída. Todas as contas que usam esta bandeira passam a usar a nova imagem.","Financeiro Master Pro");}
        catch(Exception ex){MessageBox.Show(ex.Message,"Financeiro Master Pro",MessageBoxButton.OK,MessageBoxImage.Error);}
    }
    private void RestaurarBandeira_Click(object sender,RoutedEventArgs e)
    {
        var op=CmbBandeira.SelectedItem as InstitutionOption;
        if(op==null||string.IsNullOrWhiteSpace(op.Key)){MessageBox.Show("Selecione uma bandeira padrão.","Financeiro Master Pro");return;}
        if(!InstitutionCatalog.PodeRestaurarOriginal(op.Key)){MessageBox.Show("Esta bandeira não possui uma substituição para restaurar.","Financeiro Master Pro");return;}
        try{InstitutionCatalog.RestaurarOriginal(op.Key);AtualizarBibliotecaBandeiras(null,op.Key);AtualizarPreviewBandeira();MessageBox.Show("Imagem original restaurada.","Financeiro Master Pro");}
        catch(Exception ex){MessageBox.Show(ex.Message,"Financeiro Master Pro",MessageBoxButton.OK,MessageBoxImage.Error);}
    }
    private void AjustarBandeira_Click(object sender,RoutedEventArgs e)
    {
        var op=CmbBandeira.SelectedItem as InstitutionOption;
        if(op==null||!op.Personalizada){MessageBox.Show("O ajuste de tamanho é destinado às bandeiras personalizadas que você adicionou.\nAs bandeiras padrão do sistema já vêm configuradas.","Financeiro Master Pro");return;}
        try
        {
            InstitutionCatalog.AjustarPersonalizada(op.Key,1.0);
            AtualizarPreviewBandeira();
            MessageBox.Show("Bandeira ajustada. As margens vazias foram removidas e a imagem foi centralizada para ocupar melhor o quadradinho.","Financeiro Master Pro");
        }
        catch(Exception ex){MessageBox.Show(ex.Message,"Financeiro Master Pro",MessageBoxButton.OK,MessageBoxImage.Error);}
    }
    private void ExcluirBandeira_Click(object sender,RoutedEventArgs e)
    {
        var op=CmbBandeira.SelectedItem as InstitutionOption;
        if(op==null||!op.Personalizada){MessageBox.Show("Somente bandeiras personalizadas podem ser excluídas.\nAs bandeiras padrão do sistema são protegidas.","Financeiro Master Pro");return;}
        var emUso=_contas.Count(x=>string.Equals(x.Bandeira,op.Key,StringComparison.OrdinalIgnoreCase));
        var aviso=emUso>0?$"\n\nATENÇÃO: esta bandeira está sendo usada por {emUso} conta(s). Essas contas ficarão sem a imagem até você escolher outra bandeira.":"";
        if(MessageBox.Show($"Excluir a bandeira personalizada '{op.Nome}'?{aviso}","Financeiro Master Pro",MessageBoxButton.YesNo,MessageBoxImage.Warning)!=MessageBoxResult.Yes)return;
        try{InstitutionCatalog.ExcluirPersonalizada(op.Key);AtualizarBibliotecaBandeiras();CmbBandeira.SelectedIndex=0;AtualizarPreviewBandeira();MessageBox.Show("Bandeira excluída da biblioteca.","Financeiro Master Pro");}
        catch(Exception ex){MessageBox.Show(ex.Message,"Financeiro Master Pro",MessageBoxButton.OK,MessageBoxImage.Error);}
    }
    private void AtualizarPreviewBandeira()
    {
        var op=CmbBandeira?.SelectedItem as InstitutionOption; if(ImgBandeira==null)return;
        if(string.IsNullOrWhiteSpace(op?.Icone)){ImgBandeira.Source=null;return;}
        try
        {
            var uri = op.Icone.StartsWith("pack://", StringComparison.OrdinalIgnoreCase)
                ? new Uri(op.Icone, UriKind.Absolute)
                : System.IO.Path.IsPathRooted(op.Icone)
                    ? new Uri(op.Icone, UriKind.Absolute)
                    : new Uri(op.Icone, UriKind.RelativeOrAbsolute);
            var bmp=new System.Windows.Media.Imaging.BitmapImage(); bmp.BeginInit(); bmp.CacheOption=System.Windows.Media.Imaging.BitmapCacheOption.OnLoad; bmp.UriSource=uri; bmp.EndInit(); bmp.Freeze(); ImgBandeira.Source=bmp;
        }
        catch{ImgBandeira.Source=null;}
    }
    private void Cadastro_PreviewKeyDown(object sender, KeyEventArgs e)
    {
        if (e.Key != Key.Enter) return;
        if (Keyboard.FocusedElement is Button) return;
        e.Handled = true;
        (Keyboard.FocusedElement as UIElement)?.MoveFocus(new TraversalRequest(FocusNavigationDirection.Next));
    }
}