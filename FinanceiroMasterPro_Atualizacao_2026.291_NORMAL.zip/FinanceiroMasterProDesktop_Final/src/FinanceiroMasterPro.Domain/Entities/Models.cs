namespace FinanceiroMasterPro.Domain.Entities;
public enum TipoLancamento { Pagar, Receber }
public enum StatusLancamento { Aberto, Pago, Cancelado }
public sealed class Usuario { public Guid Id {get;set;}=Guid.NewGuid(); public string Nome {get;set;}=""; public string Login {get;set;}=""; public string SenhaHash {get;set;}=""; public bool Ativo {get;set;}=true; public bool Administrador {get;set;} }
public sealed class ContaBancaria { public Guid Id {get;set;}=Guid.NewGuid(); public string Nome {get;set;}=""; public bool Ativa {get;set;}=true; }
public sealed class PlanoConta { public Guid Id {get;set;}=Guid.NewGuid(); public string Nome {get;set;}=""; }
public sealed class CentroCusto { public Guid Id {get;set;}=Guid.NewGuid(); public string Nome {get;set;}=""; }
public sealed class GrupoConta { public Guid Id {get;set;}=Guid.NewGuid(); public string Nome {get;set;}=""; }
public sealed class FluxoCaixa { public Guid Id {get;set;}=Guid.NewGuid(); public string Nome {get;set;}=""; }
public sealed class ClienteFornecedor { public Guid Id {get;set;}=Guid.NewGuid(); public string Nome {get;set;}=""; public string Documento {get;set;}=""; }
public sealed class Lancamento {
 public Guid Id {get;set;}=Guid.NewGuid(); public TipoLancamento Tipo {get;set;} public StatusLancamento Status {get;set;}=StatusLancamento.Aberto;
 public Guid? ContaBancariaId {get;set;} public DateTime DataPagamento {get;set;}=DateTime.Today; public DateTime DataEmissao {get;set;}=DateTime.Today;
 public string ClienteFornecedor {get;set;}=""; public string Descricao {get;set;}=""; public string PlanoContas {get;set;}=""; public string CentroCustos {get;set;}="";
 public string GrupoContas {get;set;}=""; public string FluxoCaixa {get;set;}=""; public decimal Valor {get;set;} public string Periodo {get;set;}=""; public string Anotacoes {get;set;}="";
 public bool Baixado {get;set;} public Guid? FaturaCartaoId {get;set;} public Guid? ParcelamentoId {get;set;} public Guid? RateioId {get;set;}
}
public sealed class FaturaCartao { public Guid Id {get;set;}=Guid.NewGuid(); public string Cartao {get;set;}=""; public DateTime Vencimento {get;set;} public bool Baixada {get;set;} }
public sealed class Parcela { public Guid Id {get;set;}=Guid.NewGuid(); public Guid LancamentoOrigemId {get;set;} public int Numero {get;set;} public int Total {get;set;} public DateTime Vencimento {get;set;} public decimal Valor {get;set;} }
public sealed class RateioItem { public Guid Id {get;set;}=Guid.NewGuid(); public Guid LancamentoId {get;set;} public string CentroCusto {get;set;}=""; public decimal Percentual {get;set;} public decimal Valor {get;set;} }
public sealed class Provisionamento { public Guid Id {get;set;}=Guid.NewGuid(); public string Descricao {get;set;}=""; public decimal Valor {get;set;} public DateTime Competencia {get;set;} }
public sealed class LicencaLocal { public string Cliente {get;set;}=""; public string Chave {get;set;}=""; public DateTime? ExpiraEm {get;set;} public bool Avaliacao {get;set;} public bool Ativa {get;set;} }
