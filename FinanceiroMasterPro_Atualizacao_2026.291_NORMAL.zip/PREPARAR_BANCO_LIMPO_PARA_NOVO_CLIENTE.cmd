@echo off
setlocal
title Financeiro Master Pro - Banco limpo para novo cliente
echo.
echo ============================================================
echo  FINANCEIRO MASTER PRO - PREPARAR NOVO CLIENTE
echo ============================================================
echo.
echo ESTE UTILITARIO APAGA SOMENTE OS DADOS FINANCEIROS/CADASTROS
echo DO BANCO LOCAL DESTA MAQUINA E MANTEM A ESTRUTURA DO SISTEMA.
echo.
echo NAO USE PARA ATUALIZAR CLIENTES EXISTENTES.
echo.
set /p CONF=Digite LIMPAR para confirmar: 
if /I not "%CONF%"=="LIMPAR" exit /b 0
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Preparar-BancoLimpo-NovoCliente.ps1"
if errorlevel 1 (
  echo.
  echo A limpeza nao foi concluida.
  pause
  exit /b 1
)
echo.
echo Banco preparado e limpo para novo cliente.
pause
