@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Atualizar-FinanceiroMasterPro.ps1"
if errorlevel 1 (
  echo.
  echo A atualizacao nao foi concluida. O sistema anterior foi preservado.
  pause
  exit /b 1
)
exit /b 0
