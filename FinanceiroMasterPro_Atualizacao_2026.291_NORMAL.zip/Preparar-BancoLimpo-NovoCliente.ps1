$ErrorActionPreference='Stop'
$DataDir=Join-Path $env:LOCALAPPDATA 'FinanceiroMasterPro'
$Db=Join-Path $DataDir 'financeiro.db'
$BackupDir=Join-Path $DataDir 'Backups'
if (!(Test-Path $Db)) {
  Write-Host 'Banco ainda nao existe. A primeira abertura criara a estrutura vazia.' -ForegroundColor Green
  exit 0
}
New-Item -ItemType Directory -Force -Path $BackupDir | Out-Null
$stamp=Get-Date -Format 'yyyyMMdd_HHmmss'
Copy-Item $Db (Join-Path $BackupDir "financeiro_antes_limpeza_novo_cliente_$stamp.db") -Force
Write-Host 'Backup de seguranca criado.' -ForegroundColor Green

# Usa sqlite3 somente se estiver disponivel. Caso contrario, remove o banco local:
# o DatabaseInitializer recria todas as tabelas/estrutura na proxima abertura.
$sqlite=Get-Command sqlite3.exe -ErrorAction SilentlyContinue
if ($sqlite) {
  $sql=@'
PRAGMA foreign_keys=OFF;
BEGIN TRANSACTION;
DELETE FROM RateioItens;
DELETE FROM Rateios;
DELETE FROM ParcelamentoItens;
DELETE FROM Parcelamentos;
DELETE FROM Lancamentos;
DELETE FROM ClientesFornecedores;
DELETE FROM PlanosContas;
DELETE FROM CentrosCustos;
DELETE FROM GruposContas;
DELETE FROM FluxosCaixa;
DELETE FROM ContasBancarias;
DELETE FROM sqlite_sequence WHERE name IN ('RateioItens','Rateios','ParcelamentoItens','Parcelamentos','Lancamentos','ClientesFornecedores','PlanosContas','CentrosCustos','GruposContas','FluxosCaixa','ContasBancarias');
COMMIT;
VACUUM;
'@
  $tmp=Join-Path $env:TEMP 'fmp_limpar_cliente.sql'
  Set-Content -Path $tmp -Value $sql -Encoding UTF8
  & $sqlite.Source $Db ".read '$($tmp -replace '\\','/')'"
  if ($LASTEXITCODE -ne 0) { throw 'Falha ao limpar o banco.' }
  Remove-Item $tmp -Force -ErrorAction SilentlyContinue
} else {
  Remove-Item $Db -Force
}
Write-Host 'Dados financeiros removidos. Estrutura sera mantida/recriada automaticamente.' -ForegroundColor Green
