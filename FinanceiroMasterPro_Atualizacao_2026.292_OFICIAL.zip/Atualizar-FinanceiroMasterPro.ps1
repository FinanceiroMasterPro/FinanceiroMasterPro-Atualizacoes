﻿$ErrorActionPreference = 'Stop'
$Version = '2026.292'
$Base = Split-Path -Parent $MyInvocation.MyCommand.Path
$ProjectRoot = Join-Path $Base 'FinanceiroMasterProDesktop_Final'
$Project = Join-Path $ProjectRoot 'src\FinanceiroMasterPro.Desktop\FinanceiroMasterPro.Desktop.csproj'
$Publish = Join-Path $env:TEMP "FinanceiroMasterPro_Publish_$Version"
$Install = Join-Path $env:LOCALAPPDATA 'FinanceiroMasterPro\App'
$DataDir = Join-Path $env:LOCALAPPDATA 'FinanceiroMasterPro'
$Db = Join-Path $DataDir 'financeiro.db'
$CurrentExe = Join-Path $Install 'FinanceiroMasterPro.exe'
$BackupDir = Join-Path $DataDir 'Backups'
# REGRA DEFINITIVA: atualizacoes preservam o banco financeiro.db do cliente.
# Somente os arquivos do aplicativo sao substituidos.

Write-Host '==> Financeiro Master Pro - Atualizacao' $Version -ForegroundColor Cyan
Get-ChildItem -Path $Base -Recurse -File -ErrorAction SilentlyContinue | Unblock-File -ErrorAction SilentlyContinue
Get-Process FinanceiroMasterPro -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue

New-Item -ItemType Directory -Force -Path $DataDir,$BackupDir | Out-Null
$stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
Get-ChildItem -Path $DataDir -Filter '*.db' -File -ErrorAction SilentlyContinue | ForEach-Object {
  Copy-Item $_.FullName (Join-Path $BackupDir ($_.BaseName + "_antes_$Version`_$stamp.db")) -Force
}
$EmpresasJson = Join-Path $DataDir 'empresas.json'
if (Test-Path $EmpresasJson) { Copy-Item $EmpresasJson (Join-Path $BackupDir "empresas_antes_$Version`_$stamp.json") -Force }
Write-Host '==> Backup dos bancos das empresas concluido.' -ForegroundColor Green

try {
  if (Test-Path $Publish) { Remove-Item $Publish -Recurse -Force }
  Write-Host '==> Compilando a nova versao...' -ForegroundColor Cyan
  & dotnet publish $Project -c Release -r win-x64 --self-contained false -o $Publish
  if ($LASTEXITCODE -ne 0) { throw 'Falha ao compilar a atualizacao.' }
  $Exe = Join-Path $Publish 'FinanceiroMasterPro.exe'
  if (!(Test-Path $Exe)) { throw 'Executavel novo nao foi gerado.' }

  $Staging = Join-Path $env:TEMP "FinanceiroMasterPro_Staging_$Version"
  if (Test-Path $Staging) { Remove-Item $Staging -Recurse -Force }
  Copy-Item $Publish $Staging -Recurse -Force
  if (!(Test-Path (Join-Path $Staging 'FinanceiroMasterPro.exe'))) { throw 'Validacao da nova versao falhou.' }
}
catch {
  Write-Host '==> A nova atualizacao apresentou erro antes da instalacao.' -ForegroundColor Red
  Write-Host '==> A versao anterior foi mantida e sera reaberta.' -ForegroundColor Yellow
  Add-Type -AssemblyName PresentationFramework -ErrorAction SilentlyContinue
  try {
    [System.Windows.MessageBox]::Show(
      "A atualizacao $Version apresentou erro.`n`nA versao anterior foi mantida com seguranca.",
      "Financeiro Master Pro - Atualizacao",
      'OK',
      'Warning',
      'None',
      'DefaultDesktopOnly'
    ) | Out-Null
  } catch {}
  if (Test-Path $CurrentExe) { Start-Process $CurrentExe }
  exit 1
}

# Protecao contra falha durante a troca dos arquivos do aplicativo.
# A versao atual e copiada antes da instalacao e restaurada automaticamente se algo der errado.
$AppBackup = Join-Path $BackupDir "App_antes_$Version`_$stamp"
if (Test-Path $AppBackup) { Remove-Item $AppBackup -Recurse -Force }
if (Test-Path $Install) {
  New-Item -ItemType Directory -Force -Path $AppBackup | Out-Null
  Copy-Item (Join-Path $Install '*') $AppBackup -Recurse -Force -ErrorAction Stop
  Write-Host '==> Backup da versao atual do aplicativo concluido.' -ForegroundColor Green
}

try {
  New-Item -ItemType Directory -Force -Path $Install | Out-Null
  Get-ChildItem $Install -Force -ErrorAction SilentlyContinue | Remove-Item -Recurse -Force -ErrorAction Stop
  Copy-Item (Join-Path $Staging '*') $Install -Recurse -Force -ErrorAction Stop
  Get-ChildItem -Path $Install -Recurse -File | Unblock-File -ErrorAction SilentlyContinue

  $InstalledExe = Join-Path $Install 'FinanceiroMasterPro.exe'
  if (!(Test-Path $InstalledExe)) { throw 'Executavel instalado nao foi encontrado.' }
}
catch {
  Write-Host '==> ERRO NA ATUALIZACAO. Restaurando a versao anterior...' -ForegroundColor Red
  New-Item -ItemType Directory -Force -Path $Install | Out-Null
  Get-ChildItem $Install -Force -ErrorAction SilentlyContinue | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
  if (Test-Path $AppBackup) {
    Copy-Item (Join-Path $AppBackup '*') $Install -Recurse -Force -ErrorAction SilentlyContinue
    $OldExe = Join-Path $Install 'FinanceiroMasterPro.exe'
    Write-Host '==> Versao anterior restaurada com sucesso.' -ForegroundColor Yellow
    if (Test-Path $OldExe) { Start-Process $OldExe }
  }
  throw
}

$InstalledExe = Join-Path $Install 'FinanceiroMasterPro.exe'
$Shell = New-Object -ComObject WScript.Shell
$Desktop = [Environment]::GetFolderPath('Desktop')
$Shortcut = $Shell.CreateShortcut((Join-Path $Desktop 'Financeiro Master Pro.lnk'))
$Shortcut.TargetPath = $InstalledExe
$Shortcut.WorkingDirectory = $Install
$Shortcut.IconLocation = "$InstalledExe,0"
$Shortcut.Description = "Financeiro Master Pro - Versao $Version"
$Shortcut.Save()

$Programs = [Environment]::GetFolderPath('Programs')
$MenuLink = $Shell.CreateShortcut((Join-Path $Programs 'Financeiro Master Pro.lnk'))
$MenuLink.TargetPath = $InstalledExe
$MenuLink.WorkingDirectory = $Install
$MenuLink.IconLocation = "$InstalledExe,0"
$MenuLink.Description = "Financeiro Master Pro - Versao $Version"
$MenuLink.Save()

Write-Host '==> Atualizacao instalada com sucesso.' -ForegroundColor Green
Write-Host '==> Versao' $Version -ForegroundColor Green
Start-Process $InstalledExe
Start-Sleep -Seconds 2
