param([string]$PackagePath = "FinanceiroMasterPro_Atualizacao_2026.463_FINAL.zip")
$ErrorActionPreference = "Stop"
$root = Join-Path $env:TEMP ("fmp_test_instalacao_" + [guid]::NewGuid().ToString("N"))
New-Item -ItemType Directory -Path $root -Force | Out-Null
function Conferir([bool]$ok,[string]$msg) { if (!$ok) { throw $msg } }
function Executar([string]$pacote,[string]$hash,[string]$destino) {
    & powershell.exe -NoProfile -ExecutionPolicy Bypass -File "publicado/Atualizar-FinanceiroMasterPro.ps1" -PackagePath $pacote -ExpectedHash $hash -DestinationPath $destino -NoRestart
    return $LASTEXITCODE
}
try {
    $zip = (Resolve-Path $PackagePath).Path
    $hash = (Get-FileHash $zip -Algorithm SHA256).Hash
    $app = Join-Path $root "App"
    New-Item -ItemType Directory -Path $app -Force | Out-Null
    Set-Content "$app/FinanceiroMasterPro.exe" "VERSAO ANTIGA"
    Set-Content "$app/financeiro.db" "BANCO PRESERVADO"
    Set-Content "$app/cliente.db-wal" "WAL PRESERVADO"
    $db=(Get-FileHash "$app/financeiro.db").Hash
    $wal=(Get-FileHash "$app/cliente.db-wal").Hash
    $codigo=Executar $zip $hash $app
    Conferir ($codigo[-1] -eq 0) "Instalacao do ZIP real falhou."
    Conferir ((Get-FileHash "$app/FinanceiroMasterPro.exe").Hash -eq (Get-FileHash "publicado/FinanceiroMasterPro.exe").Hash) "Executavel nao atualizado."
    Conferir ((Get-FileHash "$app/financeiro.db").Hash -eq $db -and (Get-FileHash "$app/cliente.db-wal").Hash -eq $wal) "Dados alterados."
    Conferir (Test-Path "$app/Atualizar-FinanceiroMasterPro.ps1") "Instalador futuro ausente."
    $antes=(Get-FileHash "$app/FinanceiroMasterPro.exe").Hash
    $codigo=Executar $zip ("0"*64) $app
    Conferir ($codigo[-1] -ne 0 -and (Get-FileHash "$app/FinanceiroMasterPro.exe").Hash -eq $antes) "Hash incorreto aceito."
    Set-Content "$app/FinanceiroMasterPro.exe" "VERSAO PARA ROLLBACK"
    $antes=(Get-FileHash "$app/FinanceiroMasterPro.exe").Hash
    $env:FMP_TEST_FAIL_AFTER_COPY="1"
    $codigo=Executar $zip $hash $app
    Remove-Item Env:FMP_TEST_FAIL_AFTER_COPY
    Conferir ($codigo[-1] -ne 0 -and (Get-FileHash "$app/FinanceiroMasterPro.exe").Hash -eq $antes) "Rollback nao restaurou versao anterior."
    Conferir ((Get-FileHash "$app/financeiro.db").Hash -eq $db) "Rollback alterou banco."
    $manual=Join-Path $root "extraido";Expand-Archive $zip $manual
    $destino=Join-Path $root "Manual"
    & powershell.exe -NoProfile -ExecutionPolicy Bypass -File "$manual/Atualizar-FinanceiroMasterPro.ps1" -DestinationPath $destino -NoRestart
    Conferir ($LASTEXITCODE -eq 0 -and (Test-Path "$destino/FinanceiroMasterPro.exe")) "Instalacao manual falhou."
    Conferir ((Get-FileHash "$destino/FinanceiroMasterPro.dll").Hash -eq (Get-FileHash "publicado/FinanceiroMasterPro.dll").Hash) "DLL manual divergente."
    Write-Host "PASS: instalacao automatica pelo ZIP real e manual pela pasta extraida, executavel/DLL/instalador conferidos, bancos e WAL preservados, hash incorreto rejeitado e rollback restaurou versao anterior."
} finally {
    Remove-Item Env:FMP_TEST_FAIL_AFTER_COPY -ErrorAction SilentlyContinue
    Remove-Item $root -Recurse -Force -ErrorAction SilentlyContinue
}






