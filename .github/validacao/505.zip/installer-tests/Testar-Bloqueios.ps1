param([Parameter(Mandatory=$true)][string]$PackagePath)
$ErrorActionPreference = "Stop"
$root = Join-Path $env:TEMP ("fmp_test_bloqueios_" + [guid]::NewGuid().ToString("N"))
New-Item -ItemType Directory -Path $root -Force | Out-Null
$processos = [Collections.Generic.List[Diagnostics.Process]]::new()
function Conferir([bool]$ok,[string]$msg) { if (!$ok) { throw $msg } }
function Executar([string]$destino,[int]$espera=20,[int]$pai=0) {
    & powershell.exe -NoProfile -ExecutionPolicy Bypass -File "publicado/Atualizar-FinanceiroMasterPro.ps1" -PackagePath $zip -ExpectedHash $hash -DestinationPath $destino -NoRestart -LockWaitSeconds $espera -WaitProcessId $pai | Out-Host
    return $LASTEXITCODE
}
function Bloquear([string]$destino,[int]$segundos) {
    $sinal = Join-Path $destino "bloqueio-pronto.txt"
    $p = Start-Process powershell.exe -ArgumentList @("-NoProfile","-ExecutionPolicy","Bypass","-File",('"' + $locker + '"'),"-Pasta",('"' + $destino + '"'),"-Segundos",$segundos) -PassThru
    $processos.Add($p)
    $limite = [DateTime]::UtcNow.AddSeconds(15)
    while (!(Test-Path $sinal)) {
        if ($p.HasExited -or [DateTime]::UtcNow -gt $limite) { throw "Processo de bloqueio nao iniciou." }
        Start-Sleep -Milliseconds 100
    }
    return $p
}
try {
    $zip = (Resolve-Path $PackagePath).Path
    $hash = (Get-FileHash $zip -Algorithm SHA256).Hash
    $locker = Join-Path $root "bloquear.ps1"
    @'
param([string]$Pasta,[int]$Segundos)
$ErrorActionPreference="Stop"
$a=[IO.File]::Open((Join-Path $Pasta "FinanceiroMasterPro.exe"),[IO.FileMode]::Open,[IO.FileAccess]::Read,[IO.FileShare]::Read)
$b=[IO.File]::Open((Join-Path $Pasta "FinanceiroMasterPro.dll"),[IO.FileMode]::Open,[IO.FileAccess]::Read,[IO.FileShare]::Read)
try { Set-Content (Join-Path $Pasta "bloqueio-pronto.txt") "PRONTO"; Start-Sleep -Seconds $Segundos }
finally { $a.Dispose();$b.Dispose() }
'@ | Set-Content $locker
    $temporario = Join-Path $root "Temporario"
    New-Item -ItemType Directory -Path $temporario -Force | Out-Null
    Set-Content "$temporario/FinanceiroMasterPro.exe" "EXE ANTIGO"
    Set-Content "$temporario/FinanceiroMasterPro.dll" "DLL ANTIGA"
    Set-Content "$temporario/cliente.db" "DADOS INTACTOS"
    $db = (Get-FileHash "$temporario/cliente.db").Hash
    $p = Bloquear $temporario 12
    $relogio = [Diagnostics.Stopwatch]::StartNew()
    $codigo = Executar $temporario
    Conferir ($codigo -eq 0 -and $relogio.Elapsed.TotalSeconds -gt 3) "Instalador nao aguardou bloqueio temporario."
    Conferir ((Get-FileHash "$temporario/FinanceiroMasterPro.exe").Hash -eq (Get-FileHash "publicado/FinanceiroMasterPro.exe").Hash) "EXE nao atualizado apos liberacao."
    Conferir ((Get-FileHash "$temporario/FinanceiroMasterPro.dll").Hash -eq (Get-FileHash "publicado/FinanceiroMasterPro.dll").Hash) "DLL nao atualizada apos liberacao."
    Conferir ((Get-FileHash "$temporario/cliente.db").Hash -eq $db) "Espera alterou banco."
    Write-Host "PASS BLOQUEIO TEMPORARIO: EXE e DLL bloqueados juntos; aguarda liberacao e instala sem falha de rollback."

    $permanente = Join-Path $root "Permanente"
    New-Item -ItemType Directory -Path $permanente -Force | Out-Null
    Set-Content "$permanente/FinanceiroMasterPro.exe" "EXE PRESERVADO"
    Set-Content "$permanente/FinanceiroMasterPro.dll" "DLL PRESERVADA"
    Set-Content "$permanente/cliente.db" "BANCO PRESERVADO"
    $antes = @("FinanceiroMasterPro.exe","FinanceiroMasterPro.dll","cliente.db") | ForEach-Object { (Get-FileHash (Join-Path $permanente $_)).Hash }
    $backupsAntes = @(Get-ChildItem $root -Directory -Force -Filter ".fmp_backup_*").Count
    $p = Bloquear $permanente 120
    $codigo = Executar $permanente 2
    $depois = @("FinanceiroMasterPro.exe","FinanceiroMasterPro.dll","cliente.db") | ForEach-Object { (Get-FileHash (Join-Path $permanente $_)).Hash }
    Conferir ($codigo -ne 0 -and ($antes -join ",") -eq ($depois -join ",")) "Bloqueio persistente causou atualizacao parcial."
    Conferir (@(Get-ChildItem $root -Directory -Force -Filter ".fmp_backup_*").Count -eq $backupsAntes) "Backup criado antes de conferir bloqueios."
    $p.Kill();[void]$p.WaitForExit(5000)
    Write-Host "PASS BLOQUEIO PERSISTENTE: falha clara antes de alterar EXE/DLL/banco; nenhuma restauracao de arquivo nao alterado."

    $pai = Join-Path $root "AguardarPai"
    New-Item -ItemType Directory -Path $pai -Force | Out-Null
    Set-Content "$pai/FinanceiroMasterPro.exe" "EXE DO PAI"
    Set-Content "$pai/FinanceiroMasterPro.dll" "DLL DO PAI"
    $p = Bloquear $pai 8
    $codigo = Executar $pai 20 $p.Id
    Conferir ($codigo -eq 0 -and $p.HasExited) "Atualizacao automatica nao aguardou o processo pai."
    Write-Host "PASS PROCESSO PAI: WaitProcessId aguarda encerramento real antes de substituir arquivos."

    $fonte = Join-Path $root "AplicativoAberto.cs"
    @'
using System;
using System.IO;
using System.Windows.Forms;
class Teste {
    [STAThread] static void Main() {
        string dir=AppDomain.CurrentDomain.BaseDirectory;
        using(var dll=File.Open(Path.Combine(dir,"FinanceiroMasterPro.dll"),FileMode.Open,FileAccess.Read,FileShare.Read)) {
            var form=new Form();form.Text="FMP teste encerramento seguro";
            form.Shown+=(s,e)=>File.WriteAllText(Path.Combine(dir,"janela-pronta.txt"),"PRONTO");
            form.FormClosed+=(s,e)=>{System.Threading.Thread.Sleep(1000);File.WriteAllText(Path.Combine(dir,"encerrado.txt"),"FECHADO");};
            var timer=new Timer();timer.Interval=120000;timer.Tick+=(s,e)=>form.Close();timer.Start();
            Application.Run(form);
        }
    }
}
'@ | Set-Content $fonte
    $aberto = Join-Path $root "Aberto"
    $outro = Join-Path $root "Outro"
    New-Item -ItemType Directory -Path $aberto,$outro -Force | Out-Null
    $csc = Join-Path $env:WINDIR "Microsoft.NET/Framework64/v4.0.30319/csc.exe"
    & $csc /nologo /target:winexe /reference:System.Windows.Forms.dll /reference:System.Drawing.dll "/out:$aberto/FinanceiroMasterPro.exe" $fonte
    if ($LASTEXITCODE -ne 0) { throw "Compilacao do processo real de teste falhou." }
    Copy-Item "$aberto/FinanceiroMasterPro.exe" "$outro/FinanceiroMasterPro.exe"
    Set-Content "$aberto/FinanceiroMasterPro.dll" "DLL EM USO"
    Set-Content "$outro/FinanceiroMasterPro.dll" "DLL DE OUTRA INSTALACAO"
    $apps = @()
    foreach ($dir in @($aberto,$outro)) {
        $p=Start-Process "$dir/FinanceiroMasterPro.exe" -PassThru
        $processos.Add($p);$apps += $p
        $limite=[DateTime]::UtcNow.AddSeconds(15)
        while (!(Test-Path "$dir/janela-pronta.txt")) {
            if ($p.HasExited -or [DateTime]::UtcNow -gt $limite) { throw "Janela de teste nao abriu." }
            Start-Sleep -Milliseconds 100
        }
    }
    $codigo = Executar $aberto 20
    Conferir ($codigo -eq 0 -and (Test-Path "$aberto/encerrado.txt")) "Aplicativo aberto nao encerrou normalmente."
    Conferir (!$apps[1].HasExited -and !(Test-Path "$outro/encerrado.txt")) "Instalador encerrou outra instalacao."
    Conferir ((Get-FileHash "$aberto/FinanceiroMasterPro.exe").Hash -eq (Get-FileHash "publicado/FinanceiroMasterPro.exe").Hash) "EXE mapeado nao substituido."
    Write-Host "PASS APLICATIVO ABERTO: processo Windows real fecha pela janela, libera EXE/DLL e instala; outra instalacao continua aberta."
} finally {
    foreach ($p in $processos) {
        try { if (!$p.HasExited) { $p.Kill();[void]$p.WaitForExit(5000) } } catch {}
        $p.Dispose()
    }
    Remove-Item $root -Recurse -Force -ErrorAction SilentlyContinue
}
